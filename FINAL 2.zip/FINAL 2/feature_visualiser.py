"""Visualisation functions: feature plots, network graph, eigenvalue spectrum, topology figures, event study."""
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

from config import CRASH_EVENTS, FIGURE_DIR


def _annotate_crashes(ax):
    """Shade the three reference crash periods on a time-series axes."""
    colors = ["#FF5722", "#F44336", "#E91E63"]
    for (name, (start, end)), color in zip(CRASH_EVENTS.items(), colors):
        ax.axvspan(pd.Timestamp(start), pd.Timestamp(end),
                   alpha=0.12, color=color, label=name)


def _save(fig, path, dpi=150):
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=dpi, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved: {path}")


def plot_feature_pairplots(features_df, output_path=None):
    """Pair-plot matrix of up to six standard features."""
    if output_path is None:
        output_path = FIGURE_DIR / "feature_pairplot.png"

    cols = [c for c in features_df.columns if c != "crash_label"][:6]
    n    = len(cols)
    if n < 2:
        print("  Pair-plot: not enough feature columns.")
        return

    fig, axes = plt.subplots(n, n, figsize=(3 * n, 3 * n))
    for i, ci in enumerate(cols):
        for j, cj in enumerate(cols):
            ax = axes[i][j]
            if i == j:
                ax.hist(features_df[ci].dropna(), bins=40,
                        color="#4C72B0", alpha=0.7, edgecolor="none")
            else:
                ax.scatter(features_df[cj], features_df[ci],
                           alpha=0.25, s=2, color="#4C72B0", rasterized=True)
            if j == 0:
                ax.set_ylabel(ci, fontsize=7)
            if i == n - 1:
                ax.set_xlabel(cj, fontsize=7)
            ax.tick_params(labelsize=5)

    fig.suptitle("Standard Feature Pair-Plot", fontsize=10, y=1.01)
    fig.tight_layout()
    _save(fig, output_path)


def plot_feature_heatmap(features_df, output_path=None):
    """Pearson correlation heatmap of all standard features."""
    if output_path is None:
        output_path = FIGURE_DIR / "feature_correlation_heatmap.png"

    cols = [c for c in features_df.columns if c != "crash_label"]
    corr = features_df[cols].corr()
    n    = len(cols)

    fig, ax = plt.subplots(figsize=(max(6, n), max(5, n - 1)))
    im = ax.imshow(corr.values, vmin=-1, vmax=1, cmap="RdBu_r", aspect="auto")
    ax.set_xticks(range(n))
    ax.set_yticks(range(n))
    ax.set_xticklabels(cols, rotation=45, ha="right", fontsize=8)
    ax.set_yticklabels(cols, fontsize=8)
    for i in range(n):
        for j in range(n):
            ax.text(j, i, f"{corr.values[i, j]:.2f}",
                    ha="center", va="center", fontsize=6, color="black")
    plt.colorbar(im, ax=ax, label="Pearson r")
    ax.set_title("Feature Correlation Heatmap")
    fig.tight_layout()
    _save(fig, output_path)


def plot_network_graph(corr_matrix, tickers, date_str, output_path=None, threshold=0.5):
    """Spring-layout network graph of asset correlations above threshold."""
    if output_path is None:
        output_path = FIGURE_DIR / f"network_{date_str}.png"

    try:
        import networkx as nx
    except ImportError:
        print("  networkx not installed — skipping network graph.")
        return

    G = nx.Graph()
    n = len(tickers)
    for t in tickers:
        G.add_node(t)
    for i in range(n):
        for j in range(i + 1, n):
            w = corr_matrix[i, j]
            if abs(w) >= threshold:
                G.add_edge(tickers[i], tickers[j], weight=abs(w))

    fig, ax = plt.subplots(figsize=(10, 8))
    pos     = nx.spring_layout(G, seed=42, k=0.5)
    weights = [d["weight"] for _, _, d in G.edges(data=True)]
    nx.draw_networkx_nodes(G, pos, node_size=40, node_color="#4C72B0", alpha=0.8, ax=ax)
    if weights:
        nx.draw_networkx_edges(G, pos, width=[w * 2 for w in weights], alpha=0.35, ax=ax)
    nx.draw_networkx_labels(G, pos, font_size=5, ax=ax)
    ax.set_title(f"Asset Correlation Network — {date_str}  (|rho| >= {threshold})")
    ax.axis("off")
    fig.tight_layout()
    _save(fig, output_path)


def plot_eigenvalue_spectrum(returns_df, output_path=None, rolling_window=60, step_size=5):
    """Rolling largest eigenvalue and eigenvalue gap from Pearson correlation matrices."""
    if output_path is None:
        output_path = FIGURE_DIR / "eigenvalue_spectrum.png"

    arr  = returns_df.values.astype(float)
    n    = len(arr)
    dates, lam1_vals, gap_vals = [], [], []

    for end_pos in range(rolling_window, n, step_size):
        window       = arr[end_pos - rolling_window: end_pos]
        window_clean = window[~np.isnan(window).any(axis=1)]
        if window_clean.shape[0] < 5 or window_clean.shape[1] < 2:
            continue
        corr    = np.corrcoef(window_clean.T)
        eigvals = np.sort(np.linalg.eigvalsh(corr))[::-1]
        dates.append(returns_df.index[end_pos - 1])
        lam1_vals.append(eigvals[0])
        gap_vals.append(eigvals[0] - eigvals[1] if len(eigvals) > 1 else 0.0)

    if not dates:
        print("  Eigenvalue spectrum: no data.")
        return

    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(13, 6), sharex=True)
    ax1.plot(dates, lam1_vals, lw=1, color="#2196F3", label="lambda_1 (market mode)")
    ax1.set_ylabel("Largest eigenvalue (lambda_1)")
    ax1.legend(fontsize=8)
    _annotate_crashes(ax1)

    ax2.plot(dates, gap_vals, lw=1, color="#FF5722", label="Eigenvalue gap (lambda_1 - lambda_2)")
    ax2.set_ylabel("lambda_1 - lambda_2")
    ax2.legend(fontsize=8)
    _annotate_crashes(ax2)
    ax2.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))

    fig.suptitle("Eigenvalue Spectrum Over Time", fontsize=11)
    fig.tight_layout()
    _save(fig, output_path)


def plot_phase_portrait(beta_ratio_df, crash_labels=None, output_path=None):
    """Scatter of (H0, H1) coloured by crash label — topology phase portrait."""
    if output_path is None:
        output_path = FIGURE_DIR / "phase_portrait.png"

    if beta_ratio_df.empty or "h0_sum" not in beta_ratio_df.columns:
        print("  Phase portrait: insufficient data.")
        return

    df = beta_ratio_df.copy()
    df.index = pd.to_datetime(df.index)

    if crash_labels is not None:
        cl = crash_labels.copy()
        cl.index = pd.to_datetime(cl.index)
        df = df.join(cl[["crash_label"]], how="left")
        df["crash_label"] = df["crash_label"].fillna(0)
    else:
        df["crash_label"] = 0

    normal = df[df["crash_label"] == 0]
    crash  = df[df["crash_label"] == 1]

    fig, ax = plt.subplots(figsize=(8, 6))
    ax.scatter(normal["h0_sum"], normal["h1_sum"],
               c="#4C72B0", alpha=0.3, s=8, label="Non-crash")
    ax.scatter(crash["h0_sum"],  crash["h1_sum"],
               c="#D62728", alpha=0.8, s=25, label="Crash", zorder=5)
    ax.set_xlabel("beta_0 — Connected components (H0)")
    ax.set_ylabel("beta_1 — Loops (H1)")
    ax.set_title("Phase Portrait: Topology Space (H0 vs H1)")
    ax.legend()
    fig.tight_layout()
    _save(fig, output_path)


def plot_beta_ratio(beta_ratio_df, crash_labels=None, output_path=None):
    """Time series of H1/H0 ratio with crash period shading (Gidea & Katz, 2018)."""
    if output_path is None:
        output_path = FIGURE_DIR / "beta_ratio.png"

    if beta_ratio_df.empty or "beta_ratio" not in beta_ratio_df.columns:
        print("  Beta ratio: insufficient data.")
        return

    idx = pd.to_datetime(beta_ratio_df.index)
    fig, ax = plt.subplots(figsize=(13, 4))
    ax.plot(idx, beta_ratio_df["beta_ratio"].values, lw=1,
            color="#9C27B0", label="beta_1 / beta_0")
    _annotate_crashes(ax)
    ax.set_ylabel("beta_1 / beta_0")
    ax.set_title("Loop-to-Component Ratio Over Time")
    ax.legend(fontsize=8)
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
    fig.tight_layout()
    _save(fig, output_path)


def plot_event_study(spy_prices, vix_series, wasserstein_df,
                     betti_ratio_df, output_path=None):
    """4-panel event study per crash: S&P 500, VIX, Wasserstein velocity, H1/H0 ratio."""
    if output_path is None:
        output_path = FIGURE_DIR / "event_study.png"

    n_events = len(CRASH_EVENTS)
    fig, axes = plt.subplots(4, n_events, figsize=(6 * n_events, 12))
    if n_events == 1:
        axes = axes.reshape(-1, 1)

    panel_labels = [
        ("S&P 500 Price",        "#2196F3"),
        ("VIX",                  "#FF5722"),
        ("Wasserstein velocity", "#4CAF50"),
        ("beta_1 / beta_0",      "#9C27B0"),
    ]

    for col_idx, (event_name, (start_str, end_str)) in enumerate(CRASH_EVENTS.items()):
        start = pd.Timestamp(start_str)
        end   = pd.Timestamp(end_str)

        series_list = []
        for src, attr in [
            (spy_prices,     None),
            (vix_series,     None),
            (wasserstein_df, None),
            (betti_ratio_df, "beta_ratio"),
        ]:
            if src is not None and not (isinstance(src, pd.DataFrame) and src.empty):
                s = src.copy()
                s.index = pd.to_datetime(s.index)
                if attr:
                    s = s[attr] if attr in s else pd.Series(dtype=float)
                elif isinstance(s, pd.DataFrame):
                    s = s.iloc[:, 0]
                series_list.append(s.loc[start:end])
            else:
                series_list.append(pd.Series(dtype=float))

        for row_idx, (s, (ylabel, color)) in enumerate(zip(series_list, panel_labels)):
            ax = axes[row_idx][col_idx]
            if not s.empty:
                ax.plot(s.index, s.values, lw=1.5, color=color)
            if row_idx == 0:
                ax.set_title(event_name, fontweight="bold", fontsize=10)
            ax.set_ylabel(ylabel, fontsize=8)
            ax.tick_params(labelsize=7)
            ax.xaxis.set_major_formatter(mdates.DateFormatter("%b %Y"))
            plt.setp(ax.xaxis.get_majorticklabels(), rotation=30, ha="right")

    fig.suptitle("Event Study — Market Crashes", fontsize=12, fontweight="bold")
    fig.tight_layout()
    _save(fig, output_path)


def plot_sector_heatmaps(returns_df, sector_map, crash_date,
                         event_name="", output_path=None):
    """Sector correlation heatmaps at T-90, T-30, and T (crash date)."""
    if output_path is None:
        safe_name   = event_name.replace(" ", "_")
        output_path = FIGURE_DIR / f"sector_heatmaps_{safe_name}.png"

    crash_ts   = pd.Timestamp(crash_date)
    returns_df = returns_df.copy()
    returns_df.index = pd.to_datetime(returns_df.index)

    all_tickers = [t for tickers in sector_map.values()
                   for t in tickers if t in returns_df.columns]
    if not all_tickers:
        print(f"  Sector heatmaps ({event_name}): no matching tickers.")
        return

    fig, axes = plt.subplots(1, 3, figsize=(18, 6))
    offsets   = {"T-90 days": 90, "T-30 days": 30, "T (crash)": 0}

    for ax, (label, offset) in zip(axes, offsets.items()):
        ref_date = crash_ts - pd.Timedelta(days=offset)
        window   = returns_df[all_tickers][returns_df.index <= ref_date].tail(60)
        if window.shape[0] < 5:
            ax.set_title(f"{label}\n(insufficient data)")
            continue
        corr = window.corr().values
        im   = ax.imshow(corr, vmin=-1, vmax=1, cmap="RdBu_r", aspect="auto")
        ax.set_title(label, fontsize=10)
        ax.set_xticks([])
        ax.set_yticks([])
        plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

    fig.suptitle(f"Sector Correlation Heatmaps — {event_name} (crash: {crash_date})",
                 fontweight="bold")
    fig.tight_layout()
    _save(fig, output_path)
