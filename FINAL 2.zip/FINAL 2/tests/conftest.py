"""
Add the project root to sys.path so all root-level modules
(data_loader, matrix_builder, etc.) are importable from tests/.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
