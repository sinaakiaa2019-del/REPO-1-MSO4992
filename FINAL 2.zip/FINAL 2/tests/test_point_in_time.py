"""
Tests for the point-in-time / survivorship-bias correction in matrix_builder
(the most consequential Octavian fix).
"""

import numpy as np

from matrix_builder import _active_stocks


def _full_data_window(n_obs=60, n_assets=5, seed=0):
    rng = np.random.default_rng(seed)
    return rng.normal(0, 0.01, (n_obs, n_assets))


def test_no_pit_includes_all_stocks_with_data():
    arr = _full_data_window()
    tickers = np.array(["AAPL", "MSFT", "LEH", "GOOG", "XOM"])
    idx = _active_stocks(arr, 59, 60, 0.8, tickers=tickers, pit_members=None)
    assert set(tickers[idx]) == set(tickers)


def test_pit_excludes_non_members():
    arr = _full_data_window()
    tickers = np.array(["AAPL", "MSFT", "LEH", "GOOG", "XOM"])
    members = {"AAPL", "MSFT", "GOOG", "XOM"}  # LEH not in the index this window
    idx = _active_stocks(arr, 59, 60, 0.8, tickers=tickers, pit_members=members)
    assert "LEH" not in set(tickers[idx])
    assert set(tickers[idx]) == members


def test_pit_includes_delisted_stock_when_it_was_a_member():
    """A firm later removed from the index must still appear in windows where it
    WAS a member -- this is the whole point of the survivorship correction."""
    arr = _full_data_window()
    tickers = np.array(["AAPL", "MSFT", "LEH", "GOOG", "XOM"])
    members = {"AAPL", "LEH"}
    idx = _active_stocks(arr, 59, 60, 0.8, tickers=tickers, pit_members=members)
    assert "LEH" in set(tickers[idx])


def test_pit_intersects_with_data_availability():
    """A stock in the index but WITHOUT enough data is still excluded."""
    arr = _full_data_window()
    arr[:, 2] = np.nan  # LEH has no data this window
    tickers = np.array(["AAPL", "MSFT", "LEH", "GOOG", "XOM"])
    members = {"AAPL", "MSFT", "LEH", "GOOG", "XOM"}  # LEH is a member...
    idx = _active_stocks(arr, 59, 60, 0.8, tickers=tickers, pit_members=members)
    assert "LEH" not in set(tickers[idx])  # ...but has no data, so excluded
