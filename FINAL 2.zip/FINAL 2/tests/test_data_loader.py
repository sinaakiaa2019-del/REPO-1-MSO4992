"""
Unit tests for data_loader.py (Octavian Gurau-Golban).
Run with:  pytest tests/test_data_loader.py -v
"""
import pandas as pd
import pytest

from data_loader import create_demo_prices, get_sp500_at_date


def _make_current(tickers):
    return pd.DataFrame({"ticker": tickers, "gics_sector": ["X"] * len(tickers)})

def _make_changes(records):
    return pd.DataFrame(records, columns=["date", "action", "ticker"])


class TestCreateDemoPrices:
    def test_prices_all_positive(self):
        assert (create_demo_prices(rows=300) > 0).all().all()

    def test_no_nans(self):
        assert not create_demo_prices(rows=100).isna().any().any()

    def test_seed_reproducibility(self):
        pd.testing.assert_frame_equal(create_demo_prices(seed=42), create_demo_prices(seed=42))


class TestGetSp500AtDate:
    def test_stock_added_after_target_is_excluded(self):
        """TSLA added 2020-12-21 should not appear when looking at 2019-01-01."""
        current = _make_current(["AAPL", "TSLA"])
        changes = _make_changes([{"date": "2020-12-21", "action": "added", "ticker": "TSLA"}])
        result = get_sp500_at_date("2019-01-01", current, changes)
        assert "TSLA" not in result
        assert "AAPL" in result

    def test_stock_removed_after_target_is_restored(self):
        """Lehman removed 2008-09-19 should appear when looking at 2007-01-01."""
        current = _make_current(["AAPL"])
        changes = _make_changes([{"date": "2008-09-19", "action": "removed", "ticker": "LEH"}])
        result = get_sp500_at_date("2007-01-01", current, changes)
        assert "LEH" in result

    def test_change_on_target_date_is_not_rolled_back(self):
        current = _make_current(["AAPL", "NEW"])
        changes = _make_changes([{"date": "2020-06-01", "action": "added", "ticker": "NEW"}])
        result = get_sp500_at_date("2020-06-01", current, changes)
        assert "NEW" in result

    def test_change_strictly_after_target_is_rolled_back(self):
        current = _make_current(["AAPL", "NEW"])
        changes = _make_changes([{"date": "2020-06-02", "action": "added", "ticker": "NEW"}])
        result = get_sp500_at_date("2020-06-01", current, changes)
        assert "NEW" not in result

    def test_multiple_changes_all_applied(self):
        current = _make_current(["AAPL", "NEW1", "NEW2"])
        changes = _make_changes([
            {"date": "2021-01-01", "action": "added",   "ticker": "NEW1"},
            {"date": "2021-06-01", "action": "added",   "ticker": "NEW2"},
            {"date": "2020-06-01", "action": "removed", "ticker": "OLD1"},
        ])
        result = get_sp500_at_date("2019-12-31", current, changes)
        assert "NEW1" not in result
        assert "NEW2" not in result
        assert "OLD1" in result
        assert "AAPL" in result

    def test_result_is_sorted(self):
        current = _make_current(["MSFT", "AAPL", "GOOG"])
        changes = pd.DataFrame(columns=["date", "action", "ticker"])
        result = get_sp500_at_date("2020-01-01", current, changes)
        assert result == sorted(result)

    def test_none_changes_handled(self):
        current = _make_current(["AAPL", "MSFT"])
        result = get_sp500_at_date("2019-01-01", current, None)
        assert sorted(result) == ["AAPL", "MSFT"]
