"""
Unit tests for robustness_builder.py and topology_analyser.py (Octavian Gurau-Golban).
Run with:  pytest tests/test_robustness_topology.py -v
"""
import numpy as np
import pandas as pd
import pytest

from robustness_builder import build_alt_lambda_matrices, build_spearman_matrices
from topology_analyser import compute_beta_ratio, compute_summary_statistics


def _make_returns(n_obs=150, n_assets=5, seed=0):
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range("2018-01-01", periods=n_obs)
    return pd.DataFrame(
        rng.normal(0, 0.01, (n_obs, n_assets)),
        index=dates,
        columns=[f"A{i}" for i in range(n_assets)],
    )


class TestBuildAltLambdaMatrices:
    def test_lambda_stored_in_metadata(self, tmp_path):
        meta = build_alt_lambda_matrices(_make_returns(), robustness_dir=tmp_path,
                                         lam_alt=0.97, init_days=60, step_size=10)
        assert (meta["ewma_lambda"] == 0.97).all()

    def test_differs_from_primary_lambda(self, tmp_path):
        """λ=0.94 and λ=0.97 must yield different distance matrices."""
        from matrix_builder import build_ewma_rolling_matrices
        returns = _make_returns(n_obs=130, seed=42)
        pc = tmp_path / "p" / "c"; pc.mkdir(parents=True)
        pd_ = tmp_path / "p" / "d"; pd_.mkdir(parents=True)
        build_ewma_rolling_matrices(returns, pc, pd_, lam=0.94, init_days=60, step_size=20)
        build_alt_lambda_matrices(returns, robustness_dir=tmp_path / "alt",
                                  lam_alt=0.97, init_days=60, step_size=20)
        primary = sorted((tmp_path / "p" / "d").glob("*.npz"))
        alt = sorted((tmp_path / "alt" / "lambda_alt" / "distances").glob("*.npz"))
        n = min(len(primary), len(alt))
        assert n > 0
        assert any(
            not np.allclose(np.load(p)["matrix"], np.load(a)["matrix"])
            for p, a in zip(primary, alt)
        )


class TestBuildSpearmanMatrices:
    def test_distance_matrices_satisfy_metric_axioms(self, tmp_path):
        build_spearman_matrices(_make_returns(), robustness_dir=tmp_path,
                                rolling_window=60, step_size=10)
        for f in (tmp_path / "spearman" / "distances").glob("*.npz"):
            D = np.load(f)["matrix"]
            assert np.allclose(D, D.T, atol=1e-5)
            assert np.allclose(np.diag(D), 0.0, atol=1e-5)
            assert D.min() >= -1e-8

    def test_differs_from_pearson_on_fat_tailed_data(self, tmp_path):
        """On t-distributed returns (df=3), Spearman and Pearson diverge."""
        from matrix_builder import build_ewma_rolling_matrices
        rng = np.random.default_rng(99)
        dates = pd.bdate_range("2018-01-01", periods=150)
        arr = rng.standard_t(df=3, size=(150, 5)) * 0.01
        returns = pd.DataFrame(arr, index=dates, columns=[f"T{i}" for i in range(5)])
        pc = tmp_path / "p" / "c"; pc.mkdir(parents=True)
        pd_ = tmp_path / "p" / "d"; pd_.mkdir(parents=True)
        build_ewma_rolling_matrices(returns, pc, pd_, lam=0.94, init_days=60, step_size=20)
        build_spearman_matrices(returns, robustness_dir=tmp_path / "sp",
                                rolling_window=60, step_size=20)
        pearson = sorted((tmp_path / "p" / "d").glob("*.npz"))
        spearman = sorted((tmp_path / "sp" / "spearman" / "distances").glob("*.npz"))
        n = min(len(pearson), len(spearman))
        if n == 0:
            pytest.skip("Not enough windows.")
        assert any(
            not np.allclose(np.load(p)["matrix"], np.load(s)["matrix"])
            for p, s in zip(pearson, spearman)
        )


class TestComputeBetaRatio:
    def test_formula_with_known_values(self):
        """H0 sums to 4, H1 sums to 2 → ratio must be 0.5."""
        betti = np.zeros((1, 2, 2))
        betti[0, :, 0] = [2, 2]
        betti[0, :, 1] = [1, 1]
        df = compute_beta_ratio(betti, dates=None)
        assert df["beta_ratio"].iloc[0] == pytest.approx(0.5, abs=1e-8)

    def test_zero_h0_does_not_divide_by_zero(self):
        betti = np.zeros((3, 2, 2))
        df = compute_beta_ratio(betti, dates=None)
        assert np.all(np.isfinite(df["beta_ratio"]))

    def test_2d_betti_array_accepted(self):
        betti = np.random.default_rng(0).integers(1, 5, (8, 2)).astype(float)
        df = compute_beta_ratio(betti, dates=None)
        assert len(df) == 8

    def test_none_input_returns_empty(self):
        assert compute_beta_ratio(None, dates=None).empty

    def test_dates_set_as_index(self):
        betti = np.ones((5, 2, 2))
        dates = pd.date_range("2020-01-01", periods=5)
        df = compute_beta_ratio(betti, dates=dates)
        assert list(df.index) == list(dates)


class TestComputeSummaryStatistics:
    def _make_data(self, n=100, seed=0):
        rng = np.random.default_rng(seed)
        dates = pd.bdate_range("2018-01-01", periods=n)
        tdf = pd.DataFrame(rng.normal(size=(n, 3)), index=dates,
                           columns=["betti0", "betti1", "wasserstein"])
        cl = pd.DataFrame({"crash_label": (rng.random(n) < 0.2).astype(int)}, index=dates)
        return tdf, cl

    def test_crash_mean_higher_when_signal_injected(self):
        rng = np.random.default_rng(3)
        dates = pd.bdate_range("2018-01-01", periods=100)
        crash_idx = rng.choice(100, 20, replace=False)
        vals = rng.normal(0, 1, 100)
        vals[crash_idx] += 5.0
        tdf = pd.DataFrame({"signal": vals}, index=dates)
        cl = pd.DataFrame(
            {"crash_label": [1 if i in crash_idx else 0 for i in range(100)]}, index=dates
        )
        stats = compute_summary_statistics(tdf, cl)
        row = stats[stats["feature"] == "signal"].iloc[0]
        assert row["crash_mean"] > row["normal_mean"] + 1.0

    def test_none_inputs_return_empty(self):
        tdf, cl = self._make_data()
        assert compute_summary_statistics(None, cl).empty
        assert compute_summary_statistics(tdf, None).empty
