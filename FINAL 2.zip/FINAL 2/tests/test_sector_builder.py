"""
Unit tests for sector_builder.py (Octavian Gurau-Golban).
Run with:  pytest tests/test_sector_builder.py -v
"""
import numpy as np
import pandas as pd
import pytest

from sector_builder import build_credit_ewma_matrices, build_sector_ewma_matrices, build_sector_map


def _make_returns(n_obs=150, tickers=None, seed=0):
    tickers = tickers or [f"T{i}" for i in range(8)]
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range("2018-01-01", periods=n_obs)
    return pd.DataFrame(rng.normal(0, 0.01, (n_obs, len(tickers))), index=dates, columns=tickers)


def _assignments(sector_map):
    rows = [{"ticker": t, "gics_sector": s} for s, ts in sector_map.items() for t in ts]
    return pd.DataFrame(rows)


class TestBuildSectorMap:
    def test_requires_at_least_three_tickers(self):
        returns = _make_returns(tickers=["A", "B"])
        sector_map = build_sector_map(returns, _assignments({"Small": ["A", "B"]}))
        assert "Small" not in sector_map

    def test_only_tickers_in_returns_count(self):
        returns = _make_returns(tickers=["A", "B", "C"])
        # D and E exist in assignments but not in returns, so they don't count
        sector_map = build_sector_map(returns, _assignments({"Tech": ["A", "B", "D", "E"]}))
        assert "Tech" not in sector_map  # only A and B are valid → < 3

    def test_slash_in_sector_name_replaced(self):
        returns = _make_returns(tickers=["A", "B", "C"])
        sector_map = build_sector_map(returns, _assignments({"Real/Estate": ["A", "B", "C"]}))
        assert "Real_Estate" in sector_map

    def test_sectors_with_three_or_more_tickers_included(self):
        tickers = [f"T{i}" for i in range(6)]
        returns = _make_returns(tickers=tickers)
        sector_map = build_sector_map(
            returns, _assignments({"Big": tickers[:4], "Small": tickers[4:]})
        )
        assert "Big" in sector_map
        assert "Small" not in sector_map


class TestBuildSectorEwmaMatrices:
    def test_creates_per_sector_subdirectories(self, tmp_path):
        tickers = [f"T{i}" for i in range(6)]
        returns = _make_returns(tickers=tickers)
        assignments = _assignments({"SectorA": tickers[:3], "SectorB": tickers[3:]})
        build_sector_ewma_matrices(returns, assignments, sector_dir=tmp_path,
                                   init_days=60, step_size=10)
        assert (tmp_path / "SectorA" / "correlations").exists()
        assert (tmp_path / "SectorB" / "distances").exists()

    def test_no_eligible_sector_returns_empty_dict(self, tmp_path):
        returns = _make_returns(tickers=["A", "B"])
        result = build_sector_ewma_matrices(
            returns, _assignments({"Tiny": ["A", "B"]}),
            sector_dir=tmp_path, init_days=60, step_size=5,
        )
        assert result == {}


class TestBuildCreditEwmaMatrices:
    def _prices(self, n_obs=150, seed=0):
        rng = np.random.default_rng(seed)
        dates = pd.bdate_range("2018-01-01", periods=n_obs)
        arr = 100 * np.exp(np.cumsum(rng.normal(0, 0.005, (n_obs, 4)), axis=0))
        return pd.DataFrame(arr, index=dates, columns=["LQD", "HYG", "JNK", "AGG"])

    def test_saves_npz_files(self, tmp_path):
        build_credit_ewma_matrices(self._prices(), credit_dir=tmp_path,
                                   init_days=60, step_size=10)
        assert len(list((tmp_path / "correlations").glob("*.npz"))) > 0

    def test_empty_input_returns_empty(self, tmp_path):
        assert build_credit_ewma_matrices(pd.DataFrame(), credit_dir=tmp_path).empty

    def test_single_column_returns_empty(self, tmp_path):
        prices = pd.DataFrame({"LQD": [100.0, 101.0, 99.0]})
        assert build_credit_ewma_matrices(prices, credit_dir=tmp_path).empty
