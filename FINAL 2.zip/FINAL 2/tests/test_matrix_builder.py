"""
Unit tests for matrix_builder.py (Octavian Gurau-Golban).
Run with:  pytest tests/test_matrix_builder.py -v
"""
import numpy as np
import pandas as pd
import pytest

from matrix_builder import (
    _cov_to_corr,
    build_ewma_rolling_matrices,
    check_distance_matrix,
    correlation_to_distance,
    create_distance_embedding,
)


def _make_returns(n_obs=150, n_assets=5, seed=0):
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range("2018-01-01", periods=n_obs)
    return pd.DataFrame(
        rng.normal(0, 0.01, (n_obs, n_assets)),
        index=dates,
        columns=[f"A{i}" for i in range(n_assets)],
    )


# ── Mantegna distance — known ground-truth values ─────────────────────────────

class TestCorrelationToDistance:
    def test_zero_correlation_gives_sqrt_two(self):
        D = correlation_to_distance(np.array([[1, 0], [0, 1]], dtype=float))
        assert D[0, 1] == pytest.approx(np.sqrt(2), abs=1e-8)

    def test_perfect_correlation_gives_zero(self):
        D = correlation_to_distance(np.array([[1, 1], [1, 1]], dtype=float))
        assert D[0, 1] == pytest.approx(0.0, abs=1e-8)

    def test_perfect_anticorrelation_gives_two(self):
        D = correlation_to_distance(np.array([[1, -1], [-1, 1]], dtype=float))
        assert D[0, 1] == pytest.approx(2.0, abs=1e-8)

    def test_diagonal_is_zero_and_output_symmetric(self):
        rng = np.random.default_rng(1)
        c = rng.uniform(-0.9, 0.9, (6, 6))
        corr = (c + c.T) / 2
        np.fill_diagonal(corr, 1.0)
        D = correlation_to_distance(corr)
        assert np.allclose(np.diag(D), 0.0)
        assert np.allclose(D, D.T)


# ── Validation ────────────────────────────────────────────────────────────────

class TestCheckDistanceMatrix:
    def test_valid_matrix_passes(self):
        D = correlation_to_distance(np.array([[1.0, 0.5], [0.5, 1.0]]))
        assert check_distance_matrix(D) is True

    def test_nan_raises(self):
        with pytest.raises(ValueError, match="NaN"):
            check_distance_matrix(np.array([[0, np.nan], [np.nan, 0]]))

    def test_asymmetric_raises(self):
        with pytest.raises(ValueError, match="symmetric"):
            check_distance_matrix(np.array([[0, 1.0], [0.5, 0]]))

    def test_nonzero_diagonal_raises(self):
        with pytest.raises(ValueError, match="diagonal"):
            check_distance_matrix(np.array([[0.1, 1.0], [1.0, 0.1]]))

    def test_negative_values_raise(self):
        with pytest.raises(ValueError, match="negative"):
            check_distance_matrix(np.array([[0, -0.1], [-0.1, 0]]))


# ── Covariance → correlation ──────────────────────────────────────────────────

class TestCovToCorr:
    def test_diagonal_is_ones(self):
        corr = _cov_to_corr(np.array([[4.0, 1.0], [1.0, 9.0]]))
        assert np.allclose(np.diag(corr), 1.0)

    def test_off_diagonal_matches_formula(self):
        corr = _cov_to_corr(np.array([[4.0, 1.0], [1.0, 9.0]]))
        assert corr[0, 1] == pytest.approx(1.0 / (2.0 * 3.0), abs=1e-8)

    def test_zero_variance_does_not_crash(self):
        corr = _cov_to_corr(np.zeros((3, 3)))
        assert np.all(np.isfinite(corr))


# ── EWMA matrices ─────────────────────────────────────────────────────────────

def _dirs(tmp_path, name=""):
    prefix = tmp_path / name if name else tmp_path
    c = prefix / "c"
    d = prefix / "d"
    c.mkdir(parents=True, exist_ok=True)
    d.mkdir(parents=True, exist_ok=True)
    return c, d


class TestBuildEwmaRollingMatrices:
    def test_window_count_formula(self, tmp_path):
        """floor((150 - 60) / 10) = 9 windows expected."""
        returns = _make_returns(n_obs=150)
        c, d = _dirs(tmp_path)
        meta, _ = build_ewma_rolling_matrices(returns, c, d, lam=0.94, init_days=60, step_size=10)
        assert len(meta) == (150 - 60) // 10

    def test_distance_matrices_satisfy_metric_axioms(self, tmp_path):
        """All saved distance matrices must be non-negative, symmetric, zero-diagonal."""
        c, d = _dirs(tmp_path)
        build_ewma_rolling_matrices(_make_returns(), c, d, lam=0.94, init_days=60, step_size=15)
        for f in d.glob("*.npz"):
            D = np.load(f)["matrix"]
            assert np.all(np.isfinite(D))
            assert np.allclose(D, D.T, atol=1e-5)
            assert np.allclose(np.diag(D), 0.0, atol=1e-5)
            assert D.min() >= -1e-8

    def test_raises_when_too_few_observations(self, tmp_path):
        c, d = _dirs(tmp_path)
        with pytest.raises(ValueError):
            build_ewma_rolling_matrices(_make_returns(n_obs=30), c, d,
                                        lam=0.94, init_days=60, step_size=5)

    def test_lambda_094_and_097_produce_different_matrices(self, tmp_path):
        """The two lambdas must yield numerically different distance matrices."""
        returns = _make_returns(n_obs=130, seed=7)
        for lam, name in [(0.94, "a"), (0.97, "b")]:
            c, d = _dirs(tmp_path, name)
            build_ewma_rolling_matrices(returns, c, d, lam=lam, init_days=60, step_size=20)
        files_a = sorted((tmp_path / "a" / "d").glob("*.npz"))
        files_b = sorted((tmp_path / "b" / "d").glob("*.npz"))
        n = min(len(files_a), len(files_b))
        assert n > 0
        assert any(
            not np.allclose(np.load(a)["matrix"], np.load(b)["matrix"])
            for a, b in zip(files_a, files_b)
        )

    def test_embedding_returns_empty_for_single_window(self):
        meta = pd.DataFrame({"date": ["2020-01-01"]})
        emb = create_distance_embedding(meta, [np.random.rand(9)])
        assert emb.empty
