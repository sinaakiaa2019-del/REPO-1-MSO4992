import numpy as np
import pandas as pd

from config import CRASH_DRAWDOWN_LIMIT, CRASH_LOOKAHEAD_DAYS, MAX_FORWARD_FILL_DAYS, MAX_MISSING_RATIO


def save_table(df, path_without_extension):
    """Save DataFrame as CSV; also tries Parquet if the environment supports it."""
    csv_path = path_without_extension.with_suffix(".csv")
    df.to_csv(csv_path)
    try:
        parquet_path = path_without_extension.with_suffix(".parquet")
        df.to_parquet(parquet_path)
    except Exception:
        pass


def calculate_log_returns(prices):
    """Compute daily log returns; drops rows where every column is NaN."""
    returns = np.log(prices / prices.shift(1))
    returns = returns.dropna(how="all")
    return returns


def create_missing_data_report(prices):
    """Return a per-ticker summary of missing data coverage."""
    report = pd.DataFrame({
        "first_date":    prices.apply(lambda x: x.first_valid_index()),
        "last_date":     prices.apply(lambda x: x.last_valid_index()),
        "missing_values": prices.isna().sum(),
        "missing_ratio":  prices.isna().mean(),
    })
    report.index.name = "ticker"
    return report


def clean_price_data(prices):
    """Drop globally broken tickers (>MAX_MISSING_RATIO missing) and forward-fill small gaps."""
    missing_ratio = prices.isna().mean()
    selected_assets = missing_ratio[missing_ratio <= MAX_MISSING_RATIO].index.tolist()

    cleaned_prices = prices[selected_assets].copy()
    cleaned_prices = cleaned_prices.ffill(limit=MAX_FORWARD_FILL_DAYS)
    cleaned_prices = cleaned_prices.dropna(how="all")
    return cleaned_prices


def build_baseline_features(returns, rolling_window=60):
    """Compute rolling market features: realised vol, average correlation, and eigenvalue ratio."""
    features = pd.DataFrame(index=returns.index)
    features["market_return"]    = returns.mean(axis=1)
    features["realised_vol_20d"] = features["market_return"].rolling(20).std() * np.sqrt(252)
    features["realised_vol_60d"] = features["market_return"].rolling(60).std() * np.sqrt(252)

    avg_corr_values  = []
    eigen_ratio_values = []
    feature_dates    = []

    for end_pos in range(rolling_window, len(returns)):
        window_returns = returns.iloc[end_pos - rolling_window:end_pos]
        valid_mask = window_returns.notna().mean() >= 0.80
        window_returns = window_returns.loc[:, valid_mask]

        if window_returns.shape[1] < 2:
            feature_dates.append(returns.index[end_pos - 1])
            avg_corr_values.append(np.nan)
            eigen_ratio_values.append(np.nan)
            continue

        corr = window_returns.corr().values
        upper = corr[np.triu_indices_from(corr, k=1)]
        avg_corr = np.nanmean(upper)

        try:
            eigvals = np.linalg.eigvalsh(corr)
            eigvals = np.sort(np.abs(eigvals))[::-1]
            eigen_ratio = eigvals[0] / eigvals.sum() if eigvals.sum() > 0 else np.nan
        except np.linalg.LinAlgError:
            eigen_ratio = np.nan

        feature_dates.append(returns.index[end_pos - 1])
        avg_corr_values.append(avg_corr)
        eigen_ratio_values.append(eigen_ratio)

    rolling_features = pd.DataFrame({
        "average_correlation_60d":      avg_corr_values,
        "largest_eigenvalue_ratio_60d": eigen_ratio_values,
    }, index=feature_dates)

    features = features.join(rolling_features, how="left")
    features = features.dropna()
    return features


def create_simple_crash_labels(returns):
    """Label each day 1 if the market index drops >CRASH_DRAWDOWN_LIMIT in the next CRASH_LOOKAHEAD_DAYS days.

    NOTE: `returns` are daily LOG returns (see calculate_log_returns). The market
    index is therefore reconstructed with exp(cumsum(log_returns)), NOT
    (1 + log_returns).cumprod(). The latter is a real bug -- it mixes the log-return
    convention with simple-return compounding and, at the -10% threshold used here,
    distorts the forward drawdown by ~3-4%, which is enough to flip borderline
    crash days. exp(cumsum) is the mathematically correct reconstruction for log
    returns and is exactly equal to compounding the corresponding simple returns.
    """
    market_returns = returns.mean(axis=1)
    market_index   = np.exp(market_returns.cumsum())

    labels = []
    dates  = []

    for i in range(len(market_index) - CRASH_LOOKAHEAD_DAYS):
        current_value  = market_index.iloc[i]
        future_window  = market_index.iloc[i + 1: i + 1 + CRASH_LOOKAHEAD_DAYS]
        future_drawdown = (future_window.min() / current_value) - 1
        labels.append(1 if future_drawdown <= CRASH_DRAWDOWN_LIMIT else 0)
        dates.append(market_index.index[i])

    return pd.DataFrame({"crash_label": labels}, index=dates)
