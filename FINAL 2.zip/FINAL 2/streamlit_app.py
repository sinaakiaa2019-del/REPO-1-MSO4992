"""
TDA Market Crash Prediction — Streamlit dashboard (v1, Sina Kia, Week 7).

Run with:  streamlit run streamlit_app.py

This is a READ-ONLY dashboard over the ML stage's saved outputs
(outputs/ml_reports/*.csv, outputs/figures/*.png). It does not retrain any
model on page load -- run run_ml.py / run_ml_week4..7.py first to (re)generate
the underlying reports and figures this app displays. That keeps page loads
fast and keeps "what the dashboard shows" and "what the paper cites" backed
by the exact same saved CSVs, rather than a live recomputation that could
silently drift from them.

Every synthetic-data placeholder is labelled in-app, not just in code
comments, since this is the artefact most likely to be shown to someone who
hasn't read the source.
"""

import sys
from pathlib import Path

import pandas as pd
import streamlit as st

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from ml import ml_config
from ml.live_features import LiveDataUnavailableError, fetch_live_f2_snapshot
from ml.model_persistence import load_model, score_with_saved_model

st.set_page_config(page_title="TDA Crash Prediction — Dashboard", layout="wide")


def _read_csv_if_exists(path, **kwargs):
    path = Path(path)
    if not path.exists():
        return None
    try:
        return pd.read_csv(path, **kwargs)
    except Exception as exc:
        st.warning(f"Could not read {path.name}: {exc}")
        return None


def _show_image_if_exists(path, caption=None):
    path = Path(path)
    if path.exists():
        st.image(str(path), caption=caption, width='stretch')
    else:
        st.info(f"Not generated yet: {path.name}")


def _missing_pipeline_notice():
    st.warning(
        "No ML outputs found yet. Run `python run_ml.py`, then "
        "`run_ml_week4.py` through `run_ml_week7.py`, to generate the "
        "reports and figures this dashboard reads."
    )


st.title("TDA Market Crash Prediction — Dashboard (v1)")
st.caption(
    "Sina Kia — ML & Validation stage. Figures/tables are loaded from "
    "outputs/ml_reports and outputs/figures; nothing on this page is "
    "recomputed live. Rerun the weekly scripts to refresh."
)

if not ml_config.ML_REPORT_DIR.exists() or not any(ml_config.ML_REPORT_DIR.iterdir()):
    _missing_pipeline_notice()
    st.stop()

tab_overview, tab_performance, tab_shap, tab_cross_asset, tab_live, tab_sources = st.tabs(
    ["Overview", "Model Performance", "SHAP", "Cross-Asset & Sectors", "Live", "Data Sources"]
)

# ---------------- Overview ----------------
with tab_overview:
    proba_df = _read_csv_if_exists(ml_config.OOS_PROBA_FILE, index_col=0, parse_dates=True)
    if proba_df is not None and not proba_df.empty:
        latest_date = proba_df.index[-1]
        latest_val = float(proba_df.iloc[-1, 0])

        col1, col2 = st.columns([1, 3])
        with col1:
            st.metric(
                "Latest out-of-sample P(crash)", f"{latest_val:.1%}",
                help=f"As of {latest_date.date()}. This is the model's own held-out "
                     "prediction from CV, not a live forecast for today.",
            )
            balance = _read_csv_if_exists(ml_config.CLASS_BALANCE_FILE)
            if balance is not None and not balance.empty:
                st.metric("Historical crash rate", f"{balance['positive_rate'].iloc[0]:.1%}")
        with col2:
            st.line_chart(proba_df)
    else:
        st.info("Out-of-sample probability series not found -- run run_ml_week7.py.")

    st.subheader("Reference crash verification")
    verification = _read_csv_if_exists(ml_config.ML_REPORT_DIR / "reference_crash_verification.csv")
    if verification is not None:
        st.dataframe(verification, width='stretch')

# ---------------- Model performance ----------------
with tab_performance:
    st.subheader("F1 vs F2 vs F3 AUROC")
    table = _read_csv_if_exists(ml_config.F1_VS_F2_VS_F3_TABLE_FILE)
    if table is not None:
        st.dataframe(table, width='stretch')

    st.subheader("Ablation (leave-one-feature-group-out)")
    ablation = _read_csv_if_exists(ml_config.ABLATION_TABLE_FILE)
    if ablation is not None:
        st.dataframe(ablation, width='stretch')

    st.subheader("CV robustness (fold count / initial train / purge gap)")
    robustness = _read_csv_if_exists(ml_config.CV_ROBUSTNESS_TABLE_FILE)
    if robustness is not None:
        st.dataframe(robustness, width='stretch')
        if (robustness["config"].str.contains("NO PURGE GAP")).any():
            st.caption(
                "The 'NO PURGE GAP' row is a deliberate known-bad control "
                "(see ml/cv_robustness.py), not a candidate configuration."
            )

    st.subheader("Calibration curve")
    _show_image_if_exists(ml_config.CALIBRATION_PLOT_FILE)

    st.subheader("Lead-time analysis")
    lead_times = _read_csv_if_exists(ml_config.LEAD_TIME_TABLE_FILE)
    if lead_times is not None:
        st.dataframe(lead_times, width='stretch')

# ---------------- SHAP ----------------
with tab_shap:
    st.subheader("SHAP beeswarm — F2 model")
    _show_image_if_exists(ml_config.SHAP_BEESWARM_FILE)

    st.subheader("Out-of-sample SHAP heatmap — F3 model")
    _show_image_if_exists(ml_config.SHAP_HEATMAP_F3_FILE)

    st.subheader("Dependence plots — top features")
    dep_dir = Path(ml_config.SHAP_DEPENDENCE_DIR)
    if dep_dir.exists():
        dep_files = sorted(dep_dir.glob("*.png"))
        if dep_files:
            cols = st.columns(2)
            for i, f in enumerate(dep_files):
                with cols[i % 2]:
                    st.image(str(f), width='stretch')
        else:
            st.info("No dependence plots found yet.")
    else:
        st.info("Not generated yet -- run run_ml_week7.py.")

    st.subheader("Per-crisis waterfall plots")
    waterfall_index = _read_csv_if_exists(ml_config.SHAP_WATERFALL_INDEX_FILE)
    if waterfall_index is not None:
        st.dataframe(waterfall_index, width='stretch')
        for _, row in waterfall_index.iterrows():
            if pd.notna(row.get("path")):
                st.markdown(f"**{row['crisis']}** (explained date: {row['explained_date']})")
                st.image(row["path"], width='stretch')
            else:
                st.caption(
                    f"{row['crisis']}: no out-of-sample prediction available before "
                    f"onset ({row['onset']}) -- see Week 4 notes on the initial "
                    "training block."
                )

# ---------------- Cross-asset & sectors ----------------
with tab_cross_asset:
    st.warning(
        "Everything on this tab uses SYNTHETIC placeholder data for credit, "
        "international, and per-sector topology (Kunal's real handover is not "
        "wired in yet -- see ml/cross_asset_validation.py and "
        "ml/sector_leadership.py). Treat these as pipeline demonstrations, "
        "not results."
    )

    st.subheader("Cross-asset AUROC (own model per asset class)")
    cross_asset = _read_csv_if_exists(ml_config.CROSS_ASSET_AUROC_TABLE_FILE)
    if cross_asset is not None:
        st.dataframe(cross_asset, width='stretch')

    st.subheader("International generalisation (equity-trained model, transferred)")
    transfer = _read_csv_if_exists(ml_config.INTERNATIONAL_GENERALISATION_TABLE_FILE)
    if transfer is not None:
        st.dataframe(transfer, width='stretch')

    st.subheader("Sector leadership heatmap")
    _show_image_if_exists(ml_config.SECTOR_LEADERSHIP_HEATMAP_FILE)
    sector_table = _read_csv_if_exists(ml_config.SECTOR_LEADERSHIP_TABLE_FILE)
    if sector_table is not None:
        with st.expander("Sector leadership — raw lead-time table"):
            st.dataframe(sector_table, width='stretch')

# ---------------- Live ----------------
with tab_live:
    st.warning(
        "This tab uses a reduced 3-feature 'F2-lite' model "
        "(vix, realised_vol_20d, yield_curve_slope) -- NOT the full, "
        "properly-validated F3 model used everywhere else in this dashboard. "
        "A genuinely live F3 prediction needs Kunal's real-time TDA pipeline "
        "(not built yet) and Octavian's full ~30-asset live correlation pull. "
        "Treat any number here as illustrative, not a validated forecast."
    )

    if st.button("Fetch live snapshot & score"):
        with st.spinner("Fetching VIX, SPY, and T10Y2Y..."):
            try:
                snapshot = fetch_live_f2_snapshot()
                model, metadata = load_model(ml_config.F2_LITE_MODEL_FILE)
                proba = score_with_saved_model(model, metadata, snapshot)

                col1, col2 = st.columns(2)
                with col1:
                    st.metric("Live F2-lite P(crash)", f"{proba:.1%}")
                    st.caption(f"As of {snapshot['as_of_utc']}")
                with col2:
                    st.write({k: v for k, v in snapshot.items() if k != "as_of_utc"})
                st.caption(
                    f"Model trained on {metadata['n_features']} features, "
                    f"OOS AUROC at training time: "
                    f"{metadata.get('mean_auroc_oos', float('nan')):.3f}"
                )
            except LiveDataUnavailableError as exc:
                st.error(
                    f"Live data unavailable: {exc}\n\n"
                    "This is expected in network-restricted environments. "
                    "Check your internet connection, or that yfinance / "
                    "pandas_datareader can reach Yahoo Finance and FRED."
                )
            except FileNotFoundError as exc:
                st.error(f"{exc}")

# ---------------- Data sources ----------------
with tab_sources:
    st.markdown(
        """
### What's real vs synthetic right now

| Component | Status |
|---|---|
| Equity returns, crash labels | Synthetic fallback unless `data/processed/returns.csv` is dropped in |
| F2 standard features (equity) | Synthetic unless `macro_features.csv` / `baseline_features.csv` present |
| F1 topology (equity) | Synthetic Betti curve unless Kunal's `betti_curves.npz` / `topology_features.csv` present |
| Credit / international F1, F2 | Always synthetic today (no real handover yet) |
| Per-sector F1 | Always synthetic today, with an explicitly arbitrary lead-time bias per sector |

Every run prints which source was actually used for each piece — check the
`run_ml*.py` console output, not just this table, before citing a number.
"""
    )
