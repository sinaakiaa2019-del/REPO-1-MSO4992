"""
Week 5 — International equity EWMA matrices.

International ETF downloads were removed from the pipeline (user decision —
no ETFs). This module is kept as a stub so imports don't break if referenced.
To add international coverage, pass a DataFrame of international prices to
build_international_ewma_matrices() directly.
"""
import pandas as pd

from config import (
    END_DATE, EWMA_INIT_DAYS, EWMA_LAMBDA,
    INTERNATIONAL_DIR, START_DATE, STEP_SIZE,
)
from data_processing import calculate_log_returns, clean_price_data
from matrix_builder import build_ewma_rolling_matrices


def build_international_ewma_matrices(
    start_date=START_DATE,
    end_date=END_DATE,
    international_dir=INTERNATIONAL_DIR,
    lam=EWMA_LAMBDA,
    init_days=EWMA_INIT_DAYS,
    step_size=STEP_SIZE,
):
    """
    Download international ETF prices and produce EWMA distance matrices.

    ETFs used as proxies:
        FEZ  EuroStoxx 50       VGK  Europe Broad
        EWG  Germany            EWQ  France
        EWU  UK                 EWJ  Japan
        EWH  Hong Kong          FXI  China
        EWZ  Brazil             EWC  Canada
        EWA  Australia

    Returns (metadata_df, returns_df). Saves matrices under international_dir.
    """
    print("  International ETF download removed — pass prices DataFrame directly.")
    return pd.DataFrame(), pd.DataFrame()

    # Dead code below retained for reference. To re-enable, pass a prices
    # DataFrame of international tickers and remove the early return above.
    prices = pd.DataFrame()
    if prices.empty:
        return pd.DataFrame(), pd.DataFrame()

    cleaned = clean_price_data(prices)
    returns = calculate_log_returns(cleaned)

    international_dir.mkdir(parents=True, exist_ok=True)
    returns.to_csv(international_dir / "international_returns.csv")

    corr_dir = international_dir / "correlations"
    dist_dir = international_dir / "distances"
    corr_dir.mkdir(parents=True, exist_ok=True)
    dist_dir.mkdir(parents=True, exist_ok=True)

    try:
        meta, embedding = build_ewma_rolling_matrices(
            returns, corr_dir, dist_dir,
            lam=lam, init_days=init_days, step_size=step_size,
        )
        meta.to_csv(international_dir / "international_metadata.csv", index=False)
        embedding.to_csv(international_dir / "international_embedding.csv", index=False)
        print(f"  International: {len(meta)} windows saved.")
        return meta, returns
    except Exception as exc:
        print(f"  International matrix build failed: {exc}")
        return pd.DataFrame(), returns
