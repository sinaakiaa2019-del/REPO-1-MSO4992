"""
TDA figures (Kunal Jha) -- Week 3 deliverable.

Plots H1 Betti curves for representative windows so the team can sanity
check that the shapes match the theory in the Concepts Reference (section
10): the curve should rise from 0, peak at some intermediate epsilon, and
fall back to 0 once enough triangles have filled every loop.

The plan's exact spec is three NAMED epochs: calm (2014-2016), 2008
pre-crash, 2020 COVID. On whatever data this is actually run against right
now -- the 11-ETF universe, possibly in --demo mode with generated prices --
those specific historical windows may not exist, or may not be especially
calm/turbulent. So this picks the windows with the lowest, median, and
highest average pairwise correlation instead (a data-driven stand-in for
"calm vs. stressed"), and labels them as such rather than pretending they are
the literal named historical epochs. Once the pipeline is run on real,
full-history market data, pass `average_correlation=None` and instead select
by the actual 2008/2020 dates for the real paper figure.
"""

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from tda.tda_config import EPSILON_GRID, FIGURE_DIR


def plot_betti_curves(betti_array, dates, average_correlation=None, output_path=None):
    """
    Plot H1 Betti curves for the lowest-, median-, and highest-correlation
    windows in the batch.

    Parameters
    ----------
    betti_array : np.ndarray, shape (n_windows, n_epsilon, 2)
    dates : array-like of date strings, shape (n_windows,)
    average_correlation : array-like or None
        Used to rank windows as calm/median/stressed. If None, falls back to
        the H1 curve's L2 norm as a stress proxy.
    output_path : Path or None
    """
    n_windows = betti_array.shape[0]
    if average_correlation is None:
        average_correlation = np.linalg.norm(betti_array[:, :, 1], axis=1)
    average_correlation = np.asarray(average_correlation, dtype=float)

    order = np.argsort(np.nan_to_num(average_correlation, nan=-np.inf))
    picks = {
        "lowest-correlation window (calm-market proxy)": order[0],
        "median-correlation window": order[len(order) // 2],
        "highest-correlation window (stressed-market proxy)": order[-1],
    }

    fig, ax = plt.subplots(figsize=(8, 5))
    for label, idx in picks.items():
        ax.plot(EPSILON_GRID, betti_array[idx, :, 1], label=f"{label}\n({dates[idx]})")

    ax.set_xlabel(r"Filtration scale $\epsilon$")
    ax.set_ylabel(r"$\beta_1(\epsilon)$  (number of contagion loops)")
    ax.set_title("H1 Betti curves: calm vs. stressed correlation regimes\n"
                  "(data-driven proxy -- replace with named 2008/2020 epochs on real data)")
    ax.legend(fontsize=8)
    fig.tight_layout()

    output_path = output_path or (FIGURE_DIR / "betti_curves_h1_example_epochs.png")
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return output_path


def plot_wasserstein_velocity(velocity_series, output_path=None, n_std=2.0):
    """Plot the Wasserstein velocity time series with its rolling 2-sigma
    early-warning band (Concepts Reference section 12)."""
    rolling_mean = velocity_series.rolling(20, min_periods=20).mean()
    rolling_std = velocity_series.rolling(20, min_periods=20).std()
    threshold = rolling_mean + n_std * rolling_std

    fig, ax = plt.subplots(figsize=(9, 4))
    ax.plot(velocity_series.index, velocity_series.values, label="Wasserstein velocity", lw=1)
    ax.plot(threshold.index, threshold.values, label=f"rolling mean + {n_std}\u03c3", ls="--", lw=1)
    ax.set_xlabel("Date")
    ax.set_ylabel(r"$W_2(D(t), D(t-1))$")
    ax.set_title("Wasserstein velocity (H1) -- parameter-free early-warning signal")
    ax.legend(fontsize=8)
    fig.tight_layout()

    output_path = output_path or (FIGURE_DIR / "wasserstein_velocity.png")
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return output_path
