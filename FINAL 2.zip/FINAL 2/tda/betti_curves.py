"""
Betti curve computation and diagram-level summary statistics (Kunal Jha).

beta_d(epsilon) = number of d-dimensional features alive at filtration
parameter epsilon (Concepts Reference, section 10). Vectorised over a fixed
epsilon grid so every rolling window produces a feature vector of the same
length regardless of how many points (assets) or features that window had.
"""

import numpy as np

from tda.tda_config import EPSILON_GRID


def betti_curve(dgm, epsilon_grid=EPSILON_GRID):
    """
    Vectorised Betti curve for one persistence diagram (one dimension).

    Parameters
    ----------
    dgm : np.ndarray, shape (n_features, 2)
        Birth-death pairs with finite deaths (see
        persistence.compute_persistence, which caps infinite deaths at the
        filtration threshold).
    epsilon_grid : np.ndarray, shape (n_epsilon,)

    Returns
    -------
    np.ndarray, shape (n_epsilon,): beta_d(epsilon) at each grid point.
    """
    epsilon_grid = np.asarray(epsilon_grid)
    if dgm.size == 0:
        return np.zeros(len(epsilon_grid))

    birth = dgm[:, 0][:, None]   # (n_features, 1)
    death = dgm[:, 1][:, None]   # (n_features, 1)
    eps = epsilon_grid[None, :]  # (1, n_epsilon)

    alive = (birth <= eps) & (eps < death)  # (n_features, n_epsilon)
    return alive.sum(axis=0).astype(float)


def betti_curves_for_window(dgms, epsilon_grid=EPSILON_GRID):
    """
    Stack H0 and H1 Betti curves for one window into a (n_epsilon, 2) array,
    matching the (n_windows, n_epsilon, 2) handover format
    ml/f1_topology_features.py expects ([..., 0] = H0, [..., 1] = H1).
    """
    h0 = betti_curve(dgms[0], epsilon_grid)
    h1 = betti_curve(dgms[1], epsilon_grid) if len(dgms) > 1 else np.zeros(len(epsilon_grid))
    return np.stack([h0, h1], axis=1)


def persistence_entropy(dgm):
    """
    Shannon entropy of the normalised lifetime distribution of a diagram.
    Low entropy = a few features dominate (calm market, simple structure);
    high entropy = many comparably-persistent features (richer, busier
    correlation network) -- see Concepts Reference glossary and Week 8 plan
    ("compute persistence entropy time series and overlay with VIX").
    """
    if dgm.size == 0:
        return 0.0
    lifetimes = dgm[:, 1] - dgm[:, 0]
    lifetimes = lifetimes[lifetimes > 0]
    if lifetimes.size == 0:
        return 0.0
    p = lifetimes / lifetimes.sum()
    return float(-(p * np.log(p)).sum())


def max_persistence(dgm):
    """Longest lifetime (d - b) in a diagram; 0.0 for an empty diagram."""
    if dgm.size == 0:
        return 0.0
    return float((dgm[:, 1] - dgm[:, 0]).max())


def total_persistence(dgm):
    """Sum of all lifetimes in a diagram (0.0 for an empty diagram)."""
    if dgm.size == 0:
        return 0.0
    return float((dgm[:, 1] - dgm[:, 0]).sum())


def betti_curve_l2_norm(curve):
    """
    L2 norm of a Betti curve sampled on the epsilon grid -- the single
    scalar crash indicator Gidea & Katz (2018) used. Kept here so the Week 8
    plan task ("replicate their L2 norm of Betti curve scalar, compare AUROC
    to our full pipeline") has a ready-made, correctly-defined baseline
    rather than an ad hoc reimplementation done later under time pressure.
    """
    curve = np.asarray(curve, dtype=float)
    return float(np.sqrt(np.sum(curve ** 2)))
