"""
Crisis proximity metric + entropy-vs-VIX overlay (Kunal Jha) -- Weeks 7-8
deliverables that were missing from the first Weeks 4-8 pass.

topological_distance_to_crisis (Week 7, plan: "compute Wasserstein distance to
the median persistence diagram of confirmed crash periods"):
    A true Frechet MEAN/median of persistence diagrams is a research problem in
    its own right (it requires solving an optimal-transport barycentre and is
    not unique). Rather than implement a fragile approximation and call it "the
    median diagram", this computes, for every window, the MEDIAN of the
    Wasserstein distances to each confirmed crash-window diagram -- i.e. the
    distance to the crash SET under the median aggregator. This is
    well-defined, cheap, and has the same interpretation the plan wants: LOW
    values mean "today's correlation topology looks like crash topology".
    The methodological substitution is documented here and should be stated in
    the paper's methods section in one sentence.

entropy_vix_overlay (Week 8, plan: "compute persistence entropy time series and
overlay with VIX; quantify the correlation"):
    Dual-axis plot of H1 persistence entropy vs VIX with the Pearson and
    Spearman correlations printed in the title. Uses whichever VIX source is
    available (macro_features.csv or market_indicators.csv).
"""

from __future__ import annotations

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from tda.tda_config import FIGURE_DIR
from tda.wasserstein import wasserstein_distance


def topological_distance_to_crisis(diagrams_by_date, crash_labels, dim=1,
                                   max_crash_refs=15):
    """
    For every window, the median Wasserstein distance from its H_dim diagram to
    the diagrams of confirmed crash windows.

    Parameters
    ----------
    diagrams_by_date : list of (date, dgms) from the Weeks 1-3 pipeline.
    crash_labels     : DataFrame with 'crash_label' (daily index) or Series.
    dim              : homology dimension (1 = loops).
    max_crash_refs   : cap on reference crash diagrams (evenly subsampled) so
                       the O(n_windows * n_refs) distance computation stays
                       cheap on 1,000+ windows.

    Returns
    -------
    pd.Series 'crisis_proximity' indexed by window date (LOW = crash-like), or
    an empty Series if no crash windows exist in the sample.
    """
    if isinstance(crash_labels, pd.DataFrame):
        labels = crash_labels["crash_label"]
    else:
        labels = pd.Series(crash_labels)
    labels.index = pd.to_datetime(labels.index)

    dates = pd.to_datetime([str(d) for d, _ in diagrams_by_date])
    aligned = labels.reindex(dates, method="nearest",
                             tolerance=pd.Timedelta("5D")).fillna(0).astype(int).values

    crash_idx = np.where(aligned == 1)[0]
    if len(crash_idx) == 0:
        return pd.Series(dtype=float, name="crisis_proximity")
    if len(crash_idx) > max_crash_refs:
        crash_idx = crash_idx[np.linspace(0, len(crash_idx) - 1, max_crash_refs).astype(int)]

    ref_dgms = [diagrams_by_date[i][1][dim] for i in crash_idx]

    values = []
    for _, dgms in diagrams_by_date:
        d = dgms[dim]
        dists = [wasserstein_distance(d, ref) for ref in ref_dgms]
        values.append(float(np.median(dists)))

    return pd.Series(values, index=dates, name="crisis_proximity")


def plot_crisis_proximity(proximity, crash_labels, output_path=None):
    """Time-series plot of the crisis-proximity metric with crash windows shaded."""
    if isinstance(crash_labels, pd.DataFrame):
        labels = crash_labels["crash_label"]
    else:
        labels = pd.Series(crash_labels)
    labels.index = pd.to_datetime(labels.index)

    fig, ax = plt.subplots(figsize=(9, 4))
    ax.plot(proximity.index, proximity.values, lw=1, color="#2c5f8a",
            label="median W2 distance to crash diagrams")
    crash_dates = labels.index[labels.astype(int) == 1]
    for d in crash_dates:
        ax.axvline(d, color="#d62728", alpha=0.08)
    ax.set_ylabel("Crisis proximity (lower = crash-like topology)")
    ax.set_title("Topological distance to crisis (Week 7 novel metric)")
    ax.legend(fontsize=8)
    fig.tight_layout()
    output_path = output_path or (FIGURE_DIR / "crisis_proximity.png")
    FIGURE_DIR.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return output_path


def entropy_vix_overlay(topology_features, vix_series, output_path=None):
    """
    Dual-axis overlay of H1 persistence entropy vs VIX with correlation stats.

    Returns (output_path, stats_dict) where stats has pearson/spearman corr and
    n_common. VIX is aligned to window dates by nearest-date within 5 days.
    """
    tf = topology_features.copy()
    tf.index = pd.to_datetime(tf.index)
    if "h1_persistence_entropy" not in tf.columns:
        raise ValueError("topology_features lacks 'h1_persistence_entropy'.")
    ent = tf["h1_persistence_entropy"]

    vix = vix_series.dropna().copy()
    vix.index = pd.to_datetime(vix.index)
    vix_aligned = vix.reindex(ent.index, method="nearest", tolerance=pd.Timedelta("5D"))

    common = ent.notna() & vix_aligned.notna()
    stats = {"n_common": int(common.sum()), "pearson": np.nan, "spearman": np.nan}
    if common.sum() >= 10:
        stats["pearson"] = float(ent[common].corr(vix_aligned[common], method="pearson"))
        stats["spearman"] = float(ent[common].corr(vix_aligned[common], method="spearman"))

    fig, ax1 = plt.subplots(figsize=(9, 4))
    ax1.plot(ent.index, ent.values, color="#2c5f8a", lw=1, label="H1 persistence entropy")
    ax1.set_ylabel("Persistence entropy", color="#2c5f8a")
    ax2 = ax1.twinx()
    ax2.plot(vix_aligned.index, vix_aligned.values, color="#d62728", lw=1, alpha=0.8,
             label="VIX (aligned)")
    ax2.set_ylabel("VIX", color="#d62728")
    ax1.set_title(f"Persistence entropy vs VIX  "
                  f"(pearson={stats['pearson']:.2f}, spearman={stats['spearman']:.2f}, "
                  f"n={stats['n_common']})")
    fig.tight_layout()
    output_path = output_path or (FIGURE_DIR / "entropy_vs_vix.png")
    FIGURE_DIR.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return output_path, stats
