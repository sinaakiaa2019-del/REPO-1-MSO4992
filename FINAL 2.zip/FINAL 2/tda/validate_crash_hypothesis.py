"""
Synthetic validation of the project's core hypothesis (Kunal Jha).

The Concepts Reference (section 13) and the 11-Week Plan's Week 5
"Theoretical Motivation" task both claim that beta_1 (the number of
1-dimensional loops / "contagion rings") should SPIKE as a market
approaches a crash, because "sector A infects sector B infects sector C
infects sector A" creates circular dependency chains.

Before trusting that signal on real data, this script stress-tests the claim
against two different synthetic mechanisms for "correlations going up":

  Mechanism 1 -- UNIFORM SURGE: every pairwise correlation rises together
      (one common factor crowds out sector-specific factors). This is the
      naive reading of "everything becomes correlated to everything."

  Mechanism 2 -- RING SURGE: correlation rises only between ADJACENT sectors
      in a cycle (A-B, B-C, C-D, D-A), while opposite sectors (A-C, B-D)
      stay uncorrelated -- i.e. an actual contagion *ring*, structurally
      identical to the 4-point-square example in tda/tests/test_persistence.py.

Result (see main() output): Mechanism 1 does NOT reproduce a beta_1 spike --
in this simulation, max H1 persistence *falls* monotonically as the uniform
correlation level rises from ~0.11 to ~0.89 mean pairwise correlation.
Mechanism 2 produces a clearly dominant, persistent loop (roughly 5-10x the
max persistence of any uniform-correlation scenario tested at a comparable
average correlation level).

Practical implication for the team: do not assume "average correlation went
up" is sufficient for the topological signal to fire. The mechanism the
Concepts Reference actually describes is asymmetric, cyclic inter-sector
correlation, not a uniform level shift. Worth checking directly on real data
(e.g. via the sector-level correlation heatmaps already planned for Week 7)
before reporting beta_1 as a crash indicator without this caveat.

Run from the project root:  python -m tda.validate_crash_hypothesis
"""

import numpy as np
import pandas as pd

from tda.figures import FIGURE_DIR
from tda.run_tda import compute_window
from tda.tda_config import EPSILON_GRID


def _to_distance(corr):
    d = np.sqrt(np.clip(2 * (1 - corr), 0, None))
    np.fill_diagonal(d, 0.0)
    return d


def simulate_uniform_surge_correlation(
    n_assets=30, n_sectors=3, n_obs=400, common_loading=0.05, sector_loading=0.6, seed=1
):
    """Mechanism 1: a single common factor whose loading increases, crowding
    out sector-specific factors. Produces a uniform rise in average pairwise
    correlation with no asymmetric/cyclic structure."""
    rng = np.random.default_rng(seed)
    market = rng.normal(size=n_obs)
    sector_factors = rng.normal(size=(n_sectors, n_obs))
    per_sector = n_assets // n_sectors
    idio_loading = np.sqrt(max(1e-6, 1 - common_loading ** 2 - sector_loading ** 2))

    returns = np.zeros((n_obs, n_assets))
    for i in range(n_assets):
        s = min(i // per_sector, n_sectors - 1)
        idio = rng.normal(size=n_obs)
        returns[:, i] = (
            common_loading * market + sector_loading * sector_factors[s] + idio_loading * idio
        )
    return np.corrcoef(returns.T)


def simulate_ring_surge_correlation(
    n_per_block=8, n_obs=400, ring_corr=0.55, within_block=0.6, seed=2
):
    """Mechanism 2: four sector blocks arranged in a cycle A-B-C-D-A.
    Adjacent blocks are correlated (a shared 'edge factor'); opposite
    (diagonal) blocks are not. This is a genuine block-level 4-cycle -- the
    financial analogue of "A infects B infects C infects D infects A" without
    a direct A-C or B-D short-circuit."""
    rng = np.random.default_rng(seed)
    n_blocks = 4
    n_assets = n_per_block * n_blocks
    edge_factors = rng.normal(size=(n_blocks, n_obs))  # edge k shared by blocks k, k+1
    block_idio_factor = rng.normal(size=(n_blocks, n_obs))
    loading = np.sqrt(max(0.0, 1 - 2 * ring_corr ** 2 - within_block ** 2))

    returns = np.zeros((n_obs, n_assets))
    for b in range(n_blocks):
        prev_edge = edge_factors[(b - 1) % n_blocks]
        next_edge = edge_factors[b]
        for j in range(n_per_block):
            idio = rng.normal(size=n_obs)
            returns[:, b * n_per_block + j] = (
                ring_corr * prev_edge + ring_corr * next_edge
                + within_block * block_idio_factor[b] + loading * idio
            )
    return np.corrcoef(returns.T)


def mean_off_diagonal(corr):
    n = len(corr)
    return float((corr.sum() - n) / (n ** 2 - n))


def run_uniform_surge_sweep(common_loadings=(0.05, 0.2, 0.35, 0.5, 0.6, 0.7, 0.85, 0.95)):
    rows = []
    for common in common_loadings:
        sector = max(0.0, 0.6 - 0.5 * common)  # sector structure erodes as common factor rises
        corr = simulate_uniform_surge_correlation(common_loading=common, sector_loading=sector)
        d = _to_distance(corr)
        dgms, curves, summary, _ = compute_window(d)
        rows.append({
            "common_loading": common,
            "mean_correlation": mean_off_diagonal(corr),
            "h1_n_features": summary["h1_n_features"],
            "h1_max_persistence": summary["h1_max_persistence"],
            "h1_total_persistence": summary["h1_total_persistence"],
            "beta1_peak": curves[:, 1].max(),
        })
    return pd.DataFrame(rows)


def run_ring_surge_example(ring_corr=0.55):
    corr = simulate_ring_surge_correlation(ring_corr=ring_corr)
    d = _to_distance(corr)
    dgms, curves, summary, _ = compute_window(d)
    return {
        "mean_correlation": mean_off_diagonal(corr),
        **summary,
        "beta1_peak": float(curves[:, 1].max()),
    }, curves


def main():
    print("Mechanism 1: UNIFORM correlation surge (single common factor)")
    print("-" * 70)
    sweep = run_uniform_surge_sweep()
    print(sweep.to_string(index=False))
    print()
    print("  -> h1_max_persistence DECREASES as mean correlation rises "
          f"({sweep['h1_max_persistence'].iloc[0]:.4f} at "
          f"corr={sweep['mean_correlation'].iloc[0]:.2f} down to "
          f"{sweep['h1_max_persistence'].iloc[-1]:.4f} at "
          f"corr={sweep['mean_correlation'].iloc[-1]:.2f}).")
    print("     A uniform correlation surge does NOT, by itself, produce a "
          "beta_1 spike in this simulation.\n")

    print("Mechanism 2: RING correlation surge (4-block contagion cycle)")
    print("-" * 70)
    ring_summary, ring_curves = run_ring_surge_example()
    for k, v in ring_summary.items():
        print(f"  {k}: {v}")
    comparable_row = sweep.iloc[(sweep["mean_correlation"] - ring_summary["mean_correlation"]).abs().idxmin()]
    ratio = ring_summary["h1_max_persistence"] / max(comparable_row["h1_max_persistence"], 1e-9)
    print(f"\n  -> At a comparable mean correlation (~{ring_summary['mean_correlation']:.2f}), "
          f"the ring structure's h1_max_persistence is {ratio:.1f}x the uniform-surge "
          f"scenario's ({comparable_row['h1_max_persistence']:.4f} at "
          f"common_loading={comparable_row['common_loading']:.2f}).")
    print("     A genuinely cyclic/asymmetric correlation surge DOES produce a "
          "much stronger, more persistent loop -- matching the Concepts "
          "Reference's own stated mechanism ('A infects B infects C infects A'), "
          "which is NOT the same thing as 'correlations went up.'\n")

    FIGURE_DIR.mkdir(parents=True, exist_ok=True)
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        fig, ax = plt.subplots(figsize=(8, 5))
        ax.plot(EPSILON_GRID, ring_curves[:, 1], label="ring surge (4-block contagion cycle)", lw=2)
        ax.set_xlabel(r"Filtration scale $\epsilon$")
        ax.set_ylabel(r"$\beta_1(\epsilon)$")
        ax.set_title("H1 Betti curve under a genuine contagion-ring correlation structure")
        ax.legend()
        fig.tight_layout()
        out_path = FIGURE_DIR / "crash_hypothesis_ring_vs_uniform.png"
        fig.savefig(out_path, dpi=150)
        plt.close(fig)
        print(f"Figure saved: {out_path}")
    except Exception as exc:  # pragma: no cover
        print(f"(figure generation skipped: {exc})")

    return sweep, ring_summary


if __name__ == "__main__":
    main()
