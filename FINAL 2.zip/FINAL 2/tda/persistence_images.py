"""
Persistence images (Kunal Jha) -- Adams et al. (2017).

Stable vectorisation of a persistence diagram into a fixed-length numeric
array: (1) move to birth-persistence coordinates, (2) weight each point by
its persistence (lifetime), (3) replace each point with a 2D Gaussian,
(4) evaluate the resulting surface on a pixel grid.

Implemented directly from the four-step recipe in the Concepts Reference
(section 11) rather than via a third-party PersistenceImager, so every
hyperparameter (sigma, grid bounds, weighting function) is explicit and
matches the plan's spec exactly (20x20 grid = 400 dimensions).
"""

import numpy as np

from tda.tda_config import (
    PERSISTENCE_IMAGE_SIGMA,
    PI_BIRTH_RANGE,
    PI_PERSISTENCE_RANGE,
    PIXEL_GRID_SIZE,
)


def _to_birth_persistence(dgm):
    """Step 1: (birth, death) -> (birth, persistence = death - birth)."""
    if dgm.size == 0:
        return np.empty((0, 2))
    birth = dgm[:, 0]
    persistence = dgm[:, 1] - dgm[:, 0]
    return np.stack([birth, persistence], axis=1)


def _weight(persistence, max_persistence):
    """
    Step 2: weight w(b, d) = (d - b), i.e. the weight is the persistence
    itself, linearly ramped from 0. Near-diagonal (low-persistence / noisy)
    points get near-zero weight; long-lived points get the most weight.
    Clipped at max_persistence so the weighting stays well-defined even if
    one feature's lifetime dominates the rest of the diagram.
    """
    if max_persistence <= 0:
        return np.zeros_like(persistence)
    return np.clip(persistence, 0, max_persistence)


def persistence_image(
    dgm,
    grid_size=PIXEL_GRID_SIZE,
    sigma=PERSISTENCE_IMAGE_SIGMA,
    birth_range=PI_BIRTH_RANGE,
    persistence_range=PI_PERSISTENCE_RANGE,
):
    """
    Build one persistence image from one persistence diagram.

    Returns
    -------
    np.ndarray, shape (grid_size, grid_size). Flatten with .ravel() for the
    (grid_size**2,)-dim feature vector (400-dim for the plan's 20x20 grid).
    """
    bp = _to_birth_persistence(dgm)
    b_lo, b_hi = birth_range
    p_lo, p_hi = persistence_range

    b_centers = np.linspace(b_lo, b_hi, grid_size)
    p_centers = np.linspace(p_lo, p_hi, grid_size)
    b_grid, p_grid = np.meshgrid(b_centers, p_centers)  # both (grid_size, grid_size)

    if bp.shape[0] == 0:
        return np.zeros((grid_size, grid_size))

    weights = _weight(bp[:, 1], max_persistence=p_hi)

    image = np.zeros((grid_size, grid_size))
    two_sigma_sq = 2 * sigma ** 2
    norm = 1.0 / (2 * np.pi * sigma ** 2)
    for (b, p), w in zip(bp, weights):
        if w <= 0:
            continue
        gaussian = norm * np.exp(-((b_grid - b) ** 2 + (p_grid - p) ** 2) / two_sigma_sq)
        image += w * gaussian

    return image


def persistence_image_vector(dgm, **kwargs):
    """Flattened persistence image, e.g. 400-dim for a 20x20 grid."""
    return persistence_image(dgm, **kwargs).ravel()
