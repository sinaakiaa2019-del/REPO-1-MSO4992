"""
TDA configuration (Kunal Jha).

Single source of truth for the persistent-homology stage: which distance
matrices to read (Octavian's window_metadata.csv / distances/ folder), the
filtration grid, the persistence-image hyperparameters, and where every
output handover artefact is written.

All paths come from the shared project config.py -- the same file
ml/ml_config.py imports from -- so Kunal's outputs land exactly where
ml/f1_topology_features.py expects to find them. This file used to not exist
at all (no TDA code had been delivered); the previous integration review
found that Sina's ML stage was therefore only ever exercised against
synthetic Betti curves, never a real ripser run.
"""

from pathlib import Path

import numpy as np

import config as data_config

# ============================================================
# INPUT (produced by Octavian's run_pipeline.py)
# ============================================================
METADATA_FILE = data_config.METADATA_FILE
DISTANCE_DIR = data_config.DISTANCE_DIR

# ============================================================
# OUTPUT (consumed by ml/f1_topology_features.py)
# ============================================================
TDA_DIR = data_config.TDA_DIR
BETTI_CURVE_FILE = data_config.BETTI_CURVE_FILE
PERSISTENCE_IMAGE_FILE = data_config.PERSISTENCE_IMAGE_FILE
PERSISTENCE_DIAGRAM_FILE = data_config.PERSISTENCE_DIAGRAM_FILE
TOPOLOGY_FEATURES_FILE = data_config.TOPOLOGY_FEATURES_FILE
WASSERSTEIN_VELOCITY_FILE = data_config.WASSERSTEIN_VELOCITY_FILE
FIGURE_DIR = data_config.FIGURE_DIR

# ============================================================
# FILTRATION SETTINGS
# ============================================================
# Mantegna distances range over [0, sqrt(2)] (Concepts Reference, sections 5
# and 7). The filtration sweeps this full range by default.
MAX_EPSILON = float(np.sqrt(2))
N_EPSILON = 200  # grid resolution for Betti curves (plan spec, section 10)
EPSILON_GRID = np.linspace(0.0, MAX_EPSILON, N_EPSILON)

# Homology dimensions computed by the Weeks 1-3 batch run. H2 (voids) is an
# explicit Week 6 task in the 11-Week Plan and is far more expensive (the
# number of 3-simplices ripser has to consider grows combinatorially with
# the number of assets) -- deliberately out of scope here. persistence.py
# can still compute H2 on demand (see tda/tests/test_persistence.py), this
# constant only controls what run_tda.py computes by default.
MAX_HOMOLOGY_DIM = 1

# ============================================================
# PERSISTENCE IMAGE SETTINGS (Adams et al. 2017)
# ============================================================
PIXEL_GRID_SIZE = 20  # 20x20 = 400-dim image (plan spec, section 11)
PERSISTENCE_IMAGE_SIGMA = 0.05  # Gaussian kernel bandwidth, in distance units
# Birth/persistence plane bounds for the pixel grid.
PI_BIRTH_RANGE = (0.0, MAX_EPSILON)
PI_PERSISTENCE_RANGE = (0.0, MAX_EPSILON)

RANDOM_STATE = 42


def ensure_output_dirs():
    """Create the TDA output folders if they do not exist yet."""
    TDA_DIR.mkdir(parents=True, exist_ok=True)
    FIGURE_DIR.mkdir(parents=True, exist_ok=True)
