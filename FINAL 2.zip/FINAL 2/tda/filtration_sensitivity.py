"""
Filtration sensitivity analysis (Kunal Jha) -- Week 4, RQ2.

RQ2 asks: at which filtration scale epsilon is the topological crash signal
strongest? Rather than feeding the whole Betti curve to a model and reading it
back out of SHAP (which the ML stage also does), this computes a DIRECT,
model-free answer: for each epsilon on a grid, take the single-scale Betti
number beta_1(epsilon) for every window, and measure how well that one scalar
separates crash windows from calm windows (AUROC vs the crash label).

The epsilon whose beta_1(epsilon) has the highest AUROC is the most predictive
scale. The literature (and the project's Concepts Reference) predicts this
peaks near epsilon ~ 0.894, i.e. the Mantegna distance corresponding to a
Pearson correlation of rho = 0.6 -- the classic "high correlation" threshold.

This is a pure-topology, no-machine-learning result, which makes it a clean,
defensible answer to RQ2 that does not depend on any XGBoost hyperparameter.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from tda.betti_curves import betti_curve
from tda.tda_config import EPSILON_GRID


def mantegna_distance_to_correlation(epsilon):
    """Invert the Mantegna metric D = sqrt(2(1-rho)) -> rho = 1 - D^2/2."""
    return 1.0 - (np.asarray(epsilon, dtype=float) ** 2) / 2.0


def single_scale_betti_matrix(betti_array, epsilon_grid=EPSILON_GRID, dim=1):
    """
    Extract beta_dim(epsilon) for every window as a (n_windows, n_epsilon) matrix.

    betti_array : (n_windows, n_epsilon, 2) as saved by tda/run_tda.py.
    Returns the slice for the requested homology dimension (0 or 1).
    """
    betti_array = np.asarray(betti_array)
    if betti_array.ndim != 3:
        raise ValueError("betti_array must be (n_windows, n_epsilon, 2).")
    return betti_array[:, :, dim]


def filtration_sensitivity(betti_array, dates, crash_labels, dim=1,
                           epsilon_grid=EPSILON_GRID):
    """
    Compute AUROC of single-scale beta_dim(epsilon) vs the crash label, per epsilon.

    Parameters
    ----------
    betti_array : (n_windows, n_epsilon, 2) Betti curve array.
    dates       : array-like of window dates aligned to betti_array rows.
    crash_labels: pd.DataFrame/Series with a DatetimeIndex and a 'crash_label'
                  column (or a plain 0/1 Series), used to label each window.
    dim         : homology dimension (1 = loops, the crash-relevant one).

    Returns
    -------
    pd.DataFrame indexed by epsilon with columns:
        epsilon, implied_rho, auroc, n_windows, n_crash
    plus attrs['best_epsilon'] / attrs['best_rho'] / attrs['best_auroc'].
    """
    from sklearn.metrics import roc_auc_score

    betti_slice = single_scale_betti_matrix(betti_array, epsilon_grid, dim=dim)
    dates = pd.to_datetime([str(d) for d in dates])

    if isinstance(crash_labels, pd.DataFrame):
        label_series = crash_labels["crash_label"]
    else:
        label_series = pd.Series(crash_labels)
    label_series.index = pd.to_datetime(label_series.index)

    # Align each window date to the nearest available label (labels are daily;
    # windows sit on the 5-day step grid, so an exact match may not exist).
    aligned_labels = label_series.reindex(dates, method="nearest", tolerance=pd.Timedelta("5D"))
    valid = ~aligned_labels.isna()
    y = aligned_labels[valid].astype(int).values
    X = betti_slice[valid.values]

    n_crash = int(y.sum())
    rows = []
    for j, eps in enumerate(epsilon_grid):
        col = X[:, j]
        if len(np.unique(y)) < 2 or np.allclose(col, col[0]):
            auroc = np.nan
        else:
            # beta_1 is hypothesised to be HIGHER pre-crash, but sign is data
            # dependent; report the orientation-invariant max(AUROC, 1-AUROC)
            # so a strong negative association is not reported as ~0.
            raw = roc_auc_score(y, col)
            auroc = max(raw, 1 - raw)
        rows.append({
            "epsilon": float(eps),
            "implied_rho": float(mantegna_distance_to_correlation(eps)),
            "auroc": auroc,
            "n_windows": int(len(y)),
            "n_crash": n_crash,
        })

    result = pd.DataFrame(rows)
    valid_auroc = result.dropna(subset=["auroc"])
    if not valid_auroc.empty:
        best = valid_auroc.loc[valid_auroc["auroc"].idxmax()]
        result.attrs["best_epsilon"] = float(best["epsilon"])
        result.attrs["best_rho"] = float(best["implied_rho"])
        result.attrs["best_auroc"] = float(best["auroc"])
    else:
        result.attrs["best_epsilon"] = np.nan
        result.attrs["best_rho"] = np.nan
        result.attrs["best_auroc"] = np.nan
    return result
