"""
Tests for the Week 4-8 TDA modules (Kunal Jha).

These build a small synthetic Betti/diagram dataset with a KNOWN crash
structure (loops suppressed during a stress window, per the project's
validated hypothesis) and confirm each analysis module returns sensible,
correctly-shaped, correctly-signed results.
"""

import numpy as np
import pandas as pd
import pytest

from tda.filtration_sensitivity import (
    filtration_sensitivity,
    mantegna_distance_to_correlation,
)
from tda.significance_and_evolution import (
    gidea_katz_l2_replication,
    mann_whitney_betti_test,
)
from tda.tda_config import EPSILON_GRID


def _synthetic_betti_and_labels(n_windows=200, n_epsilon=None, seed=0):
    """
    Build (betti_array, dates, crash_labels) where H1 mass is systematically
    different in a crash block, so every downstream test has real signal.
    """
    if n_epsilon is None:
        n_epsilon = len(EPSILON_GRID)
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range("2010-01-01", periods=n_windows, freq="5B")

    # Crash block: windows 80..100.
    labels = pd.Series(0, index=pd.bdate_range("2010-01-01", periods=n_windows * 5))
    crash_start = dates[80]
    crash_end = dates[100]
    labels.loc[crash_start:crash_end] = 1

    betti = np.zeros((n_windows, n_epsilon, 2))
    for i in range(n_windows):
        in_crash = 80 <= i <= 100
        # H0 decays from n_assets to 1
        betti[i, :, 0] = 30 * np.exp(-3 * EPSILON_GRID) + 1
        # H1 bump; HIGHER in crash windows so there is a clear, signed signal
        height = 5.0 if in_crash else 1.5
        centre = 0.7
        betti[i, :, 1] = height * np.exp(-((EPSILON_GRID - centre) ** 2) / 0.05)
        betti[i, :, 1] += rng.normal(0, 0.05, n_epsilon).clip(min=0)

    return betti, np.array([str(d.date()) for d in dates]), labels


def test_mantegna_inversion_roundtrip():
    # rho = 0.6 -> D = 0.894...; invert back to 0.6
    D = np.sqrt(2 * (1 - 0.6))
    assert mantegna_distance_to_correlation(D) == pytest.approx(0.6, abs=1e-9)
    # D = sqrt(2) -> rho = 0
    assert mantegna_distance_to_correlation(np.sqrt(2)) == pytest.approx(0.0, abs=1e-9)


def test_filtration_sensitivity_finds_a_peak_with_signal():
    betti, dates, labels = _synthetic_betti_and_labels()
    result = filtration_sensitivity(betti, dates, labels, dim=1)
    assert "auroc" in result.columns
    assert len(result) == len(EPSILON_GRID)
    # There is real signal, so the best AUROC should be clearly above chance.
    assert result.attrs["best_auroc"] > 0.7
    # The most discriminative scale sits on the H1 bump (which spans roughly
    # epsilon in [0.2, 1.1] for a bump centred at 0.7 with this width); the
    # exact peak can be on the rising edge, so just require it inside that band.
    assert 0.2 < result.attrs["best_epsilon"] < 1.1


def test_filtration_sensitivity_reports_implied_rho():
    betti, dates, labels = _synthetic_betti_and_labels()
    result = filtration_sensitivity(betti, dates, labels, dim=1)
    # implied_rho must be a valid correlation everywhere on the grid up to 1.0
    assert (result["implied_rho"] <= 1.0 + 1e-9).all()


def test_mann_whitney_detects_pre_crash_difference():
    betti, dates, labels = _synthetic_betti_and_labels()
    res = mann_whitney_betti_test(betti, dates, labels, dim=1, pre_crash_days=20)
    assert res["n_pre_crash"] >= 3
    # Crash windows have higher H1 mass by construction -> significant, and the
    # direction must be "pre-crash > calm".
    assert res["p_value"] < 0.05
    assert res["direction"] == "pre-crash > calm"


def test_gidea_katz_l2_replication_beats_chance():
    betti, dates, labels = _synthetic_betti_and_labels()
    res = gidea_katz_l2_replication(betti, dates, labels, dim=1)
    assert res["n_windows"] > 0
    # The GK scalar carries the (synthetic) signal, so AUROC should beat chance.
    assert res["gk_auroc"] > 0.7
    assert len(res["gk_scalar"]) == len(dates)


def test_gidea_katz_scalar_is_per_window():
    betti, dates, labels = _synthetic_betti_and_labels()
    res = gidea_katz_l2_replication(betti, dates, labels, dim=1)
    # scalar should be non-negative (it's an L2 norm) and finite
    assert (res["gk_scalar"] >= 0).all()
    assert np.isfinite(res["gk_scalar"]).all()
