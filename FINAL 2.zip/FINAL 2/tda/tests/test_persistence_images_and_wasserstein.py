"""
Unit tests for persistence images and Wasserstein distance/velocity
(Kunal Jha).
"""

import numpy as np

from tda.persistence_images import persistence_image, persistence_image_vector
from tda.wasserstein import velocity_alert, wasserstein_distance, wasserstein_velocity_series


def test_persistence_image_shape_matches_grid_size():
    dgm = np.array([[0.5, 0.9], [0.1, 0.2]])
    img = persistence_image(dgm, grid_size=20)
    assert img.shape == (20, 20)
    vec = persistence_image_vector(dgm, grid_size=20)
    assert vec.shape == (400,)


def test_persistence_image_empty_diagram_is_all_zero():
    empty = np.empty((0, 2))
    img = persistence_image(empty, grid_size=10)
    assert np.allclose(img, 0.0)


def test_persistence_image_mass_concentrates_near_high_persistence_point():
    """A single point with high persistence should leave most of the image's
    mass near its (birth, persistence) location, not spread uniformly."""
    dgm = np.array([[0.2, 1.2]])  # birth=0.2, persistence=1.0
    img = persistence_image(dgm, grid_size=20, sigma=0.05,
                             birth_range=(0, 1.4), persistence_range=(0, 1.4))
    peak_row, peak_col = np.unravel_index(np.argmax(img), img.shape)
    b_centers = np.linspace(0, 1.4, 20)
    p_centers = np.linspace(0, 1.4, 20)
    assert abs(b_centers[peak_col] - 0.2) < 0.15
    assert abs(p_centers[peak_row] - 1.0) < 0.15


def test_wasserstein_distance_zero_for_identical_diagrams():
    dgm = np.array([[0.1, 0.5], [0.2, 0.4]])
    assert wasserstein_distance(dgm, dgm) == 0.0


def test_wasserstein_distance_empty_vs_empty_is_zero():
    empty = np.empty((0, 2))
    assert wasserstein_distance(empty, empty) == 0.0


def test_wasserstein_distance_is_symmetric():
    dgm1 = np.array([[0.1, 0.5]])
    dgm2 = np.array([[0.15, 0.6], [0.05, 0.1]])
    assert abs(wasserstein_distance(dgm1, dgm2) - wasserstein_distance(dgm2, dgm1)) < 1e-9


def test_velocity_series_drops_first_undefined_value():
    dgms_by_date = [
        ("2020-01-01", [np.empty((0, 2)), np.array([[0.1, 0.3]])]),
        ("2020-01-02", [np.empty((0, 2)), np.array([[0.1, 0.35]])]),
        ("2020-01-03", [np.empty((0, 2)), np.array([[0.1, 0.9]])]),
    ]
    series = wasserstein_velocity_series(dgms_by_date, dim=1)
    assert len(series) == 2  # first date has no predecessor, dropped
    assert series.iloc[1] > series.iloc[0]  # the big jump on day 3 should show up


def test_velocity_alert_flags_a_clear_spike():
    rng = np.random.default_rng(0)
    import pandas as pd
    baseline = rng.normal(loc=0.1, scale=0.01, size=40)
    baseline[-1] = 0.5  # an obvious spike at the end
    series = pd.Series(baseline, index=pd.date_range("2020-01-01", periods=40))
    alerts = velocity_alert(series, n_std=2.0, min_periods=20)
    assert alerts.iloc[-1] == True  # noqa: E712
    assert alerts.iloc[:20].sum() == 0  # nothing flagged before min_periods is met
