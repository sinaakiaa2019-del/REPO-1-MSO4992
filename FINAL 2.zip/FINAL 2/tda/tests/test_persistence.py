"""
Unit tests for the core persistence computation (Kunal Jha).

These are the Week 1 "confirm the TDA stack works" sanity checks, written as
pytest tests with known ground truth instead of one-off interactive
exploration, so they keep proving the stack works on every future run (e.g.
after a ripser/numpy upgrade) rather than just once, in Week 1, and never
again.

Run with:  pytest tda/tests
"""

import numpy as np
import pytest

from tda.betti_curves import betti_curve, max_persistence, persistence_entropy
from tda.persistence import betti_number_at, compute_persistence


def _square_distance_matrix():
    """
    Four points on a unit square: one persistent H1 loop, born when the four
    sides (length 1) connect everything into a 4-cycle, dying when the two
    diagonals (length sqrt(2)) triangulate it. Hand-computed ground truth,
    independently verified against ripser's actual output before writing
    these assertions.
    """
    pts = np.array([[0, 0], [1, 0], [1, 1], [0, 1]], dtype=float)
    diff = pts[:, None, :] - pts[None, :, :]
    return np.sqrt((diff ** 2).sum(-1))


def test_square_h1_loop_matches_hand_computed_values():
    D = _square_distance_matrix()
    result = compute_persistence(D, maxdim=1, thresh=2.0)
    h1 = result["dgms"][1]
    assert h1.shape[0] == 1, "expected exactly one H1 feature (the square's loop)"
    birth, death = h1[0]
    assert birth == pytest.approx(1.0, abs=1e-6)
    assert death == pytest.approx(np.sqrt(2), abs=1e-6)


def test_square_h0_four_bars_three_merges_one_survivor():
    """4 points -> 4 H0 bars: 3 finite-death merge events (all at epsilon=1,
    when the unit-length edges appear) and 1 infinite-death survivor (the
    final single component), capped at `thresh` by compute_persistence."""
    D = _square_distance_matrix()
    result = compute_persistence(D, maxdim=1, thresh=2.0)
    h0 = result["dgms"][0]
    assert h0.shape[0] == 4
    assert np.allclose(h0[:, 0], 0.0)

    raw = result["dgms_raw"][0]
    n_infinite = np.isinf(raw[:, 1]).sum()
    assert n_infinite == 1, "exactly one component should survive to the end"

    finite_deaths = np.sort(h0[~np.isinf(raw[:, 1]), 1])
    assert np.allclose(finite_deaths, [1.0, 1.0, 1.0])

    capped_death = h0[np.isinf(raw[:, 1]), 1][0]
    assert capped_death == pytest.approx(2.0)  # capped at thresh, not inf


def test_betti_curve_matches_betti_number_at_every_grid_point():
    D = _square_distance_matrix()
    eps_grid = np.linspace(0, 2.0, 50)
    result = compute_persistence(D, maxdim=1, thresh=2.0)
    h1 = result["dgms"][1]
    curve = betti_curve(h1, eps_grid)
    for i, eps in enumerate(eps_grid):
        assert curve[i] == betti_number_at(h1, eps)


def test_betti_curve_h1_shape_rises_then_falls_for_the_square():
    """For the square: beta_1 = 0 below epsilon=1, beta_1 = 1 on [1, sqrt(2)),
    beta_1 = 0 at and above sqrt(2) once the diagonals triangulate the loop."""
    D = _square_distance_matrix()
    eps_grid = np.array([0.5, 1.0, 1.2, 1.41, 1.42, 1.5])
    result = compute_persistence(D, maxdim=1, thresh=2.0)
    curve = betti_curve(result["dgms"][1], eps_grid)
    assert list(curve) == [0.0, 1.0, 1.0, 1.0, 0.0, 0.0]


def test_circle_point_cloud_has_one_dominant_h1_feature():
    """Standard ripser-tutorial sanity check: points sampled on a circle
    should show one H1 feature whose lifetime clearly dominates any other
    (noise) feature -- the classic 'does the stack actually find the loop'
    smoke test, run here on a self-generated, fully reproducible point cloud."""
    rng = np.random.default_rng(0)
    theta = np.linspace(0, 2 * np.pi, 30, endpoint=False)
    pts = np.stack([np.cos(theta), np.sin(theta)], axis=1)
    pts += rng.normal(scale=0.02, size=pts.shape)  # small noise

    diff = pts[:, None, :] - pts[None, :, :]
    D = np.sqrt((diff ** 2).sum(-1))

    result = compute_persistence(D, maxdim=1, thresh=3.0)
    h1 = result["dgms"][1]
    assert h1.shape[0] >= 1
    lifetimes = h1[:, 1] - h1[:, 0]
    dominant = lifetimes.max()
    others = np.sort(lifetimes)[:-1]
    if others.size:
        assert dominant > 3 * others.max(), "expected one clearly dominant loop"


def test_sphere_point_cloud_has_one_h2_void():
    """
    Week 1 plan deliverable: 'Run the ripser sphere example to confirm the
    TDA stack works.' Reproduced with a self-generated point cloud (no
    external example-file download required) sampled on a 2-sphere, which
    should show a persistent H2 feature (the enclosed void). This also
    confirms the stack can compute H2 on demand if Week 6 needs it, even
    though the Weeks 1-3 batch pipeline only computes up to H1 by default
    (see tda_config.MAX_HOMOLOGY_DIM and its docstring)."""
    rng = np.random.default_rng(1)
    n = 60
    vecs = rng.normal(size=(n, 3))
    vecs /= np.linalg.norm(vecs, axis=1, keepdims=True)  # points on the unit sphere

    diff = vecs[:, None, :] - vecs[None, :, :]
    D = np.sqrt((diff ** 2).sum(-1))

    result = compute_persistence(D, maxdim=2, thresh=2.5)
    h2 = result["dgms"][2]
    assert h2.shape[0] >= 1, "expected at least one H2 feature for a sphere sample"
    lifetimes = h2[:, 1] - h2[:, 0]
    assert lifetimes.max() > 0.2, "expected a reasonably persistent void"


def test_single_point_degrades_safely():
    """A single point (n=1) has no edges and no loops -- everything should
    degrade gracefully instead of raising."""
    D = np.zeros((1, 1))
    result = compute_persistence(D, maxdim=1, thresh=1.0)
    h0, h1 = result["dgms"][0], result["dgms"][1]
    assert h0.shape == (1, 2)        # one component, born and "dies" (capped) at thresh
    assert h1.shape == (0, 2)        # no edges -> no possible loop
    assert persistence_entropy(h1) == 0.0
    assert max_persistence(h1) == 0.0


def test_compute_persistence_rejects_non_square_input():
    with pytest.raises(ValueError):
        compute_persistence(np.zeros((3, 4)))
