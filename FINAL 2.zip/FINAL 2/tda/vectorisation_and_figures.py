"""
Vectorisation ablation + publication persistence-diagram figures (Kunal Jha)
-- Weeks 6-7.

vectorisation_ablation:
  The TDA stage produces four different vectorisations of the same persistence
  diagrams -- (A) full Betti curves, (B) persistence images, (C) diagram-level
  scalars (entropy, max/total persistence, L2 norm), (D) Wasserstein velocity.
  This scores each one INDEPENDENTLY on the crash label under the project's
  expanding-window CV, so the paper can say which topological representation
  actually carries the predictive signal rather than reporting one aggregate
  number. Hands the AUROC-per-method table to Sina for the paper's ablation.

  This uses the ML stage's own cross_validated_auroc so the numbers are
  directly comparable to F1/F2/F3 -- the TDA and ML stages share one evaluator.

plot_persistence_diagrams:
  Publication-quality birth-death scatter plots for a calm window, a pre-crash
  window and a post-crash window, side by side -- the key visual result showing
  the diagram densifies as a crash approaches.
"""

from __future__ import annotations

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from tda.tda_config import EPSILON_GRID, FIGURE_DIR


def build_vectorisation_frames(betti_array, pi_array, topology_features, dates):
    """
    Assemble the four vectorisation feature frames on a common date index.

    Returns dict of DataFrames keyed 'betti_curves', 'persistence_images',
    'scalars', 'wasserstein' (whichever are available), all date-indexed.
    """
    dates = pd.to_datetime([str(d) for d in dates])
    frames = {}

    # (A) Betti curves: flatten H0+H1 across epsilon.
    n = betti_array.shape[0]
    betti_flat = betti_array.reshape(n, -1)
    frames["betti_curves"] = pd.DataFrame(
        betti_flat, index=dates,
        columns=[f"betti_{d}_{j}" for d in range(betti_array.shape[2])
                 for j in range(betti_array.shape[1])][:betti_flat.shape[1]],
    )

    # (B) Persistence images.
    if pi_array is not None:
        frames["persistence_images"] = pd.DataFrame(
            pi_array, index=dates, columns=[f"pi_{k}" for k in range(pi_array.shape[1])])

    # (C) Diagram-level scalars + (D) Wasserstein velocity from topology_features.
    if topology_features is not None and not topology_features.empty:
        tf = topology_features.copy()
        tf.index = pd.to_datetime(tf.index)
        scalar_cols = [c for c in tf.columns
                       if c not in ("wasserstein_velocity",) and tf[c].dtype != object]
        if scalar_cols:
            frames["scalars"] = tf[scalar_cols]
        if "wasserstein_velocity" in tf.columns:
            frames["wasserstein"] = tf[["wasserstein_velocity"]]

    return frames


def vectorisation_ablation(betti_array, pi_array, topology_features, dates, crash_labels):
    """
    Score each TDA vectorisation independently on the crash label.

    Returns a DataFrame: method, n_features, mean_auroc, std_auroc,
    n_scored_folds -- sorted by mean AUROC. Uses the ML stage's evaluator so
    the numbers sit directly alongside F1/F2/F3.
    """
    from ml.data_access import align_features_labels
    from ml.models import cross_validated_auroc

    frames = build_vectorisation_frames(betti_array, pi_array, topology_features, dates)

    if isinstance(crash_labels, pd.DataFrame):
        labels = crash_labels[["crash_label"]].copy()
    else:
        labels = pd.DataFrame({"crash_label": crash_labels})
    labels.index = pd.to_datetime(labels.index)

    rows = []
    for method, X in frames.items():
        try:
            X_aligned, y = align_features_labels(X, labels)
        except Exception as exc:
            rows.append({"method": method, "n_features": X.shape[1],
                         "mean_auroc": np.nan, "std_auroc": np.nan,
                         "n_scored_folds": 0, "note": f"align failed: {exc}"})
            continue
        if X_aligned.empty or y.nunique() < 2:
            rows.append({"method": method, "n_features": X.shape[1],
                         "mean_auroc": np.nan, "std_auroc": np.nan,
                         "n_scored_folds": 0, "note": "insufficient signal/labels"})
            continue
        cv = cross_validated_auroc(X_aligned, y)
        rows.append({
            "method": method, "n_features": X_aligned.shape[1],
            "mean_auroc": cv["mean_auroc"], "std_auroc": cv["std_auroc"],
            "n_scored_folds": cv["n_scored_folds"], "note": "",
        })

    table = pd.DataFrame(rows)
    if "mean_auroc" in table.columns and table["mean_auroc"].notna().any():
        table = table.sort_values("mean_auroc", ascending=False, na_position="last")
    return table.reset_index(drop=True)


def plot_persistence_diagrams(diagrams_by_date, dates, crash_labels,
                              output_path=None):
    """
    Side-by-side H1 birth-death scatter plots for a calm, pre-crash, and
    post-crash window (selected from the real diagrams), showing the diagram
    densifying around a crash.
    """
    dates_ts = pd.to_datetime([str(d) for d, _ in diagrams_by_date])
    if isinstance(crash_labels, pd.DataFrame):
        labels = crash_labels["crash_label"]
    else:
        labels = pd.Series(crash_labels)
    labels.index = pd.to_datetime(labels.index)

    aligned = labels.reindex(dates_ts, method="nearest",
                             tolerance=pd.Timedelta("5D")).fillna(0).astype(int).values

    crash_idx = np.where(aligned == 1)[0]
    calm_idx = np.where(aligned == 0)[0]

    picks = {}
    if len(calm_idx):
        picks["Calm market"] = calm_idx[len(calm_idx) // 2]
    if len(crash_idx):
        picks["Pre / during crash"] = crash_idx[0]
        picks["Later crash window"] = crash_idx[-1]
    if not picks:
        picks["First window"] = 0

    fig, axes = plt.subplots(1, len(picks), figsize=(5 * len(picks), 4.6), squeeze=False)
    for ax, (title, idx) in zip(axes[0], picks.items()):
        _, dgms = diagrams_by_date[idx]
        for dim, colour, marker in [(0, "#1f77b4", "o"), (1, "#d62728", "^")]:
            if len(dgms) > dim and dgms[dim].size:
                d = dgms[dim]
                ax.scatter(d[:, 0], d[:, 1], s=18, c=colour, marker=marker,
                           alpha=0.6, label=f"H{dim}")
        lim = float(np.sqrt(2))
        ax.plot([0, lim], [0, lim], "k--", lw=0.8, alpha=0.5)
        ax.set_xlim(0, lim); ax.set_ylim(0, lim)
        ax.set_xlabel("Birth"); ax.set_ylabel("Death")
        ax.set_title(f"{title}\n({str(pd.Timestamp(dates_ts[idx]).date())})", fontsize=9)
        ax.legend(fontsize=8)
    fig.suptitle("Persistence diagrams: calm vs. crash windows", fontsize=12)
    fig.tight_layout()

    output_path = output_path or (FIGURE_DIR / "persistence_diagrams_calm_vs_crash.png")
    FIGURE_DIR.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return output_path


def plot_filtration_sensitivity(sensitivity_df, output_path=None):
    """Plot AUROC vs epsilon (RQ2), marking the peak and the rho=0.6 reference."""
    fig, ax = plt.subplots(figsize=(8, 4.6))
    ax.plot(sensitivity_df["epsilon"], sensitivity_df["auroc"], lw=1.6, color="#2c5f8a")
    best_eps = sensitivity_df.attrs.get("best_epsilon", np.nan)
    best_auroc = sensitivity_df.attrs.get("best_auroc", np.nan)
    if not np.isnan(best_eps):
        ax.axvline(best_eps, color="#d62728", ls="--", lw=1,
                   label=f"peak epsilon={best_eps:.3f} (AUROC {best_auroc:.3f})")
    # rho = 0.6 reference (Mantegna D = sqrt(2*(1-0.6)) ~ 0.894)
    ax.axvline(0.894, color="gray", ls=":", lw=1, label="rho=0.6 reference (D=0.894)")
    ax.set_xlabel(r"Filtration scale $\epsilon$")
    ax.set_ylabel(r"AUROC of single-scale $\beta_1(\epsilon)$ vs crash label")
    ax.set_title("RQ2: which filtration scale is most predictive?")
    ax.legend(fontsize=8)
    fig.tight_layout()

    output_path = output_path or (FIGURE_DIR / "filtration_sensitivity_rq2.png")
    FIGURE_DIR.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return output_path


def shap_by_epsilon_overlay(betti_array, dates, crash_labels, sensitivity_df,
                            output_path=None, dim=1):
    """
    Week 7 deliverable: overlay SHAP attribution by epsilon on the filtration-
    sensitivity plot -- do the model's learned importances concentrate at the
    same scales the model-free AUROC analysis identifies?

    Trains one XGBoost on the flattened H_dim Betti curve, computes mean |SHAP|
    per epsilon column, and plots it (right axis) over the AUROC-vs-epsilon
    curve (left axis). Returns (output_path, shap_by_eps Series).
    """
    import shap
    from xgboost import XGBClassifier

    from ml.data_access import align_features_labels
    from ml.ml_config import XGB_BASE_PARAMS

    dates_ts = pd.to_datetime([str(d) for d in dates])
    X = pd.DataFrame(betti_array[:, :, dim], index=dates_ts,
                     columns=[f"eps_{j}" for j in range(betti_array.shape[1])])
    labels = (crash_labels[["crash_label"]] if isinstance(crash_labels, pd.DataFrame)
              else pd.DataFrame({"crash_label": crash_labels}))
    labels.index = pd.to_datetime(labels.index)
    X_al, y = align_features_labels(X, labels)
    if y.nunique() < 2:
        raise ValueError("Need both classes for SHAP-by-epsilon.")

    params = dict(XGB_BASE_PARAMS)
    n_pos = int(y.sum())
    params["scale_pos_weight"] = (len(y) - n_pos) / n_pos if n_pos else 1.0
    model = XGBClassifier(**params).fit(X_al.values, y.values)
    sv = shap.TreeExplainer(model).shap_values(X_al.values)
    mean_abs = pd.Series(np.abs(sv).mean(axis=0), index=EPSILON_GRID, name="mean_abs_shap")

    fig, ax1 = plt.subplots(figsize=(8, 4.6))
    ax1.plot(sensitivity_df["epsilon"], sensitivity_df["auroc"],
             color="#2c5f8a", lw=1.6, label="model-free AUROC")
    ax1.set_xlabel(r"Filtration scale $\epsilon$")
    ax1.set_ylabel("Single-scale AUROC", color="#2c5f8a")
    ax2 = ax1.twinx()
    ax2.fill_between(mean_abs.index, mean_abs.values, color="#d62728", alpha=0.3,
                     label="mean |SHAP| (XGBoost)")
    ax2.set_ylabel("Mean |SHAP|", color="#d62728")
    ax1.set_title("RQ2 cross-check: model-free AUROC vs learned SHAP attribution by scale")
    fig.tight_layout()
    output_path = output_path or (FIGURE_DIR / "shap_by_epsilon_overlay.png")
    FIGURE_DIR.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return output_path, mean_abs
