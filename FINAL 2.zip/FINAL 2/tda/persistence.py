"""
Core persistent-homology computation (Kunal Jha).

Thin, tested wrapper around ripser's Vietoris-Rips persistence so the rest of
the tda/ package (Betti curves, persistence images, Wasserstein velocity)
only ever has to deal with one simple diagram format:

    dgms[d] : np.ndarray of shape (n_features, 2), columns [birth, death]

ripser returns death = inf for "essential" classes still alive at the end of
the filtration (always true of exactly one H0 component for a connected
point set; can also happen for H1 if the filtration is thresholded before a
loop fills in). These are genuinely infinite-lifetime features, but every
downstream numeric use here (Betti curves on a finite grid, persistence
images, Wasserstein distance) needs a finite number. We cap death at the
filtration's max epsilon rather than dropping these points -- dropping the
single surviving H0 component would silently misrepresent "the whole market
is one connected component" (a real, important state) as "no information."
"""

from __future__ import annotations

import numpy as np
from ripser import ripser as _ripser

from tda.tda_config import MAX_EPSILON, MAX_HOMOLOGY_DIM


def compute_persistence(distance_matrix, maxdim=MAX_HOMOLOGY_DIM, thresh=MAX_EPSILON):
    """
    Compute Vietoris-Rips persistence diagrams from a precomputed distance
    matrix (e.g. a Mantegna distance matrix from matrix_builder.py).

    Parameters
    ----------
    distance_matrix : np.ndarray, shape (n, n)
        Symmetric, zero-diagonal distance matrix.
    maxdim : int
        Maximum homology dimension to compute (0 = components, 1 = loops,
        2 = voids). Week 1-3 scope only needs 0 and 1; see tda_config.py.
    thresh : float
        Filtration stops at this epsilon. Mantegna distances are bounded by
        sqrt(2), so the default already covers the full range; pass a
        smaller thresh to truncate the filtration for speed (RQ2 / Concepts
        Reference section 5 suggests the signal concentrates near
        epsilon ~ 0.894, well below sqrt(2) ~ 1.414).

    Returns
    -------
    dict with keys:
        'dgms'      : list of (n_features, 2) arrays, one per dimension,
                      with infinite deaths capped at `thresh`.
        'dgms_raw'  : the same, but with ripser's raw output (inf preserved).
        'n_points'  : number of points (assets) in this window.
    """
    distance_matrix = np.asarray(distance_matrix, dtype=float)
    if distance_matrix.ndim != 2 or distance_matrix.shape[0] != distance_matrix.shape[1]:
        raise ValueError("distance_matrix must be square (n_assets x n_assets).")

    result = _ripser(distance_matrix, distance_matrix=True, maxdim=maxdim, thresh=thresh)
    dgms_raw = result["dgms"]

    dgms_capped = []
    for d in dgms_raw:
        d = np.array(d, dtype=float, copy=True)
        if d.size:
            d[np.isinf(d[:, 1]), 1] = thresh
        dgms_capped.append(d)

    return {
        "dgms": dgms_capped,
        "dgms_raw": dgms_raw,
        "n_points": distance_matrix.shape[0],
    }


def betti_number_at(dgm, epsilon):
    """
    Scalar Betti number: number of features in a single-dimension diagram
    alive at scale epsilon (birth <= epsilon < death). The vectorised version
    used in the batch pipeline lives in betti_curves.betti_curve; this scalar
    form exists for spot checks and tests where one specific epsilon matters.
    """
    if dgm.size == 0:
        return 0
    birth, death = dgm[:, 0], dgm[:, 1]
    return int(np.sum((birth <= epsilon) & (epsilon < death)))
