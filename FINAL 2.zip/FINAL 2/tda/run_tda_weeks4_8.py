"""
TDA Weeks 4-8 orchestrator (Kunal Jha).

Runs every Week 4-8 TDA analysis on the primary equity topology (and, where
available, the sector/robustness universes), writing results into
outputs/tda_reports/ and outputs/figures/. Assumes tda/run_tda.py (Weeks 1-3)
has already produced betti_curves.npz / topology_features.csv, and that
Octavian's pipeline has produced crash_labels.csv and the distance matrices.

Run from the project root:
    python -m tda.run_tda_weeks4_8
"""

from __future__ import annotations

import pickle
from pathlib import Path

import numpy as np
import pandas as pd

import config
from tda.filtration_sensitivity import filtration_sensitivity
from tda.multi_universe import (
    run_all_sectors,
    wasserstein_early_warning_eval,
)
from tda.significance_and_evolution import (
    crash_diagram_evolution,
    gidea_katz_l2_replication,
    h2_void_analysis,
    mann_whitney_betti_test,
)
from tda.vectorisation_and_figures import (
    plot_filtration_sensitivity,
    plot_persistence_diagrams,
    vectorisation_ablation,
)

TDA_REPORTS = config.OUTPUT_DIR / "tda_reports"


def _load_primary_topology():
    """Load Weeks 1-3 TDA outputs + crash labels. Returns dict or None."""
    if not Path(config.BETTI_CURVE_FILE).exists():
        print("  No betti_curves.npz found -- run tda/run_tda.py first.")
        return None

    data = np.load(config.BETTI_CURVE_FILE, allow_pickle=True)
    betti_array = data["betti"] if "betti" in data.files else data[data.files[0]]
    dates = data["dates"] if "dates" in data.files else None

    pi_array = None
    if Path(config.PERSISTENCE_IMAGE_FILE).exists():
        pdata = np.load(config.PERSISTENCE_IMAGE_FILE, allow_pickle=True)
        pi_array = pdata["images"] if "images" in pdata.files else pdata[pdata.files[0]]

    topo_features = None
    if Path(config.TOPOLOGY_FEATURES_FILE).exists():
        topo_features = pd.read_csv(config.TOPOLOGY_FEATURES_FILE, index_col=0)
        topo_features.index = pd.to_datetime(topo_features.index)

    diagrams = None
    if Path(config.PERSISTENCE_DIAGRAM_FILE).exists():
        with open(config.PERSISTENCE_DIAGRAM_FILE, "rb") as fh:
            diagrams = pickle.load(fh)

    if not Path(config.CRASH_LABELS_FILE).exists():
        print("  No crash_labels.csv found -- run the data pipeline first.")
        return None
    labels = pd.read_csv(config.CRASH_LABELS_FILE, index_col=0)
    labels.index = pd.to_datetime(labels.index)

    return {
        "betti_array": betti_array, "dates": dates, "pi_array": pi_array,
        "topology_features": topo_features, "diagrams": diagrams, "labels": labels,
    }


def run(verbose=True):
    TDA_REPORTS.mkdir(parents=True, exist_ok=True)
    config.FIGURE_DIR.mkdir(parents=True, exist_ok=True)

    prim = _load_primary_topology()
    if prim is None:
        print("TDA Weeks 4-8: prerequisites missing, nothing to do.")
        return

    betti, dates, labels = prim["betti_array"], prim["dates"], prim["labels"]

    print("=" * 60)
    print("TDA Weeks 4-8 analysis")
    print("=" * 60)

    # --- Week 4: filtration sensitivity (RQ2) ---
    print("Week 4: filtration sensitivity (RQ2)...")
    sens = filtration_sensitivity(betti, dates, labels, dim=1)
    sens.to_csv(TDA_REPORTS / "filtration_sensitivity.csv", index=False)
    fig1 = plot_filtration_sensitivity(sens)
    print(f"  peak epsilon={sens.attrs['best_epsilon']:.3f} "
          f"(rho={sens.attrs['best_rho']:.3f}), AUROC={sens.attrs['best_auroc']:.3f}")
    print(f"  -> {fig1}")

    # --- Week 7: SHAP-by-epsilon overlay on the RQ2 curve ---
    print("Week 7: SHAP attribution by epsilon (RQ2 cross-check)...")
    try:
        from tda.vectorisation_and_figures import shap_by_epsilon_overlay
        fig_shap, shap_eps = shap_by_epsilon_overlay(betti, dates, labels, sens)
        shap_eps.to_frame().to_csv(TDA_REPORTS / "shap_by_epsilon.csv")
        print(f"  -> {fig_shap}")
    except Exception as exc:
        print(f"  SHAP-by-epsilon skipped: {exc}")

    # --- Week 7: topological distance to crisis (novel proximity metric) ---
    if prim["diagrams"] is not None:
        print("Week 7: topological distance to crisis...")
        try:
            from tda.crisis_proximity import (
                plot_crisis_proximity, topological_distance_to_crisis)
            prox = topological_distance_to_crisis(prim["diagrams"], labels)
            if len(prox):
                prox.to_frame().to_csv(TDA_REPORTS / "crisis_proximity.csv")
                figp = plot_crisis_proximity(prox, labels)
                print(f"  -> {figp}")
            else:
                print("  no crash windows in sample; proximity metric skipped.")
        except Exception as exc:
            print(f"  crisis proximity skipped: {exc}")

    # --- Week 8: persistence entropy vs VIX overlay ---
    print("Week 8: persistence entropy vs VIX overlay...")
    try:
        from tda.crisis_proximity import entropy_vix_overlay
        vix = _load_vix_series()
        if vix is not None and prim["topology_features"] is not None:
            fige, ecorr = entropy_vix_overlay(prim["topology_features"], vix)
            pd.DataFrame([ecorr]).to_csv(TDA_REPORTS / "entropy_vix_correlation.csv", index=False)
            print(f"  pearson={ecorr['pearson']:.2f}, spearman={ecorr['spearman']:.2f} -> {fige}")
        else:
            print("  no VIX series available; overlay skipped.")
    except Exception as exc:
        print(f"  entropy-vs-VIX skipped: {exc}")

    # --- Week 3 (Octavian, back-filled): UMAP embedding of distance matrices ---
    print("Week 3 back-fill: UMAP embedding of distance-matrix geometry...")
    try:
        from embedding_visualiser import umap_distance_embedding
        figu, emb = umap_distance_embedding(crash_labels=labels)
        emb.to_csv(TDA_REPORTS / "umap_embedding.csv")
        print(f"  -> {figu}")
    except Exception as exc:
        print(f"  UMAP embedding skipped: {exc}")

    # --- Week 6: vectorisation ablation ---
    print("Week 6: vectorisation ablation...")
    try:
        abl = vectorisation_ablation(betti, prim["pi_array"], prim["topology_features"],
                                     dates, labels)
        abl.to_csv(TDA_REPORTS / "vectorisation_ablation.csv", index=False)
        if not abl.empty and abl["mean_auroc"].notna().any():
            top = abl.dropna(subset=["mean_auroc"]).iloc[0]
            print(f"  best vectorisation: {top['method']} "
                  f"(AUROC {top['mean_auroc']:.3f} on {int(top['n_scored_folds'])} folds)")
    except Exception as exc:
        print(f"  vectorisation ablation skipped: {exc}")

    # --- Week 7: Mann-Whitney significance ---
    print("Week 7: Mann-Whitney significance of Betti spikes...")
    mw = mann_whitney_betti_test(betti, dates, labels, dim=1)
    pd.DataFrame([mw]).to_csv(TDA_REPORTS / "mann_whitney_betti.csv", index=False)
    print(f"  U={mw['u_statistic']}, p={mw['p_value']}, direction={mw['direction']}")

    # --- Week 7: publication persistence-diagram figure ---
    if prim["diagrams"] is not None:
        print("Week 7: persistence-diagram figure...")
        try:
            fig2 = plot_persistence_diagrams(prim["diagrams"], dates, labels)
            print(f"  -> {fig2}")
        except Exception as exc:
            print(f"  diagram figure skipped: {exc}")

    # --- Week 8: Gidea & Katz L2 replication ---
    print("Week 8: Gidea & Katz (2018) L2-norm replication...")
    gk = gidea_katz_l2_replication(betti, dates, labels, dim=1)
    pd.DataFrame([{k: v for k, v in gk.items() if k != "gk_scalar"}]).to_csv(
        TDA_REPORTS / "gidea_katz_replication.csv", index=False)
    gk["gk_scalar"].to_frame().to_csv(TDA_REPORTS / "gidea_katz_scalar.csv")
    print(f"  Gidea-Katz L2 scalar AUROC = {gk['gk_auroc']}")

    # --- Week 8: crash-specific diagram evolution (needs distance matrices) ---
    dist_dir = Path(config.DISTANCE_DIR)
    dist_files = sorted(dist_dir.glob("distance_*.npz")) if dist_dir.exists() else []
    if dist_files:
        print("Week 8: crash-specific diagram evolution...")
        by_date = []
        for f in dist_files:
            d = np.load(f, allow_pickle=True)
            date = str(d["date"]) if "date" in d.files else f.stem.split("_")[-1]
            by_date.append((pd.Timestamp(date), d["matrix"]))
        try:
            evo = crash_diagram_evolution(by_date, config.CRASH_EVENTS_LIST
                                          if hasattr(config, "CRASH_EVENTS_LIST")
                                          else _crash_events_list())
            evo.to_csv(TDA_REPORTS / "crash_diagram_evolution.csv", index=False)
            print(f"  {len(evo)} (crisis, offset) diagram summaries written.")
        except Exception as exc:
            print(f"  crash evolution skipped: {exc}")

        # --- Week 6: H2 feasibility on a crash-centred sample ---
        print("Week 6: H2 (voids) feasibility sample...")
        try:
            h2_df, h2_timing = h2_void_analysis(by_date, labels, max_windows=20)
            h2_df.to_csv(TDA_REPORTS / "h2_void_analysis.csv", index=False)
            print(f"  H2 on {h2_timing['n_windows']} windows: "
                  f"mean {h2_timing['mean_seconds']*1000:.0f} ms/window, "
                  f"max {h2_timing['max_seconds']*1000:.0f} ms/window (thresh {h2_timing['thresh']})")
        except Exception as exc:
            print(f"  H2 analysis skipped: {exc}")

    # --- Week 5: Wasserstein velocity early-warning (no ML) ---
    wv_path = Path(config.WASSERSTEIN_VELOCITY_FILE)
    if wv_path.exists():
        print("Week 5: Wasserstein-velocity early-warning eval...")
        wv = pd.read_csv(wv_path, index_col=0)
        wv_series = wv.iloc[:, 0]
        wv_series.index = pd.to_datetime(wv_series.index)
        ew = wasserstein_early_warning_eval(wv_series, labels)
        pd.DataFrame([ew]).to_csv(TDA_REPORTS / "wasserstein_early_warning.csv", index=False)
        print(f"  precision={ew['precision']}, recall={ew['recall']}, f1={ew['f1']}")

    # --- Week 4-5: sector TDA (if Octavian built sector matrices) ---
    sectors_root = Path(config.SECTOR_DIR)
    if sectors_root.exists() and any(sectors_root.iterdir()):
        print("Week 4-5: per-sector TDA...")
        sector_out = config.PROCESSED_DIR / "sectors_tda"
        results = run_all_sectors(sectors_root, sector_out)
        print(f"  {len(results)} sectors processed -> {sector_out}")

    print("=" * 60)
    print(f"TDA Weeks 4-8 complete. Reports: {TDA_REPORTS}")
    print("=" * 60)


def _crash_events_list():
    """Reference crashes as (name, start, end) tuples from config.CRASH_EVENTS."""
    return [(name, s, e) for name, (s, e) in config.CRASH_EVENTS.items()]


def _load_vix_series():
    """Load a VIX series from whichever source exists: market_indicators.csv
    (real runs) or macro_features.csv (synthetic demo). Returns Series or None."""
    for path, cols in ((config.MARKET_INDICATORS_FILE, ("vix_close", "vix", "VIX")),
                       (config.MACRO_FEATURES_FILE, ("vix", "VIX", "vix_close"))):
        p = Path(path)
        if p.exists():
            df = pd.read_csv(p, index_col=0)
            df.index = pd.to_datetime(df.index)
            for c in cols:
                if c in df.columns:
                    return df[c]
    return None


if __name__ == "__main__":
    run()
