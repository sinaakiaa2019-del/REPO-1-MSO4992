"""
Wasserstein distance and velocity between persistence diagrams (Kunal Jha).

Uses persim's optimal-transport matching (Concepts Reference section 12:
"computed using the persim library in Python"). Wasserstein velocity
V(t) = W2(D(t), D(t-1)) needs no model and no training data -- it is a pure
topological early-warning signal (sections 12 and 16).
"""

import numpy as np
import pandas as pd
import persim


def wasserstein_distance(dgm1, dgm2):
    """
    2-Wasserstein distance between two single-dimension persistence
    diagrams. persim.wasserstein already treats an empty diagram as "every
    point sits on the diagonal" (verified: wasserstein(empty, empty) == 0.0),
    so no special-casing is needed here beyond normalising shapes.
    """
    dgm1 = np.asarray(dgm1, dtype=float)
    dgm2 = np.asarray(dgm2, dtype=float)
    if dgm1.size == 0:
        dgm1 = np.empty((0, 2))
    if dgm2.size == 0:
        dgm2 = np.empty((0, 2))
    return float(persim.wasserstein(dgm1, dgm2))


def wasserstein_velocity_series(dgms_by_date, dim=1):
    """
    V(t) = W2(D(t), D(t-1)) for consecutive windows, in date order.

    Parameters
    ----------
    dgms_by_date : list of (date, dgms) tuples, already sorted by date, where
        `dgms` is the per-window list of diagrams from
        persistence.compute_persistence (dgms[dim] is used).
    dim : int
        Homology dimension to use (default H1 -- contagion loops, the
        dimension Concepts Reference sections 12/16 actually motivate).

    Returns
    -------
    pd.Series indexed by date, name 'wasserstein_velocity'. The first date is
    dropped (no previous window exists to compare it against).
    """
    if len(dgms_by_date) < 2:
        return pd.Series([], name="wasserstein_velocity", dtype=float)

    dates = [d for d, _ in dgms_by_date]
    values = [np.nan]
    for i in range(1, len(dgms_by_date)):
        prev_dgm = dgms_by_date[i - 1][1][dim]
        curr_dgm = dgms_by_date[i][1][dim]
        values.append(wasserstein_distance(prev_dgm, curr_dgm))

    series = pd.Series(values, index=pd.to_datetime(dates), name="wasserstein_velocity")
    return series.iloc[1:]


def velocity_alert(velocity_series, n_std=2.0, min_periods=20):
    """
    Parameter-free early-warning rule (Concepts Reference section 12):
    flag V(t) > rolling_mean + n_std * rolling_std. Returns a boolean Series
    aligned to velocity_series (False, not NaN, before min_periods is met).
    """
    rolling_mean = velocity_series.rolling(min_periods, min_periods=min_periods).mean()
    rolling_std = velocity_series.rolling(min_periods, min_periods=min_periods).std()
    threshold = rolling_mean + n_std * rolling_std
    alert = velocity_series > threshold
    return alert.fillna(False)
