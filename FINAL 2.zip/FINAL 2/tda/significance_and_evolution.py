"""
TDA significance, H2, crash-evolution and Gidea-Katz replication (Kunal Jha)
-- Weeks 6-8.

Contents
--------
Week 6:
  - h2_void_analysis: compute H2 (2-cycles / voids) on a sample of windows
    around crash dates and test whether beta_2 also spikes. H2 is far more
    expensive than H0/H1, so this runs on a small crash-centred sample, not
    the full history -- and it TIMES itself so the feasibility question ("can
    we afford H2 at 461 stocks?") is answered with a number, not a guess.

Week 7:
  - mann_whitney_betti_test: non-parametric test that beta_1 in pre-crash
    windows is stochastically larger (or smaller) than in calm windows. This
    is the significance backing for "topology changes before crashes".

Week 8:
  - crash_diagram_evolution: for each reference crash, extract the persistence
    diagram at T-30, T-20, T-10, T (trading days) and summarise how it moves --
    the raw material for the paper's crash-evolution figure.
  - gidea_katz_l2_replication: reproduce Gidea & Katz (2018)'s single scalar
    (L2 norm of the H1 Betti curve) and score ITS crash AUROC, so the paper can
    show the full pipeline improves on the prior-art scalar.
"""

from __future__ import annotations

import time

import numpy as np
import pandas as pd
from scipy.stats import mannwhitneyu

from tda.betti_curves import betti_curve, betti_curve_l2_norm
from tda.persistence import compute_persistence
from tda.tda_config import EPSILON_GRID


# ---------------------------------------------------------------------------
# Week 7 -- Mann-Whitney significance of Betti spikes
# ---------------------------------------------------------------------------

def mann_whitney_betti_test(betti_array, dates, crash_labels, dim=1,
                            epsilon_grid=EPSILON_GRID, pre_crash_days=20):
    """
    Mann-Whitney U test: is the summed beta_dim curve larger in the
    (t-pre_crash_days .. t) run-up to crashes than in all other windows?

    Uses the L2 norm of each window's beta_dim curve as the per-window scalar
    (the same summary Gidea & Katz used), then splits windows into "pre-crash"
    vs "other" and runs a one-sided Mann-Whitney U test.

    Returns dict: u_statistic, p_value, n_pre_crash, n_other, median_pre,
    median_other, direction.
    """
    dates = pd.to_datetime([str(d) for d in dates])
    if isinstance(crash_labels, pd.DataFrame):
        labels = crash_labels["crash_label"]
    else:
        labels = pd.Series(crash_labels)
    labels.index = pd.to_datetime(labels.index)

    # Per-window scalar = L2 norm of that window's Betti curve for `dim`.
    scalars = np.array([betti_curve_l2_norm(betti_array[i, :, dim])
                        for i in range(betti_array.shape[0])])

    # A window is "pre-crash" if any crash day falls within the next
    # pre_crash_days after it.
    crash_dates = labels.index[labels.astype(int) == 1]
    pre_crash_mask = np.zeros(len(dates), dtype=bool)
    for i, d in enumerate(dates):
        horizon_end = d + pd.tseries.offsets.BDay(pre_crash_days)
        if ((crash_dates >= d) & (crash_dates <= horizon_end)).any():
            pre_crash_mask[i] = True

    pre = scalars[pre_crash_mask]
    other = scalars[~pre_crash_mask]
    if len(pre) < 3 or len(other) < 3:
        return {"u_statistic": np.nan, "p_value": np.nan,
                "n_pre_crash": int(len(pre)), "n_other": int(len(other)),
                "median_pre": np.nan, "median_other": np.nan, "direction": "n/a"}

    # Two-sided first to learn direction, then report it.
    u, p = mannwhitneyu(pre, other, alternative="two-sided")
    direction = "pre-crash > calm" if np.median(pre) > np.median(other) else "pre-crash < calm"
    return {
        "u_statistic": float(u), "p_value": float(p),
        "n_pre_crash": int(len(pre)), "n_other": int(len(other)),
        "median_pre": float(np.median(pre)), "median_other": float(np.median(other)),
        "direction": direction,
    }


# ---------------------------------------------------------------------------
# Week 6 -- H2 (voids) feasibility + spike test
# ---------------------------------------------------------------------------

def h2_void_analysis(distance_matrices_by_date, crash_labels,
                     thresh=None, max_windows=40):
    """
    Compute H2 (voids) on a crash-centred sample of windows and time it.

    Parameters
    ----------
    distance_matrices_by_date : list of (date, distance_matrix) tuples.
    crash_labels : label frame/series to identify crash-adjacent windows.
    thresh : filtration cap for H2 (defaults to a truncated 1.1 for speed; H2
             on a full sqrt(2) filtration over hundreds of points is very
             expensive -- truncation is both a speed and a relevance choice,
             since RQ2 shows the signal lives well below sqrt(2)).
    max_windows : cap on how many windows to process (H2 is expensive).

    Returns
    -------
    (results_df, timing_dict). results_df has per-window beta_2 summary;
    timing_dict reports mean/max seconds per window so the team can decide
    whether full-history H2 is affordable.
    """
    if thresh is None:
        thresh = 1.1

    if isinstance(crash_labels, pd.DataFrame):
        labels = crash_labels["crash_label"]
    else:
        labels = pd.Series(crash_labels)
    labels.index = pd.to_datetime(labels.index)
    crash_dates = labels.index[labels.astype(int) == 1]

    # Prefer crash-adjacent windows; fall back to an even sample.
    scored = []
    for date, mat in distance_matrices_by_date:
        d = pd.Timestamp(date)
        near_crash = ((crash_dates >= d - pd.tseries.offsets.BDay(30)) &
                      (crash_dates <= d + pd.tseries.offsets.BDay(30))).any() if len(crash_dates) else False
        scored.append((near_crash, date, mat))
    scored.sort(key=lambda x: (not x[0]))  # crash-adjacent first
    sample = scored[:max_windows]

    rows, timings = [], []
    for near_crash, date, mat in sample:
        t0 = time.time()
        res = compute_persistence(mat, maxdim=2, thresh=thresh)
        elapsed = time.time() - t0
        timings.append(elapsed)
        h2 = res["dgms"][2] if len(res["dgms"]) > 2 else np.empty((0, 2))
        rows.append({
            "date": pd.Timestamp(date),
            "near_crash": bool(near_crash),
            "n_assets": mat.shape[0],
            "h2_n_features": int(h2.shape[0]),
            "h2_max_persistence": float((h2[:, 1] - h2[:, 0]).max()) if h2.size else 0.0,
            "h2_total_persistence": float((h2[:, 1] - h2[:, 0]).sum()) if h2.size else 0.0,
            "seconds": elapsed,
        })

    results_df = pd.DataFrame(rows)
    timing = {
        "n_windows": len(timings),
        "mean_seconds": float(np.mean(timings)) if timings else np.nan,
        "max_seconds": float(np.max(timings)) if timings else np.nan,
        "thresh": thresh,
    }
    return results_df, timing


# ---------------------------------------------------------------------------
# Week 8 -- crash-specific diagram evolution
# ---------------------------------------------------------------------------

def crash_diagram_evolution(distance_matrices_by_date, reference_crashes,
                            offsets_days=(30, 20, 10, 0)):
    """
    For each reference crash, extract H1 diagram summaries at T-offset days.

    reference_crashes : list of (name, start, end); onset = start.
    Returns a DataFrame with one row per (crash, offset) and columns
    describing the H1 diagram at that lead time (n features, max/total
    persistence). Shows the diagram "filling up" as a crash approaches.
    """
    by_date = [(pd.Timestamp(d), m) for d, m in distance_matrices_by_date]
    by_date.sort(key=lambda x: x[0])
    all_dates = np.array([d for d, _ in by_date])

    rows = []
    for name, start, _end in reference_crashes:
        onset = pd.Timestamp(start)
        for off in offsets_days:
            target = onset - pd.tseries.offsets.BDay(off)
            # nearest available window on/before target
            eligible = [i for i, d in enumerate(all_dates) if d <= target]
            if not eligible:
                rows.append({"crisis": name, "offset_days": off, "window_date": None,
                             "h1_n_features": np.nan, "h1_max_persistence": np.nan,
                             "h1_total_persistence": np.nan})
                continue
            idx = eligible[-1]
            date, mat = by_date[idx]
            res = compute_persistence(mat, maxdim=1)
            h1 = res["dgms"][1]
            life = (h1[:, 1] - h1[:, 0]) if h1.size else np.array([])
            rows.append({
                "crisis": name, "offset_days": off,
                "window_date": date.date().isoformat(),
                "h1_n_features": int(h1.shape[0]),
                "h1_max_persistence": float(life.max()) if life.size else 0.0,
                "h1_total_persistence": float(life.sum()) if life.size else 0.0,
            })
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Week 8 -- Gidea & Katz (2018) L2-norm replication
# ---------------------------------------------------------------------------

def gidea_katz_l2_replication(betti_array, dates, crash_labels,
                              dim=1, epsilon_grid=EPSILON_GRID):
    """
    Reproduce the Gidea & Katz (2018) crash indicator: the L2 norm of the H1
    Betti curve, as a single scalar per window. Score its crash AUROC so the
    paper can show the full pipeline (curves + images + Wasserstein + XGBoost)
    improves on this prior-art scalar.

    Returns dict: gk_auroc, n_windows, n_crash, plus the per-window scalar
    Series (gk_scalar) for downstream plotting / DeLong comparison against the
    full model.
    """
    from sklearn.metrics import roc_auc_score

    dates = pd.to_datetime([str(d) for d in dates])
    if isinstance(crash_labels, pd.DataFrame):
        labels = crash_labels["crash_label"]
    else:
        labels = pd.Series(crash_labels)
    labels.index = pd.to_datetime(labels.index)

    gk = np.array([betti_curve_l2_norm(betti_array[i, :, dim])
                   for i in range(betti_array.shape[0])])
    gk_series = pd.Series(gk, index=dates, name="gidea_katz_l2")

    aligned = labels.reindex(dates, method="nearest", tolerance=pd.Timedelta("5D"))
    valid = ~aligned.isna()
    y = aligned[valid].astype(int).values
    x = gk[valid.values]

    if len(np.unique(y)) < 2:
        auroc = np.nan
    else:
        raw = roc_auc_score(y, x)
        auroc = max(raw, 1 - raw)

    return {
        "gk_auroc": auroc,
        "n_windows": int(valid.sum()),
        "n_crash": int(y.sum()) if len(y) else 0,
        "gk_scalar": gk_series,
    }
