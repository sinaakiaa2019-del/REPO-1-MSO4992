"""
Multi-universe TDA runner (Kunal Jha) -- Weeks 4-5.

Weeks 1-3 (tda/run_tda.py) ran persistent homology over Octavian's PRIMARY
S&P 500 distance matrices. Weeks 4-5 extend the same machinery to every other
distance-matrix set Octavian's pipeline now produces:

  Week 4: per-GICS-sector matrices (data/processed/sectors/<Sector>/distances/)
  Week 5: robustness variants (lambda_alt, spearman) and credit/international.

Because Octavian saves all of these in the SAME NPZ format (matrix, tickers,
date), a single generic runner processes any of them and writes Betti curves,
persistence images, Wasserstein velocity, and the diagram-level feature table
into a parallel output folder -- so Sina's cross-asset and sector-leadership
ML can consume real topology features per universe instead of synthetic ones.

This module deliberately reuses tda.run_tda.compute_window (the tested,
single-window pipeline) rather than reimplementing persistence, so the sector
and robustness topology is computed by exactly the same code path as the
primary equity topology.
"""

from __future__ import annotations

import pickle
from pathlib import Path

import numpy as np
import pandas as pd

from tda.run_tda import average_correlation_from_distance, compute_window
from tda.tda_config import EPSILON_GRID
from tda.wasserstein import velocity_alert, wasserstein_velocity_series


def _load_distance_dir(distance_dir):
    """Load every distance_*.npz in a directory, sorted by embedded date."""
    distance_dir = Path(distance_dir)
    files = sorted(distance_dir.glob("distance_*.npz"))
    windows = []
    for f in files:
        data = np.load(f, allow_pickle=True)
        date = str(data["date"]) if "date" in data.files else f.stem.split("_")[-1]
        windows.append((pd.Timestamp(date), data["matrix"], f))
    windows.sort(key=lambda x: x[0])
    return windows


def run_universe_tda(distance_dir, output_dir, label="universe", verbose=True):
    """
    Run the full TDA pipeline over one directory of distance matrices.

    Parameters
    ----------
    distance_dir : path with distance_*.npz files (Octavian's format).
    output_dir   : where to write betti_curves.npz, persistence_images.npz,
                   wasserstein_velocity.csv, topology_features.csv.
    label        : short name for logging.

    Returns
    -------
    dict with the in-memory arrays and the topology_features DataFrame, or None
    if the directory has no windows.
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    windows = _load_distance_dir(distance_dir)
    if not windows:
        if verbose:
            print(f"  [{label}] no distance matrices found in {distance_dir}")
        return None

    n = len(windows)
    n_epsilon = len(EPSILON_GRID)
    betti_array = np.zeros((n, n_epsilon, 2))
    pi_array = None
    dates, diagrams_by_date, summary_rows = [], [], []

    for i, (date, matrix, _) in enumerate(windows):
        dgms, curves, summary, pi_vector = compute_window(matrix)
        betti_array[i] = curves
        if pi_array is None:
            pi_array = np.zeros((n, pi_vector.shape[0]))
        pi_array[i] = pi_vector
        dates.append(date)
        diagrams_by_date.append((date, dgms))
        summary = dict(summary)
        summary["date"] = date
        summary["n_assets"] = matrix.shape[0]
        summary["average_correlation"] = average_correlation_from_distance(matrix)
        summary_rows.append(summary)

    date_strings = np.array([str(pd.Timestamp(d).date()) for d in dates])

    np.savez_compressed(output_dir / "betti_curves.npz", betti=betti_array, dates=date_strings)
    np.savez_compressed(output_dir / "persistence_images.npz", images=pi_array, dates=date_strings)
    with open(output_dir / "persistence_diagrams.pkl", "wb") as fh:
        pickle.dump(diagrams_by_date, fh)

    wv = wasserstein_velocity_series(diagrams_by_date, dim=1)
    wv.to_frame().to_csv(output_dir / "wasserstein_velocity.csv")

    summary_df = pd.DataFrame(summary_rows).set_index("date")
    summary_df.index = pd.to_datetime(summary_df.index)
    topo = summary_df.join(wv, how="left")
    topo.to_csv(output_dir / "topology_features.csv")

    if verbose:
        print(f"  [{label}] {n} windows -> {output_dir}")
    return {
        "betti_array": betti_array, "pi_array": pi_array, "dates": date_strings,
        "topology_features": topo, "wasserstein_velocity": wv,
        "diagrams_by_date": diagrams_by_date,
    }


def run_all_sectors(sectors_root, output_root, verbose=True):
    """
    Run TDA for every per-sector distance-matrix folder under sectors_root.

    Octavian's sector_builder writes sectors/<SectorName>/distances/. This
    produces sectors_tda/<SectorName>/ with that sector's topology outputs.
    Returns dict {sector_name: result_dict}.
    """
    sectors_root = Path(sectors_root)
    output_root = Path(output_root)
    results = {}
    if not sectors_root.exists():
        if verbose:
            print(f"  No sectors root at {sectors_root}")
        return results

    for sector_dir in sorted(p for p in sectors_root.iterdir() if p.is_dir()):
        dist_dir = sector_dir / "distances"
        if not dist_dir.exists():
            continue
        res = run_universe_tda(dist_dir, output_root / sector_dir.name,
                               label=f"sector:{sector_dir.name}", verbose=verbose)
        if res is not None:
            results[sector_dir.name] = res
    return results


def wasserstein_early_warning_eval(velocity_series, crash_labels,
                                   n_std=2.0, min_periods=20):
    """
    Standalone (no-ML) evaluation of Wasserstein velocity as an early-warning
    signal -- Week 5 deliverable.

    Applies the 2-sigma rolling alert rule to the velocity series and scores
    its precision/recall against the crash labels. This is the purest
    topological crash indicator in the project: no model, no training, no
    hyperparameter tuning.

    Returns dict with precision, recall, f1, n_alerts, n_crash, tp, fp, fn.
    """
    if isinstance(crash_labels, pd.DataFrame):
        labels = crash_labels["crash_label"]
    else:
        labels = pd.Series(crash_labels)
    labels.index = pd.to_datetime(labels.index)

    alerts = velocity_alert(velocity_series, n_std=n_std, min_periods=min_periods)
    alert_dates = alerts.index[alerts.values]

    # A window is aligned to the nearest daily label within 5 trading days.
    aligned = labels.reindex(pd.to_datetime(velocity_series.index),
                             method="nearest", tolerance=pd.Timedelta("5D"))
    y_true = aligned.fillna(0).astype(int)
    y_pred = alerts.astype(int)

    tp = int(((y_pred == 1) & (y_true == 1)).sum())
    fp = int(((y_pred == 1) & (y_true == 0)).sum())
    fn = int(((y_pred == 0) & (y_true == 1)).sum())

    precision = tp / (tp + fp) if (tp + fp) > 0 else np.nan
    recall = tp / (tp + fn) if (tp + fn) > 0 else np.nan
    f1 = (2 * precision * recall / (precision + recall)
          if precision and recall and not np.isnan(precision) and not np.isnan(recall) else np.nan)

    return {
        "precision": precision, "recall": recall, "f1": f1,
        "n_alerts": int(len(alert_dates)), "n_crash": int(y_true.sum()),
        "tp": tp, "fp": fp, "fn": fn, "n_std": n_std,
    }
