"""
TDA batch runner (Kunal Jha) -- Weeks 1-3 deliverable.

Reads every rolling-window distance matrix produced by Octavian's
run_pipeline.py (data/processed/distances/*.npz, indexed by
window_metadata.csv) and produces, for the full ordered set of windows:

  - Persistence diagrams (H0, H1) for every window      -> persistence_diagrams.pkl
  - Betti curves, shape (n_windows, 200, 2)              -> betti_curves.npz
  - Persistence images (H1), shape (n_windows, 400)      -> persistence_images.npz
  - Wasserstein velocity time series                     -> wasserstein_velocity.csv
  - A flat feature table of summary statistics           -> topology_features.csv
    (persistence entropy, max/total persistence, the Gidea & Katz L2-norm
    scalar for both dimensions, Wasserstein velocity) -- a ready-made,
    already-vectorised table for anyone who wants summary features instead
    of the raw curve/image arrays.

This is the Week 2 + Week 3 deliverable from the 11-Week Plan:
  Week 2: "Working ripser pipeline producing persistence diagrams for any
           single input distance matrix" (see compute_window) + timing
           profile (the plan's "if ripser > 30s/window, flag HPC" check).
  Week 3: "Full Betti curve array (1000x200x2) + Persistence image array
           (1000x400) + Wasserstein velocity series."

Before this module existed, none of Kunal's stage had been implemented:
Sina's F1 features were necessarily built from a synthetic stand-in, and the
project's actual topological-data-analysis content -- the premise of the
whole dissertation -- had never been run on real data. Run from the project
root with:

    python -m tda.run_tda
"""

import pickle
import time

import numpy as np
import pandas as pd

from tda.betti_curves import (
    betti_curve_l2_norm,
    betti_curves_for_window,
    max_persistence,
    persistence_entropy,
    total_persistence,
)
from tda.figures import plot_betti_curves, plot_wasserstein_velocity
from tda.persistence import compute_persistence
from tda.persistence_images import persistence_image_vector
from tda.tda_config import (
    BETTI_CURVE_FILE,
    DISTANCE_DIR,
    EPSILON_GRID,
    METADATA_FILE,
    PERSISTENCE_DIAGRAM_FILE,
    PERSISTENCE_IMAGE_FILE,
    TOPOLOGY_FEATURES_FILE,
    WASSERSTEIN_VELOCITY_FILE,
    ensure_output_dirs,
)
from tda.wasserstein import wasserstein_velocity_series


def load_window_metadata(metadata_file=METADATA_FILE):
    meta = pd.read_csv(metadata_file)
    meta["date"] = pd.to_datetime(meta["date"])
    return meta.sort_values("date").reset_index(drop=True)


def load_distance_matrix(npz_path):
    data = np.load(npz_path, allow_pickle=True)
    return data["matrix"], list(data["tickers"])


def average_correlation_from_distance(distance_matrix):
    """
    Recover the average pairwise correlation implied by a Mantegna distance
    matrix (D = sqrt(2*(1-rho)) => rho = 1 - D^2/2), used only for the
    "calm vs. stressed" figure labelling in figures.py. Diagonal excluded.
    """
    n = distance_matrix.shape[0]
    if n < 2:
        return np.nan
    off_diag = distance_matrix[~np.eye(n, dtype=bool)]
    rho = 1 - (off_diag ** 2) / 2
    return float(np.mean(rho))


def compute_window(distance_matrix):
    """
    Week 2 deliverable: the full single-window pipeline (diagram -> Betti
    curve -> summary stats -> persistence image), usable standalone for a
    quick sanity check on one window, and reused inside the batch loop below.
    """
    result = compute_persistence(distance_matrix)
    dgms = result["dgms"]
    curves = betti_curves_for_window(dgms)
    h1 = dgms[1] if len(dgms) > 1 else np.empty((0, 2))
    h0 = dgms[0]
    summary = {
        "h1_persistence_entropy": persistence_entropy(h1),
        "h1_max_persistence": max_persistence(h1),
        "h1_total_persistence": total_persistence(h1),
        "h1_n_features": int(h1.shape[0]),
        "h1_betti_curve_l2_norm": betti_curve_l2_norm(curves[:, 1]),
        "h0_betti_curve_l2_norm": betti_curve_l2_norm(curves[:, 0]),
        "h0_n_features": int(h0.shape[0]),
    }
    pi_vector = persistence_image_vector(h1)
    return dgms, curves, summary, pi_vector


def run(metadata_file=METADATA_FILE, distance_dir=DISTANCE_DIR, limit=None, verbose=True):
    """
    Run the full Weeks 1-3 TDA pipeline over every window in metadata_file
    and write all handover artefacts. Returns a dict of the in-memory
    results too, so this can be called from a notebook or from run_all.py
    without re-reading the files it just wrote.
    """
    ensure_output_dirs()
    meta = load_window_metadata(metadata_file)
    if limit is not None:
        meta = meta.iloc[:limit].reset_index(drop=True)

    n_windows = len(meta)
    if n_windows == 0:
        raise ValueError(f"No windows found in {metadata_file}. Run Octavian's "
                          f"pipeline (run_pipeline.py) first.")

    n_epsilon = len(EPSILON_GRID)
    betti_array = np.zeros((n_windows, n_epsilon, 2))
    pi_array = None

    dates = []
    diagrams_by_date = []
    summary_rows = []
    timings = []

    if verbose:
        print(f"Running TDA pipeline on {n_windows} windows "
              f"(epsilon grid: {n_epsilon} points, 0 to {EPSILON_GRID[-1]:.4f})...")

    for i, row in meta.iterrows():
        t0 = time.time()
        matrix, tickers = load_distance_matrix(row["distance_file"])
        dgms, curves, summary, pi_vector = compute_window(matrix)
        elapsed = time.time() - t0

        betti_array[i] = curves
        if pi_array is None:
            pi_array = np.zeros((n_windows, pi_vector.shape[0]))
        pi_array[i] = pi_vector

        dates.append(row["date"])
        diagrams_by_date.append((row["date"], dgms))

        summary = dict(summary)
        summary["date"] = row["date"]
        summary["n_assets"] = matrix.shape[0]
        summary["average_correlation"] = average_correlation_from_distance(matrix)
        summary_rows.append(summary)
        timings.append(elapsed)

        if verbose and (i % max(1, n_windows // 10) == 0 or i == n_windows - 1):
            print(f"  window {i + 1}/{n_windows}  date={pd.Timestamp(row['date']).date()}  "
                  f"n_assets={matrix.shape[0]}  H1 features={len(dgms[1])}  "
                  f"{elapsed * 1000:.1f} ms")

    date_strings = np.array([str(pd.Timestamp(d).date()) for d in dates])

    # --- Save handover artefacts ---
    np.savez_compressed(BETTI_CURVE_FILE, betti=betti_array, dates=date_strings)
    np.savez_compressed(PERSISTENCE_IMAGE_FILE, images=pi_array, dates=date_strings)
    with open(PERSISTENCE_DIAGRAM_FILE, "wb") as f:
        pickle.dump(diagrams_by_date, f)

    wv = wasserstein_velocity_series(diagrams_by_date, dim=1)
    wv.to_frame().to_csv(WASSERSTEIN_VELOCITY_FILE)

    summary_df = pd.DataFrame(summary_rows).set_index("date")
    summary_df.index = pd.to_datetime(summary_df.index)
    topology_features = summary_df.join(wv, how="left")
    topology_features.to_csv(TOPOLOGY_FEATURES_FILE)

    timing_summary = {
        "n_windows": n_windows,
        "mean_seconds_per_window": float(np.mean(timings)),
        "max_seconds_per_window": float(np.max(timings)),
        "total_seconds": float(np.sum(timings)),
    }

    if verbose:
        print("\nDone.")
        print(f"  Betti curves:         {BETTI_CURVE_FILE}  shape={betti_array.shape}")
        print(f"  Persistence images:   {PERSISTENCE_IMAGE_FILE}  shape={pi_array.shape}")
        print(f"  Persistence diagrams: {PERSISTENCE_DIAGRAM_FILE}  ({len(diagrams_by_date)} windows)")
        print(f"  Wasserstein velocity: {WASSERSTEIN_VELOCITY_FILE}  n={len(wv)}")
        print(f"  Topology features:    {TOPOLOGY_FEATURES_FILE}  shape={topology_features.shape}")
        print(f"  Timing: mean={timing_summary['mean_seconds_per_window'] * 1000:.2f} ms/window, "
              f"max={timing_summary['max_seconds_per_window'] * 1000:.2f} ms/window, "
              f"total={timing_summary['total_seconds']:.2f} s for {n_windows} windows")
        if timing_summary["max_seconds_per_window"] > 30:
            print("  WARNING: a window exceeded the plan's 30s/window threshold "
                  "(11-Week Plan, Week 2) -- consider ripser++, truncating the "
                  "filtration below sqrt(2), or HPC for the full S&P 500 run.")

    betti_fig = plot_betti_curves(
        betti_array, date_strings,
        average_correlation=summary_df["average_correlation"].to_numpy(),
    )
    wv_fig = None
    if len(wv) >= 20:
        wv_fig = plot_wasserstein_velocity(wv)
    if verbose:
        print(f"  Figure:               {betti_fig}")
        if wv_fig:
            print(f"  Figure:               {wv_fig}")
        else:
            print("  Wasserstein velocity figure skipped (need >= 20 windows for the rolling band)")

    return {
        "betti_array": betti_array,
        "pi_array": pi_array,
        "dates": date_strings,
        "topology_features": topology_features,
        "wasserstein_velocity": wv,
        "diagrams_by_date": diagrams_by_date,
        "timing": timing_summary,
    }


if __name__ == "__main__":
    run()
