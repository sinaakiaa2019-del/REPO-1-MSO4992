"""
Run the full pipeline end to end:
  Stage 1  Data (Octavian)        -> returns, EWMA/Mantegna matrices, labels, macro
  Stage 2  TDA Weeks 1-3 (Kunal)  -> Betti curves, persistence images, Wasserstein velocity
  Stage 3  TDA Weeks 4-8 (Kunal)  -> filtration sensitivity, significance, H2, Gidea-Katz, sectors
  Stage 4  ML (Sina)              -> F1/F2/F3, DeLong, leave-one-crisis-out, SHAP, lead time

Usage:
    python run_all.py --demo        # signal-bearing synthetic data, no network
    python run_all.py               # real data: yfinance + FRED (needs network)

Each stage still runs standalone (run_pipeline.py, tda/run_tda.py,
tda/run_tda_weeks4_8.py, run_ml*.py). This chains them with one timing summary
so the cross-team interface contract is validated on every run, not just read.
"""

import argparse
import time

import config


def main():
    parser = argparse.ArgumentParser(description="Run the full TDA crash-prediction pipeline.")
    parser.add_argument("--demo", action="store_true",
                        help="Use signal-bearing synthetic data (no network).")
    parser.add_argument("--limit-windows", type=int, default=None,
                        help="Cap TDA windows (quick smoke test on a large real universe).")
    args = parser.parse_args()

    config.make_project_folders()
    t0 = time.time()

    if args.demo:
        # The demo path uses the crash-bearing synthetic generator so every
        # downstream metric is finite and meaningful, then runs the two TDA
        # stages and a compact ML check -- see demo_end_to_end.py.
        print("=" * 70)
        print("DEMO MODE -- signal-bearing synthetic data, full stack")
        print("=" * 70)
        import demo_end_to_end
        demo_end_to_end.main()
        print(f"\nTotal: {time.time() - t0:.1f}s")
        return

    import runpy

    import run_pipeline
    from tda import run_tda
    from tda.run_tda_weeks4_8 import run as run_tda48

    print("=" * 70); print("STAGE 1/4 -- Data pipeline (Octavian)"); print("=" * 70)
    run_pipeline.main(use_demo=False)
    t1 = time.time()

    print("\n" + "=" * 70); print("STAGE 2/4 -- TDA Weeks 1-3 (Kunal)"); print("=" * 70)
    run_tda.run(limit=args.limit_windows)
    t2 = time.time()

    print("\n" + "=" * 70); print("STAGE 3/4 -- TDA Weeks 4-8 (Kunal)"); print("=" * 70)
    run_tda48()
    t3 = time.time()

    print("\n" + "=" * 70); print("STAGE 4/4 -- ML pipeline (Sina)"); print("=" * 70)
    runpy.run_path("run_ml.py", run_name="__main__")
    t4 = time.time()

    print("\n" + "=" * 70); print("ALL STAGES COMPLETE"); print("=" * 70)
    print(f"  Stage 1 (data):        {t1 - t0:.1f}s")
    print(f"  Stage 2 (tda 1-3):     {t2 - t1:.1f}s")
    print(f"  Stage 3 (tda 4-8):     {t3 - t2:.1f}s")
    print(f"  Stage 4 (ml):          {t4 - t3:.1f}s")
    print(f"  Total:                 {t4 - t0:.1f}s")


if __name__ == "__main__":
    main()
