"""
ML & Validation orchestrator (Sina Kia) — Week 6.

Run AFTER run_ml.py. Reuses Weeks 1-3 state (returns, crash labels, equity
F1/F2) and rebuilds F3 exactly like Week 4 does, rather than recomputing
anything differently.

  python run_ml_week6.py

Deliverables:
  - Ablation AUROC table: leave-one-feature-group-out on F3.
  - Calibration curve: reliability diagram + Brier score + ECE on
    out-of-sample F3 probabilities.
  - CV robustness: mean AUROC / PR-AUC across several CV configurations
    (fold count, initial train fraction, purge gap), including a known-bad
    no-purge-gap control to sanity-check the leakage guard is doing its job.
"""

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from ml import ml_config
from ml.ablation import run_ablation
from ml.calibration import (
    brier_score,
    compute_calibration_curve,
    expected_calibration_error,
    save_calibration_plot,
)
from ml.cv_robustness import run_cv_robustness, summarise_robustness
from ml.f3_combined_features import build_f1_f2_f3
from ml.lead_time_analysis import out_of_sample_probabilities
from run_ml import main as run_weeks_1_to_3


def banner(text):
    print("\n" + "=" * 64)
    print(text)
    print("=" * 64)


def main():
    ml_config.ensure_output_dirs()

    banner("Reusing Weeks 1-3 (returns, crash labels, equity F1/F2) + building F3")
    state = run_weeks_1_to_3()
    crash_labels = state["crash_labels"]
    aligned, y = build_f1_f2_f3(state["f1_features"], state["f2_features"], crash_labels)
    X3 = aligned["F3"]
    print(f"  F3: {X3.shape[0]} rows x {X3.shape[1]} features, {int(y.sum())} positive")

    # ---------------- Week 6: ablation ----------------
    banner("WEEK 6  Leave-one-feature-group-out ablation (F3)")
    ablation_table = run_ablation(
        X3, y,
        f1_columns=X3.attrs["f1_columns"],
        f2_columns=X3.attrs["f2_columns"],
    )
    print(ablation_table.to_string(index=False))
    ablation_table.to_csv(ml_config.ABLATION_TABLE_FILE, index=False)
    print(f"  Saved: {ml_config.ABLATION_TABLE_FILE}")

    valid_ablation = ablation_table.dropna(subset=["mean_auroc"])
    if not valid_ablation.empty:
        worst_to_remove = valid_ablation.loc[valid_ablation["delta_auroc_vs_full"].idxmax()]
        print(f"  Largest AUROC drop from removing a group: "
              f"'{worst_to_remove['ablation']}' "
              f"(delta={worst_to_remove['delta_auroc_vs_full']:+.3f})")

    # ---------------- Week 6: calibration ----------------
    banner("WEEK 6  Calibration curve (F3, out-of-sample)")
    proba = out_of_sample_probabilities(X3, y)
    if proba.empty:
        print("  No out-of-sample probabilities produced -- skipping calibration.")
    else:
        y_oos = y.loc[proba.index]
        calibration_table = compute_calibration_curve(
            proba.values, y_oos.values, n_bins=ml_config.CALIBRATION_N_BINS,
        )
        brier = brier_score(proba.values, y_oos.values)
        ece = expected_calibration_error(calibration_table)
        print(calibration_table.to_string(index=False))
        print(f"  Brier score = {brier:.4f}   ECE = {ece:.4f}"
              if pd_notna(ece) else f"  Brier score = {brier:.4f}   ECE = NaN (no non-empty bins)")

        calibration_table.to_csv(ml_config.CALIBRATION_TABLE_FILE, index=False)
        print(f"  Saved: {ml_config.CALIBRATION_TABLE_FILE}")

        save_calibration_plot(
            calibration_table, ml_config.CALIBRATION_PLOT_FILE,
            title="F3 calibration curve (out-of-sample)", brier=brier, ece=ece,
        )
        print(f"  Plot saved: {ml_config.CALIBRATION_PLOT_FILE}")

    # ---------------- Week 6: CV robustness ----------------
    banner("WEEK 6  CV robustness (fold count / initial train / purge gap)")
    robustness_table = run_cv_robustness(X3, y)
    print(robustness_table.to_string(index=False))
    robustness_table.to_csv(ml_config.CV_ROBUSTNESS_TABLE_FILE, index=False)
    print(f"  Saved: {ml_config.CV_ROBUSTNESS_TABLE_FILE}")
    print(summarise_robustness(robustness_table))

    banner("DONE (Week 6)")
    print(f"Reports: {ml_config.ML_REPORT_DIR}")
    print(f"Figures: {ml_config.ML_FIGURE_DIR}")


def pd_notna(x):
    import pandas as pd
    return pd.notna(x)


if __name__ == "__main__":
    main()
