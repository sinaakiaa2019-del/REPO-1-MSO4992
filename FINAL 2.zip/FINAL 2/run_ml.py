"""
ML & Validation orchestrator (Sina Kia) — Weeks 1-3.

Run this from the project root:   python run_ml.py

Executes Sina's deliverables in order and writes outputs into
outputs/ml_reports and outputs/figures:

  Week 1  - expanding-window CV skeleton (ml/cross_validation.py)
  Week 2  - crash labels (index/SPY based) + reference-crash verification
          - F2 standard feature set
          - 5-fold expanding-window CV XGBoost baseline AUROC per fold
  Week 3  - class-balance + scale_pos_weight note
          - time-series-safe random search on F2
          - SHAP TreeExplainer + F2 beeswarm PNG
          - F1 (topology-only) feature matrix from Betti curves
          - F1 vs F2 AUROC comparison table

Data sourcing
-------------
For every real artefact (returns, macro features, crash labels, Betti curves)
the runner uses the real file if it exists, and otherwise falls back to the
synthetic generator so the whole sequence runs end-to-end today. Each
fallback is printed clearly.
"""

import sys
from pathlib import Path

import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from ml import ml_config
from ml.cross_validation import ExpandingWindowSplit, describe_splits
from ml.crash_labels import (
    build_crash_labels_from_index,
    build_crash_labels_from_returns,
    class_balance,
    verify_reference_crashes,
)
from ml.data_access import align_features_labels, align_multiple, load_returns
from ml.f1_topology_features import build_f1_from_betti_array, load_f1_features
from ml.f2_standard_features import build_f2_features, summarise_f2
from ml.models import (
    compare_feature_sets,
    cross_validated_auroc,
    time_series_random_search,
)
from ml.shap_analysis import compute_shap_values, mean_abs_importance, save_beeswarm
from ml import synthetic_data


def banner(text):
    print("\n" + "=" * 64)
    print(text)
    print("=" * 64)


def load_returns_or_synthetic():
    if Path(ml_config.RETURNS_FILE).exists():
        print(f"[real] returns: {ml_config.RETURNS_FILE}")
        return load_returns(ml_config.RETURNS_FILE), False
    print("[synthetic] returns file not found -> generating synthetic returns")
    return synthetic_data.make_synthetic_returns(), True


def load_macro_or_synthetic(returns):
    if Path(ml_config.MACRO_FEATURES_FILE).exists():
        print(f"[real] macro features: {ml_config.MACRO_FEATURES_FILE}")
        df = pd.read_csv(ml_config.MACRO_FEATURES_FILE, index_col=0)
        df.index = pd.to_datetime(df.index)
        return df, False
    if Path(ml_config.BASELINE_FEATURES_FILE).exists():
        print(f"[real] baseline features (fallback for F2): {ml_config.BASELINE_FEATURES_FILE}")
        df = pd.read_csv(ml_config.BASELINE_FEATURES_FILE, index_col=0)
        df.index = pd.to_datetime(df.index)
        return df, False
    print("[synthetic] no macro/baseline features found -> generating synthetic macro")
    return synthetic_data.make_synthetic_macro(returns), True


def load_betti_or_synthetic(returns):
    try:
        f1, source = load_f1_features(
            topology_csv_path=ml_config.TOPOLOGY_FEATURES_FILE,
            betti_npz_path=ml_config.BETTI_CURVE_FILE,
        )
        print(f"[real] F1 topology features: {source}")
        return f1
    except FileNotFoundError:
        print("[synthetic] no Betti/topology handover found -> generating synthetic Betti curves")
        betti_array, dates = synthetic_data.make_synthetic_betti(returns)
        return build_f1_from_betti_array(betti_array, dates)


def main():
    ml_config.ensure_output_dirs()
    synthetic_used = False

    # ---------------- Week 1: CV skeleton ----------------
    banner("WEEK 1  Expanding-window CV skeleton")
    splitter = ExpandingWindowSplit(
        n_splits=ml_config.N_CV_FOLDS,
        initial_train_fraction=ml_config.INITIAL_TRAIN_FRACTION,
        purge_gap=ml_config.PURGE_GAP,
    )
    print(f"  {ml_config.N_CV_FOLDS} folds, "
          f"initial_train_fraction={ml_config.INITIAL_TRAIN_FRACTION}, "
          f"purge_gap={ml_config.PURGE_GAP}")

    returns, ret_synth = load_returns_or_synthetic()
    synthetic_used = synthetic_used or ret_synth
    print(f"  Returns: {returns.shape[0]} rows x {returns.shape[1]} assets")

    fold_summary = describe_splits(splitter, len(returns))
    for f in fold_summary:
        print(f"    fold {f['fold']}: train={f['train_size']} test={f['test_size']}")

    # ---------------- Week 2: crash labels ----------------
    banner("WEEK 2  Crash labels + reference-crash verification")
    if not ret_synth:
        # Real returns: fall back to the equal-weighted portfolio proxy until a
        # real SPY index series is wired in (documented known issue -- the plan
        # specifies SPY specifically; see ml/crash_labels.py docstring).
        crash_labels = build_crash_labels_from_returns(returns)
    else:
        # Synthetic returns only carry a correlation shock, not a drawdown, so
        # build_crash_labels_from_returns on them produces zero crashes. Use the
        # drift-and-vol-shocked synthetic INDEX instead, which is the intended
        # stand-in for SPY and actually draws down in the three stress windows.
        print("[synthetic] using make_synthetic_index (SPY stand-in) for crash labels")
        synthetic_index = synthetic_data.make_synthetic_index()
        crash_labels = build_crash_labels_from_index(synthetic_index)
    verification = verify_reference_crashes(crash_labels)
    print(verification.to_string(index=False))
    if not verification["fired"].all():
        print("  WARNING: not every reference crisis fired a positive label.")
    verification.to_csv(ml_config.ML_REPORT_DIR / "reference_crash_verification.csv", index=False)

    # ---------------- Week 2: F2 baseline ----------------
    banner("WEEK 2  F2 standard feature set + XGBoost baseline")
    macro_df, macro_synth = load_macro_or_synthetic(returns)
    synthetic_used = synthetic_used or macro_synth
    f2_features, provenance = build_f2_features(macro_df=macro_df)
    print(summarise_f2(f2_features, provenance))

    X2, y = align_features_labels(f2_features, crash_labels)
    print(f"  Aligned F2 rows: {len(X2)}")

    f2_cv = cross_validated_auroc(X2, y)
    f2_table = pd.DataFrame(f2_cv["fold_detail"])
    print(f2_table.to_string(index=False))
    print(f"  F2 mean AUROC = {f2_cv['mean_auroc']:.3f} +/- {f2_cv['std_auroc']:.3f}"
          if not pd.isna(f2_cv["mean_auroc"]) else "  F2 mean AUROC = NaN (all folds single-class)")
    if f2_cv["single_class_folds"] > 0:
        print(f"  NOTE: {f2_cv['single_class_folds']} / {f2_cv['n_total_folds']} folds were single-class.")
        print("  Crashes are rare and time-clustered, so some expanding folds are")
        print("  single-class. With real data, consider fewer folds, a larger initial")
        print("  train fraction, or reporting PR-AUC alongside AUROC (Week 5 task).")
    f2_table.to_csv(ml_config.F2_BASELINE_AUROC_FILE, index=False)

    # ---------------- Week 3: class balance ----------------
    banner("WEEK 3  Class balance + scale_pos_weight")
    balance = class_balance(crash_labels)
    print(balance)
    pd.DataFrame([balance]).to_csv(ml_config.CLASS_BALANCE_FILE, index=False)

    # ---------------- Week 3: random search ----------------
    banner("WEEK 3  Time-series-safe random search on F2")
    search = time_series_random_search(X2, y, n_iter=ml_config.N_SEARCH_ITERATIONS)
    print(f"  Best F2 mean AUROC = {search['best_mean_auroc']:.3f} "
          f"+/- {search['best_std_auroc']:.3f}")
    tuned = {k: v for k, v in search["best_params"].items()
             if k in ml_config.XGB_SEARCH_SPACE}
    print(f"  Best params (searched): {tuned}")
    search["results_table"].to_csv(ml_config.TUNING_RESULT_FILE, index=False)

    # ---------------- Week 3: SHAP on F2 ----------------
    banner("WEEK 3  SHAP TreeExplainer + F2 beeswarm")
    f2_full = cross_validated_auroc(X2, y, return_models=True)
    last_model = f2_full["models"][-1]
    shap_values, _ = compute_shap_values(last_model, X2)
    importance = mean_abs_importance(shap_values, list(X2.columns))
    print(importance.to_string(index=False))
    importance.to_csv(ml_config.ML_REPORT_DIR / "f2_shap_importance.csv", index=False)
    save_beeswarm(shap_values, X2, ml_config.SHAP_BEESWARM_FILE,
                  title="SHAP beeswarm - F2 standard model")
    print(f"  Beeswarm saved: {ml_config.SHAP_BEESWARM_FILE}")

    # ---------------- Week 3: F1 + comparison ----------------
    banner("WEEK 3  F1 topology features + F1 vs F2 comparison")
    f1_features = load_betti_or_synthetic(returns)
    print(f"  F1 matrix: {f1_features.shape[0]} rows x {f1_features.shape[1]} features")

    aligned, y_common = align_multiple({"F1": f1_features, "F2": f2_features}, crash_labels)
    print(f"  Common rows for fair F1/F2 comparison: {len(y_common)}")
    comparison = compare_feature_sets(aligned, y_common)
    print(comparison.to_string(index=False))
    comparison.to_csv(ml_config.F1_VS_F2_TABLE_FILE, index=False)

    banner("DONE (Weeks 1-3)")
    if synthetic_used:
        print("NOTE: synthetic stand-in data was used for one or more inputs.")
        print("Drop the real artefacts into data/processed/ and rerun; the same")
        print("code will consume them with no changes.")
    print(f"Reports: {ml_config.ML_REPORT_DIR}")
    print(f"Figures: {ml_config.ML_FIGURE_DIR}")

    return {
        "returns": returns,
        "crash_labels": crash_labels,
        "f1_features": f1_features,
        "f2_features": f2_features,
        "aligned": aligned,
        "y_common": y_common,
        "synthetic_used": synthetic_used,
    }


if __name__ == "__main__":
    main()
