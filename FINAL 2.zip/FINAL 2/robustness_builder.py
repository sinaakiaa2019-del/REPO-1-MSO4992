"""
Robustness variants for the primary EWMA pipeline.

Two alternative distance matrix sets are produced to verify the TDA crash
signal is stable across methodological choices:
  1. Alt-lambda  : EWMA with lambda=0.97 (effective memory ~33 days vs ~17 days)
  2. Spearman    : rank-based correlation, more robust to heavy-tailed returns

Both produce the same NPZ format as the primary pipeline so the TDA stage
can process them without modification.
"""
import numpy as np
import pandas as pd
from scipy.stats import spearmanr

from config import EWMA_INIT_DAYS, EWMA_LAMBDA_ALT, MIN_VALID_FRACTION, ROBUSTNESS_DIR, STEP_SIZE
from matrix_builder import (
    build_ewma_rolling_matrices,
    check_distance_matrix,
    correlation_to_distance,
    create_distance_embedding,
)


def build_alt_lambda_matrices(
    returns,
    robustness_dir=ROBUSTNESS_DIR,
    lam_alt=EWMA_LAMBDA_ALT,
    init_days=EWMA_INIT_DAYS,
    step_size=STEP_SIZE,
):
    """Recompute EWMA matrices with lambda=0.97 for sensitivity analysis."""
    corr_dir = robustness_dir / "lambda_alt" / "correlations"
    dist_dir = robustness_dir / "lambda_alt" / "distances"
    corr_dir.mkdir(parents=True, exist_ok=True)
    dist_dir.mkdir(parents=True, exist_ok=True)

    meta, _ = build_ewma_rolling_matrices(
        returns, corr_dir, dist_dir,
        lam=lam_alt, init_days=init_days, step_size=step_size,
    )
    meta.to_csv(robustness_dir / "lambda_alt_metadata.csv", index=False)
    print(f"  Robustness (lambda={lam_alt}): {len(meta)} windows saved.")
    return meta


def build_spearman_matrices(
    returns,
    robustness_dir=ROBUSTNESS_DIR,
    rolling_window=60,
    step_size=STEP_SIZE,
    min_valid_fraction=MIN_VALID_FRACTION,
):
    """
    Build distance matrices using Spearman rank correlation.
    Spearman does not assume normality and is more robust to the fat-tailed
    return distributions that occur during crisis periods.
    """
    corr_dir = robustness_dir / "spearman" / "correlations"
    dist_dir = robustness_dir / "spearman" / "distances"
    corr_dir.mkdir(parents=True, exist_ok=True)
    dist_dir.mkdir(parents=True, exist_ok=True)

    arr      = returns.values.astype(float)
    n_obs, n_assets = arr.shape
    tickers  = np.array(list(returns.columns))
    metadata       = []
    flat_distances = []
    window_id      = 0

    for end_pos in range(rolling_window, n_obs, step_size):
        window = arr[end_pos - rolling_window: end_pos]

        # PER-WINDOW UNIVERSE (mirrors the EWMA path in matrix_builder.py).
        #
        # The original implementation dropped every ROW (day) that had a NaN in
        # ANY of the ~461 columns. On a wide, staggered-listing S&P 500 panel
        # almost every 60-day window has at least one not-yet-listed stock, so
        # nearly every row was discarded and the whole variant collapsed to a
        # handful of usable windows. Instead, we select the COLUMNS (stocks)
        # that have >= MIN_VALID_FRACTION valid returns in this window, then
        # keep the rows where those active stocks are jointly observed. This is
        # exactly the active-stock logic the primary EWMA matrices use, so the
        # Spearman robustness variant is now genuinely comparable to the
        # primary pipeline rather than being computed on a different (tiny)
        # sample.
        valid_ratio = 1.0 - np.isnan(window).mean(axis=0)
        active_idx  = np.where(valid_ratio >= min_valid_fraction)[0]
        if len(active_idx) < 3:
            window_id += 1
            continue

        sub          = window[:, active_idx]
        window_clean = sub[~np.isnan(sub).any(axis=1)]
        if window_clean.shape[0] < 10 or window_clean.shape[1] < 2:
            window_id += 1
            continue

        corr_mat, _ = spearmanr(window_clean)
        corr_mat = np.atleast_2d(corr_mat)
        corr_mat = np.clip(corr_mat, -1, 1)
        np.fill_diagonal(corr_mat, 1.0)

        dist = correlation_to_distance(corr_mat)
        try:
            check_distance_matrix(dist)
        except ValueError:
            window_id += 1
            continue

        active_tickers = tickers[active_idx]
        date_text = pd.Timestamp(returns.index[end_pos - 1]).strftime("%Y-%m-%d")
        corr_file = corr_dir / f"correlation_{window_id:04d}_{date_text}.npz"
        dist_file = dist_dir / f"distance_{window_id:04d}_{date_text}.npz"

        np.savez_compressed(corr_file, matrix=corr_mat, tickers=active_tickers, date=date_text)
        np.savez_compressed(dist_file, matrix=dist,     tickers=active_tickers, date=date_text)

        metadata.append({
            "window_id":        window_id,
            "date":             date_text,
            "n_assets":         len(active_idx),
            "method":           "spearman",
            "correlation_file": str(corr_file),
            "distance_file":    str(dist_file),
        })
        flat_distances.append(dist.flatten())
        window_id += 1

    meta_df = pd.DataFrame(metadata)
    if not meta_df.empty:
        meta_df.to_csv(robustness_dir / "spearman_metadata.csv", index=False)
    print(f"  Robustness (Spearman): {len(meta_df)} windows saved.")
    return meta_df
