import numpy as np
import pandas as pd

from config import (
    END_DATE, FRED_SERIES, SP500_CHANGES_FILE, SP500_TICKERS_FILE, START_DATE,
)


def create_demo_prices(tickers=None, rows=1500, seed=42):
    """Generate synthetic GBM prices for offline testing — no network required."""
    if tickers is None:
        tickers = [f"STOCK_{i:03d}" for i in range(20)]
    np.random.seed(seed)
    dates = pd.bdate_range(end=pd.Timestamp.today().normalize(), periods=rows)
    n = len(dates)  # use the ACTUAL number of dates, not the requested `rows`
    prices = pd.DataFrame(index=dates)
    for ticker in tickers:
        dr = np.random.normal(0.0003, 0.012, n)
        prices[ticker] = 100 * np.exp(np.cumsum(dr))
    return prices


def download_sp500_constituents(cache=True):
    """Fetch S&P 500 members and historical changes from Wikipedia, cached to CSV."""
    if cache and SP500_TICKERS_FILE.exists() and SP500_CHANGES_FILE.exists():
        current = pd.read_csv(SP500_TICKERS_FILE)
        changes = pd.read_csv(SP500_CHANGES_FILE)
        changes["date"] = pd.to_datetime(changes["date"])
        return current, changes

    import requests
    from io import StringIO

    resp = requests.get(
        "https://en.wikipedia.org/wiki/List_of_S%26P_500_companies",
        headers={"User-Agent": "Mozilla/5.0 (research project, academic use)"},
        timeout=30,
    )
    resp.raise_for_status()
    tables = pd.read_html(StringIO(resp.text), header=0)

    raw = tables[0]
    current = raw[["Symbol", "Security", "GICS Sector", "GICS Sub-Industry"]].copy()
    current.columns = ["ticker", "name", "gics_sector", "gics_sub_industry"]
    current["ticker"] = current["ticker"].str.replace(".", "-", regex=False).str.strip()

    raw_ch = tables[1].copy()
    raw_ch.columns = [c[1] if isinstance(c, tuple) else c for c in raw_ch.columns]
    raw_ch.columns = [str(c).strip() for c in raw_ch.columns]

    records = []
    for _, row in raw_ch.iterrows():
        try:
            date = pd.to_datetime(str(row.iloc[0]).strip())
        except Exception:
            continue
        for col_idx, action in [(1, "added"), (3, "removed")]:
            if col_idx < len(row):
                raw_ticker = str(row.iloc[col_idx]).strip().replace(".", "-")
                if raw_ticker and raw_ticker.lower() not in ("nan", "", "none"):
                    records.append({"date": date, "action": action, "ticker": raw_ticker})

    changes = (
        pd.DataFrame(records)
        if records
        else pd.DataFrame(columns=["date", "action", "ticker"])
    )

    if cache:
        SP500_TICKERS_FILE.parent.mkdir(parents=True, exist_ok=True)
        current.to_csv(SP500_TICKERS_FILE, index=False)
        changes.to_csv(SP500_CHANGES_FILE, index=False)

    return current, changes


def get_sp500_at_date(target_date, current_members, changes):
    """Reconstruct point-in-time S&P 500 membership by reversing post-date changes."""
    target_date = pd.Timestamp(target_date)
    members = set(current_members["ticker"].tolist())

    if changes is not None and not changes.empty:
        ch = changes.copy()
        ch["date"] = pd.to_datetime(ch["date"])
        future = ch[ch["date"] > target_date]
        for _, row in future.iterrows():
            t = str(row["ticker"]).strip()
            if row["action"] == "added":
                members.discard(t)
            elif row["action"] == "removed":
                members.add(t)

    return sorted(members)


def build_full_ticker_universe(current_members, membership_changes):
    """Union of current constituents AND every ticker ever added or removed.

    For a genuinely survivorship-bias-free download we must fetch prices for
    firms that were deleted from the index during the sample (Lehman, Bear
    Stearns, Wachovia, ...), not just today's members. Those tickers appear in
    the 'removed' rows of the changes table. This returns the full historical
    union so download_sp500_prices pulls all of them; the point-in-time
    membership logic in matrix_builder then decides which are active per window.
    """
    tickers = set()
    if isinstance(current_members, pd.DataFrame):
        tickers.update(current_members["ticker"].astype(str).tolist())
    elif current_members is not None:
        tickers.update(list(current_members))

    if membership_changes is not None and not membership_changes.empty:
        tickers.update(membership_changes["ticker"].astype(str).tolist())

    # Drop obvious non-tickers
    tickers = {t.strip() for t in tickers if t and t.strip().lower() not in ("nan", "none", "")}
    return sorted(tickers)


def download_sp500_prices(
    start_date=START_DATE,
    end_date=END_DATE,
    current_members=None,
    membership_changes=None,
    batch_size=100,
):
    """Download daily adjusted close prices via yfinance, batched to avoid rate limits.

    If membership_changes is provided, the download universe is the full
    historical union (current members + every ticker ever added/removed), so
    delisted firms are included -- a prerequisite for the survivorship-bias
    correction in matrix_builder.build_ewma_rolling_matrices. Some delisted
    tickers will no longer resolve on Yahoo Finance; those simply come back
    empty and are dropped, which is logged rather than silently ignored.
    """
    import yfinance as yf

    if membership_changes is not None:
        tickers = build_full_ticker_universe(current_members, membership_changes)
    elif current_members is None:
        current_df, _ = download_sp500_constituents()
        tickers = current_df["ticker"].tolist()
    elif isinstance(current_members, pd.DataFrame):
        tickers = current_members["ticker"].tolist()
    else:
        tickers = list(current_members)

    all_frames = []
    n_batches = (len(tickers) - 1) // batch_size + 1

    for i in range(0, len(tickers), batch_size):
        batch = tickers[i: i + batch_size]
        print(f"  Batch {i // batch_size + 1}/{n_batches} ({len(batch)} tickers)...")
        try:
            raw = yf.download(
                tickers=batch,
                start=start_date,
                end=end_date,
                auto_adjust=True,
                progress=False,
                group_by="column",
                threads=True,
            )
            if raw.empty:
                continue
            closes = (
                raw["Close"].copy()
                if isinstance(raw.columns, pd.MultiIndex)
                else raw[["Close"]].rename(columns={"Close": batch[0]})
            )
            all_frames.append(closes)
        except Exception as exc:
            print(f"  Batch failed: {exc} — skipping.")

    if not all_frames:
        raise ValueError("No price data was downloaded.")

    prices = pd.concat(all_frames, axis=1)
    prices = prices.loc[:, ~prices.columns.duplicated()]
    return prices.dropna(axis=1, how="all").sort_index()


def download_fred_macro(start_date=START_DATE, end_date=END_DATE):
    """Download macro series from FRED. Raises RuntimeError if unreachable."""
    try:
        import pandas_datareader.data as web
    except ImportError:
        raise RuntimeError("pandas_datareader is not installed. Run: pip install pandas-datareader")

    end = end_date or pd.Timestamp.today().strftime("%Y-%m-%d")
    df = web.DataReader(list(FRED_SERIES.keys()), "fred", start_date, end)
    df.columns = list(FRED_SERIES.values())
    df = df.dropna(how="all").sort_index()
    print(f"  [FRED] {df.shape[1]} series, {len(df)} rows.")
    return df
