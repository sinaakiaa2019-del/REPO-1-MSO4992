# Integration + Completion Plan

## Base: Octavian W8 (data) + Sina W8 (ml) + Kunal weeks1-3 TDA, extended to W8

## KUNAL — extend TDA from weeks 1-3 to weeks 4-8 (the main new work)
- [ ] W4: filtration sensitivity (AUROC vs epsilon) — single-scale Betti vs crash label -> RQ2
- [ ] W4: sector-level TDA runner (consume Octavian's per-sector distance matrices)
- [ ] W5: Wasserstein velocity precision/recall standalone early-warning eval
- [ ] W5: run TDA on robustness variants (lambda_alt, spearman) + international/credit
- [ ] W6: vectorisation ablation (betti / images / scalars / wasserstein) hand to Sina
- [ ] W6: H2 (voids) computation on crash-window sample + timing/feasibility
- [ ] W7: publication persistence diagram figures (calm/pre-crash/post-crash)
- [ ] W7: Mann-Whitney significance test of Betti spikes crash vs normal
- [ ] W8: crash-specific persistence diagram evolution (T-30,-20,-10,T)
- [ ] W8: Gidea & Katz L2-norm replication + comparison
- [ ] DeLong test (shared util — Sina needs it too)
- [ ] tests for all new TDA modules

## OCTAVIAN — fix bugs found in review
- [ ] BUG1 (serious): point-in-time membership built+tested but NEVER used -> wire get_sp500_at_date into pipeline OR honestly downgrade claim. Implement proper wiring.
- [ ] BUG2: Spearman robustness drops any row with ANY nan (collapses wide panel) -> per-window active-stock filter
- [ ] BUG3: crash labels mix log returns with (1+r).cumprod() -> use exp(cumsum)
- [ ] BUG4: topology loader npz key mismatch ('betti_curves'/'curves' vs Kunal's 'betti')
- [ ] BUG5 (cosmetic): Mantegna range claim [0,sqrt2] wrong -> [0,2]
- [ ] international_builder is a dead stub -> either implement or wire real data

## SINA — fix gaps found in review
- [ ] GAP1: DeLong test not implemented (required for F1/F3 vs F2 significance) -> add (shared with Kunal)
- [ ] GAP2: lead-time has no VIX baseline comparison -> add VIX 95th pct lead time + differential
- [ ] GAP3: leave-one-crisis-out evaluation (effective N problem) -> add
- [ ] GAP4: crash labels equal-weight proxy + log/simple compounding -> shared fix with Octavian
- [ ] GAP5: tests can't run standalone (config import) -> conftest adds root to path

## INTEGRATION
- [ ] single config.py, single run_all.py chaining data->tda->ml->tda-analysis
- [ ] full test suite passes (octavian + kunal + sina)
- [ ] end-to-end demo run clean
- [ ] end-to-end small real-ish run if network allows, else synthetic proof
