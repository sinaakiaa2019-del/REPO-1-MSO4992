"""
UMAP embedding of the rolling distance matrices (Octavian) -- the Week 3
deliverable that was missing: "Produce UMAP 2D embedding of all distance
matrices over time. Colour by date and by crash/non-crash label. This figure
will go in the paper."

Each rolling window's Mantegna distance matrix is flattened (upper triangle)
into one point; UMAP then embeds the ~1,000 windows into 2D. Windows with
similar correlation GEOMETRY land near each other, so the market's trajectory
through "correlation-structure space" becomes visible -- calm regimes cluster,
crash windows should migrate to a distinct region.

Caveat handled explicitly: windows can have different active-stock universes
(point-in-time membership), so raw flattened triangles differ in length. We
therefore embed a fixed-length summary per window -- the histogram of pairwise
distances on a common grid -- which is permutation- and size-invariant, rather
than padding/truncating ticker-aligned entries (which would silently compare
different stock pairs across windows). Falls back to sklearn MDS if umap-learn
is unavailable, labelled as such on the figure.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from config import DISTANCE_DIR, FIGURE_DIR


def _distance_histograms(distance_dir=DISTANCE_DIR, n_bins=64):
    """Fixed-length per-window features: histogram of pairwise Mantegna
    distances over [0, 2] (size/universe invariant)."""
    files = sorted(Path(distance_dir).glob("distance_*.npz"))
    grid = np.linspace(0.0, 2.0, n_bins + 1)
    feats, dates = [], []
    for f in files:
        data = np.load(f, allow_pickle=True)
        m = data["matrix"]
        iu = np.triu_indices(m.shape[0], k=1)
        hist, _ = np.histogram(m[iu], bins=grid, density=True)
        feats.append(hist)
        dates.append(pd.Timestamp(str(data["date"])) if "date" in data.files
                     else pd.Timestamp(f.stem.split("_")[-1]))
    return np.array(feats), pd.DatetimeIndex(dates)


def umap_distance_embedding(crash_labels=None, distance_dir=DISTANCE_DIR,
                            output_path=None, random_state=42):
    """
    Build and plot the 2D embedding of all windows. Returns
    (output_path, embedding_df). Colours: left panel by date, right panel by
    crash/non-crash label (if labels supplied).
    """
    X, dates = _distance_histograms(distance_dir)
    if len(X) < 10:
        raise ValueError(f"Only {len(X)} windows found in {distance_dir}.")

    method = "UMAP"
    try:
        import umap
        emb = umap.UMAP(n_components=2, random_state=random_state,
                        n_neighbors=15, min_dist=0.1).fit_transform(X)
    except Exception:
        from sklearn.manifold import MDS
        emb = MDS(n_components=2, random_state=random_state,
                  normalized_stress="auto").fit_transform(X)
        method = "MDS (umap-learn unavailable)"

    df = pd.DataFrame(emb, columns=["x", "y"], index=dates)

    crash = None
    if crash_labels is not None:
        labels = (crash_labels["crash_label"] if isinstance(crash_labels, pd.DataFrame)
                  else pd.Series(crash_labels))
        labels.index = pd.to_datetime(labels.index)
        crash = labels.reindex(dates, method="nearest",
                               tolerance=pd.Timedelta("5D")).fillna(0).astype(int).values
        df["crash_label"] = crash

    n_panels = 2 if crash is not None else 1
    fig, axes = plt.subplots(1, n_panels, figsize=(6 * n_panels, 5), squeeze=False)
    sc = axes[0][0].scatter(df["x"], df["y"], c=np.arange(len(df)), cmap="viridis", s=14)
    fig.colorbar(sc, ax=axes[0][0], label="window order (time)")
    axes[0][0].set_title(f"{method} of distance-matrix geometry — coloured by date")

    if crash is not None:
        calm, cr = df[df["crash_label"] == 0], df[df["crash_label"] == 1]
        axes[0][1].scatter(calm["x"], calm["y"], c="#9ecae1", s=12, label="calm")
        axes[0][1].scatter(cr["x"], cr["y"], c="#d62728", s=26, label="crash window",
                           edgecolors="k", linewidths=0.4)
        axes[0][1].set_title(f"{method} — coloured by crash label")
        axes[0][1].legend(fontsize=8)
    fig.tight_layout()

    output_path = output_path or (FIGURE_DIR / "umap_distance_embedding.png")
    Path(FIGURE_DIR).mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return output_path, df
