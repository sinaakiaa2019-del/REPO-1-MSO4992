"""
ML & Validation orchestrator (Sina Kia) — Week 7.

Run AFTER run_ml.py. Reuses Weeks 1-3 state and rebuilds F3 like Week 4/6.

  python run_ml_week7.py

Deliverables:
  - Full SHAP suite: dependence plots (top features) + per-crisis waterfall
    plots, on top of Week 4's beeswarm/heatmap.
  - International generalisation: transfer an equity-trained F1 (topology)
    model directly to credit and international data, no retraining.
  - Streamlit v1: this script also exports the out-of-sample F3 probability
    series the dashboard (streamlit_app.py) reads on load.
"""

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from ml import ml_config
from ml.cross_asset_validation import load_asset_class_features
from ml.data_access import align_features_labels
from ml.f3_combined_features import build_f1_f2_f3
from ml.international_generalisation import run_international_generalisation
from ml.lead_time_analysis import out_of_sample_probabilities
from ml.shap_analysis import compute_shap_values_oos
from ml.shap_suite import save_crisis_waterfalls, save_dependence_plots
from run_ml import main as run_weeks_1_to_3


def banner(text):
    print("\n" + "=" * 64)
    print(text)
    print("=" * 64)


def main():
    ml_config.ensure_output_dirs()

    banner("Reusing Weeks 1-3 (returns, crash labels, equity F1/F2) + building F3")
    state = run_weeks_1_to_3()
    crash_labels = state["crash_labels"]
    equity_f1 = state["f1_features"]
    equity_f2 = state["f2_features"]
    aligned, y = build_f1_f2_f3(equity_f1, equity_f2, crash_labels)
    X3 = aligned["F3"]
    print(f"  F3: {X3.shape[0]} rows x {X3.shape[1]} features")

    # ---------------- Week 7: full SHAP suite ----------------
    banner("WEEK 7  Full SHAP suite (dependence plots + crisis waterfalls)")
    shap_df, base_values = compute_shap_values_oos(X3, y, return_base_values=True)
    if shap_df.empty:
        print("  No out-of-sample rows -- skipping SHAP suite.")
    else:
        dep_paths = save_dependence_plots(
            shap_df, X3, ml_config.SHAP_DEPENDENCE_DIR, top_n=ml_config.SHAP_DEPENDENCE_TOP_N,
        )
        print(f"  Dependence plots ({len(dep_paths)}): {ml_config.SHAP_DEPENDENCE_DIR}")

        waterfall_index = save_crisis_waterfalls(
            shap_df, base_values, X3, ml_config.SHAP_WATERFALL_DIR,
        )
        print(waterfall_index.to_string(index=False))
        waterfall_index.to_csv(ml_config.SHAP_WATERFALL_INDEX_FILE, index=False)
        n_explained = int(waterfall_index["path"].notna().sum())
        print(f"  Waterfall plots: {n_explained} / {len(waterfall_index)} crises explained "
              f"(rest had no out-of-sample date before onset -- see Week 4 notes)")

    # ---------------- Week 7: international generalisation ----------------
    banner("WEEK 7  International generalisation (equity -> credit/international transfer)")
    credit_f1, _, credit_prov = load_asset_class_features(
        "credit",
        topology_csv_path=ml_config.CREDIT_TOPOLOGY_FEATURES_FILE,
        betti_npz_path=ml_config.CREDIT_BETTI_CURVE_FILE,
        synthetic_seed=41, synthetic_betti_seed=43, synthetic_macro_seed=47,
    )
    intl_f1, _, intl_prov = load_asset_class_features(
        "international",
        topology_csv_path=ml_config.INTERNATIONAL_TOPOLOGY_FEATURES_FILE,
        betti_npz_path=ml_config.INTERNATIONAL_BETTI_CURVE_FILE,
        synthetic_seed=53, synthetic_betti_seed=59, synthetic_macro_seed=61,
    )
    print(f"  [credit] F1 source: {credit_prov['f1']}")
    print(f"  [international] F1 source: {intl_prov['f1']}")

    # Use ALL available equity F1 rows (not just F3's common index) to train
    # the source model -- transfer only needs F1, no reason to throw away
    # equity rows that happened to lack a macro (F2) value that day.
    X1_equity, y1_equity = align_features_labels(equity_f1, crash_labels)

    try:
        transfer_table, source_cv = run_international_generalisation(
            X1_equity, y1_equity,
            target_datasets={
                "credit": (credit_f1, crash_labels),
                "international": (intl_f1, crash_labels),
            },
        )
        print(transfer_table.to_string(index=False))
        transfer_table.to_csv(ml_config.INTERNATIONAL_GENERALISATION_TABLE_FILE, index=False)
        print(f"  Saved: {ml_config.INTERNATIONAL_GENERALISATION_TABLE_FILE}")
        print("  NOTE: credit/international F1 are synthetic placeholders (see Week 5 notes) --")
        print("  transfer numbers demonstrate the PIPELINE is correct, not a real finding.")
    except ValueError as exc:
        print(f"  Transfer skipped: {exc}")

    # ---------------- Week 7: export OOS probabilities for dashboard ----------------
    banner("WEEK 7  Exporting out-of-sample F3 probabilities for the dashboard")
    proba = out_of_sample_probabilities(X3, y)
    if proba.empty:
        print("  No out-of-sample probabilities produced.")
    else:
        proba.to_frame("oos_crash_probability").to_csv(ml_config.OOS_PROBA_FILE)
        print(f"  Saved: {ml_config.OOS_PROBA_FILE} ({len(proba)} rows)")

    banner("DONE (Week 7)")
    print(f"Reports: {ml_config.ML_REPORT_DIR}")
    print(f"Figures: {ml_config.ML_FIGURE_DIR}")


if __name__ == "__main__":
    main()
