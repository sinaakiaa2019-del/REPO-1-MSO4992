from pathlib import Path

# Project directories
BASE_DIR        = Path(__file__).resolve().parent
DATA_DIR        = BASE_DIR / "data"
RAW_DIR         = DATA_DIR / "raw"
PROCESSED_DIR   = DATA_DIR / "processed"
CORRELATION_DIR = PROCESSED_DIR / "correlations"
DISTANCE_DIR    = PROCESSED_DIR / "distances"
TDA_DIR         = PROCESSED_DIR / "tda"
REPORTS_DIR     = BASE_DIR / "reports"
LOGS_DIR        = BASE_DIR / "logs"
OUTPUT_DIR      = BASE_DIR / "outputs"
FIGURE_DIR      = OUTPUT_DIR / "figures"
SECTOR_DIR        = PROCESSED_DIR / "sectors"
CREDIT_DIR        = PROCESSED_DIR / "credit"
INTERNATIONAL_DIR = PROCESSED_DIR / "international"
ROBUSTNESS_DIR    = PROCESSED_DIR / "robustness"

# Shared file paths — imported by ml/ and tda/ to stay consistent
PROCESSED_DATA_DIR     = PROCESSED_DIR
RETURNS_FILE           = PROCESSED_DIR / "returns.csv"
METADATA_FILE          = PROCESSED_DIR / "window_metadata.csv"
CRASH_LABELS_FILE      = PROCESSED_DIR / "crash_labels.csv"
BASELINE_FEATURES_FILE = PROCESSED_DIR / "baseline_features.csv"
MACRO_FEATURES_FILE    = PROCESSED_DIR / "macro_features.csv"
MARKET_INDICATORS_FILE = PROCESSED_DIR / "market_indicators.csv"

SP500_TICKERS_FILE = DATA_DIR / "sp500_tickers.csv"
SP500_CHANGES_FILE = DATA_DIR / "sp500_changes.csv"

# TDA output files produced by tda/run_tda.py
BETTI_CURVE_FILE          = TDA_DIR / "betti_curves.npz"
PERSISTENCE_IMAGE_FILE    = TDA_DIR / "persistence_images.npz"
PERSISTENCE_DIAGRAM_FILE  = TDA_DIR / "persistence_diagrams.pkl"
TOPOLOGY_FEATURES_FILE    = TDA_DIR / "topology_features.csv"
WASSERSTEIN_VELOCITY_FILE = TDA_DIR / "wasserstein_velocity.csv"

# Date range for price downloads
START_DATE = "2004-01-01"
END_DATE   = None  # defaults to today at runtime

# EWMA parameters — RiskMetrics standard (lambda=0.94 gives ~17-day effective memory)
EWMA_LAMBDA     = 0.94
EWMA_LAMBDA_ALT = 0.97  # alternative decay for robustness checks
EWMA_INIT_DAYS  = 60    # warm-up observations before first saved window
STEP_SIZE       = 5     # trading days between consecutive saved windows
ROLLING_WINDOW  = EWMA_INIT_DAYS

# FRED macro series: identifier -> column name used in output CSV
FRED_SERIES = {
    "VIXCLS":       "vix",
    "T10Y2Y":       "yield_curve_slope",
    "BAMLC0A0CMEY": "ig_credit_spread",
    "BAMLH0A0HYM2": "hy_credit_spread",
}

# Missing data thresholds
MAX_MISSING_RATIO     = 0.50  # drop ticker globally if >50% of all rows are missing
MAX_FORWARD_FILL_DAYS = 5     # maximum consecutive days to forward-fill
MIN_VALID_FRACTION    = 0.80  # minimum fraction of valid returns required per rolling window

# Crash label parameters
CRASH_LOOKAHEAD_DAYS = 20
CRASH_DRAWDOWN_LIMIT = -0.10

# Reference crash periods used for event studies and label verification
CRASH_EVENTS = {
    "2000 Dot-com": ("2000-03-01", "2001-04-30"),
    "2008 GFC":     ("2007-10-01", "2009-03-31"),
    "2020 COVID":   ("2020-02-01", "2020-04-30"),
}


def make_project_folders():
    """Create the full directory tree needed by the pipeline."""
    folders = [
        DATA_DIR, RAW_DIR, PROCESSED_DIR, CORRELATION_DIR, DISTANCE_DIR,
        TDA_DIR, REPORTS_DIR, LOGS_DIR, OUTPUT_DIR, FIGURE_DIR,
        SECTOR_DIR, CREDIT_DIR, INTERNATIONAL_DIR, ROBUSTNESS_DIR,
    ]
    for folder in folders:
        folder.mkdir(parents=True, exist_ok=True)
