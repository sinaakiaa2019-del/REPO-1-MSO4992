"""
Data pipeline orchestrator — Stage 1.

Usage:
  python run_pipeline.py                        # full S&P 500 download
  python run_pipeline.py --demo                 # synthetic prices, no network
  python run_pipeline.py --sector               # also build per-sector matrices
  python run_pipeline.py --robustness           # also build robustness variants
  python run_pipeline.py --topology             # also run topology analysis
"""
import argparse
import numpy as np
import pandas as pd

from config import (
    CORRELATION_DIR, CRASH_EVENTS, CRASH_LABELS_FILE, DISTANCE_DIR,
    EWMA_INIT_DAYS, EWMA_LAMBDA, LOGS_DIR, MACRO_FEATURES_FILE,
    PROCESSED_DIR, REPORTS_DIR, ROLLING_WINDOW, STEP_SIZE, TDA_DIR,
    make_project_folders,
)
from data_loader import (
    create_demo_prices, download_fred_macro,
    download_sp500_constituents, download_sp500_prices,
)
from data_processing import (
    build_baseline_features, calculate_log_returns, clean_price_data,
    create_missing_data_report, create_simple_crash_labels, save_table,
)
from matrix_builder import build_ewma_rolling_matrices
from report_builder import write_data_quality_report, write_development_notes


def main(
    use_demo=False,
    full_sp500=False,
    run_sector=False,
    run_robustness=False,
    run_topology=False,
):
    make_project_folders()
    print("=" * 60)
    print("TDA Market Crash Prediction — Stage 1 Data Pipeline")
    print("=" * 60)

    current_df = None
    changes_df = None

    # Stage 1: price data
    if use_demo:
        prices = create_demo_prices()
        print("Stage 1: Using synthetic demo prices.")
    else:
        print("Stage 1: Downloading full S&P 500 universe (survivorship-bias-free)...")
        current_df, changes_df = download_sp500_constituents(cache=True)
        print(f"  S&P 500 current members: {len(current_df)}, "
              f"historical changes: {0 if changes_df is None else len(changes_df)}")
        # Pass the changes table so delisted firms (Lehman, Bear Stearns, ...)
        # are downloaded too, not just today's survivors.
        prices = download_sp500_prices(current_members=current_df,
                                       membership_changes=changes_df)

    save_table(prices, PROCESSED_DIR / "prices")
    print(f"  Prices shape: {prices.shape}")

    # Stage 2: cleaning and returns
    print("Stage 2: Cleaning prices and computing log returns...")
    missing_report = create_missing_data_report(prices)
    save_table(missing_report, PROCESSED_DIR / "missing_data_report")

    cleaned_prices = clean_price_data(prices)
    save_table(cleaned_prices, PROCESSED_DIR / "cleaned_prices")

    returns = calculate_log_returns(cleaned_prices)
    save_table(returns, PROCESSED_DIR / "returns")
    print(f"  Assets: {cleaned_prices.shape[1]},  Trading days: {returns.shape[0]}")

    # Stage 3: EWMA correlation and distance matrices
    print(f"Stage 3: Building EWMA matrices (lam={EWMA_LAMBDA}, "
          f"init={EWMA_INIT_DAYS}d, step={STEP_SIZE}d)...")
    metadata_df, embedding_df = build_ewma_rolling_matrices(
        returns=returns,
        correlation_dir=CORRELATION_DIR,
        distance_dir=DISTANCE_DIR,
        lam=EWMA_LAMBDA,
        init_days=EWMA_INIT_DAYS,
        step_size=STEP_SIZE,
        current_members=current_df,      # None in demo mode -> PIT off, logged
        membership_changes=changes_df,
    )
    metadata_df.to_csv(PROCESSED_DIR / "window_metadata.csv", index=False)
    embedding_df.to_csv(PROCESSED_DIR / "distance_embedding.csv", index=False)
    print(f"  {len(metadata_df)} windows saved -> {CORRELATION_DIR}")

    # Stage 4: baseline features and crash labels
    print("Stage 4: Building baseline features and crash labels...")
    baseline_features = build_baseline_features(returns, rolling_window=ROLLING_WINDOW)
    save_table(baseline_features, PROCESSED_DIR / "baseline_features")

    crash_labels = create_simple_crash_labels(returns)
    crash_labels.to_csv(CRASH_LABELS_FILE)
    n_crash = int((crash_labels["crash_label"] == 1).sum())
    print(f"  Crash windows: {n_crash} / {len(crash_labels)} ({n_crash/len(crash_labels)*100:.1f}%)")

    # Stage 5: FRED macro indicators
    if not use_demo:
        print("Stage 5: Downloading FRED macro indicators...")
        try:
            macro = download_fred_macro()
            macro.to_csv(MACRO_FEATURES_FILE)
            print(f"  {macro.shape[1]} series, {len(macro)} rows -> {MACRO_FEATURES_FILE}")
        except Exception as exc:
            print(f"  FRED download failed: {exc}")
    else:
        print("Stage 5: Skipped (demo mode).")

    # Stage 6: per-sector EWMA matrices
    if run_sector and not use_demo:
        print("Stage 6: Building per-GICS-sector EWMA matrices...")
        from sector_builder import build_sector_ewma_matrices
        if current_df is not None:
            try:
                build_sector_ewma_matrices(returns, current_df)
            except Exception as exc:
                print(f"  Sector matrices failed: {exc}")
        else:
            print("  Sector matrices require full S&P 500 mode.")
    elif run_sector:
        print("Stage 6: Skipped (demo mode).")

    # Stage 7: robustness variants (alt-lambda and Spearman)
    if run_robustness:
        print("Stage 7: Building robustness variants (lambda=0.97 + Spearman)...")
        from robustness_builder import build_alt_lambda_matrices, build_spearman_matrices
        try:
            build_alt_lambda_matrices(returns)
            build_spearman_matrices(returns)
        except Exception as exc:
            print(f"  Robustness variants failed: {exc}")

    # Stage 8: topology analysis and visualisations
    if run_topology:
        print("Stage 8: Topology analysis and visualisations...")
        from topology_analyser import (
            compute_beta_ratio, compute_summary_statistics,
            generate_results_skeleton, load_crash_labels, load_topology_features,
        )
        from feature_visualiser import (
            plot_beta_ratio, plot_eigenvalue_spectrum, plot_event_study,
            plot_feature_heatmap, plot_feature_pairplots,
            plot_phase_portrait, plot_sector_heatmaps,
        )

        try:
            plot_feature_pairplots(baseline_features)
            plot_feature_heatmap(baseline_features)
            plot_eigenvalue_spectrum(returns)
        except Exception as exc:
            print(f"  Visualisations failed: {exc}")

        try:
            topology_df, betti_array, betti_dates = load_topology_features()
            if betti_array is not None:
                beta_df = compute_beta_ratio(betti_array, betti_dates)
                beta_df.to_csv(PROCESSED_DIR / "beta_ratio.csv")
                cl = load_crash_labels()
                plot_phase_portrait(beta_df, crash_labels=cl)
                plot_beta_ratio(beta_df, crash_labels=cl)
                stats = compute_summary_statistics(topology_df, cl)
                if not stats.empty:
                    stats.to_csv(REPORTS_DIR / "topology_summary_statistics.csv", index=False)

                # Event study: load VIX and Wasserstein velocity if available
                vix   = None
                wassl = None
                try:
                    macro = pd.read_csv(MACRO_FEATURES_FILE, index_col=0, parse_dates=True)
                    vix   = macro["vix"] if "vix" in macro.columns else None
                except Exception:
                    pass
                try:
                    wassl = pd.read_csv(
                        TDA_DIR / "wasserstein_velocity.csv", index_col=0, parse_dates=True
                    )
                except Exception:
                    pass
                # The market price panel was previously blank (spy_prices=None).
                # Reconstruct the equal-weighted market level from the log
                # returns (exp of the cumulative mean log return) so the
                # flagship event-study figure shows price, VIX, Wasserstein
                # velocity and the beta ratio on one timeline as the plan spec.
                market_level = np.exp(returns.mean(axis=1).cumsum()) * 100
                plot_event_study(spy_prices=market_level, vix_series=vix,
                                 wasserstein_df=wassl, betti_ratio_df=beta_df)

                # Sector heatmaps at T-90, T-30, T for each crash event
                if current_df is not None and run_sector:
                    from sector_builder import build_sector_map
                    sector_map = build_sector_map(returns, current_df)
                    for event_name, (start_str, _) in CRASH_EVENTS.items():
                        plot_sector_heatmaps(returns, sector_map,
                                             crash_date=start_str,
                                             event_name=event_name)
            else:
                print("  TDA outputs not yet available — run tda/run_tda.py first.")
        except Exception as exc:
            print(f"  Topology analysis failed: {exc}")

        generate_results_skeleton()

    # Stage 9: quality reports
    print("Stage 9: Writing quality report...")
    write_data_quality_report(
        path=REPORTS_DIR / "data_quality_report.md",
        prices=prices,
        cleaned_prices=cleaned_prices,
        returns=returns,
        metadata_df=metadata_df,
        missing_report=missing_report,
        baseline_features=baseline_features,
        crash_labels=crash_labels,
    )
    write_development_notes(LOGS_DIR / "development_notes.md")

    print("=" * 60)
    print("Pipeline complete.")
    print(f"  Assets:        {cleaned_prices.shape[1]}")
    print(f"  Trading days:  {returns.shape[0]}")
    print(f"  EWMA windows:  {len(metadata_df)}")
    print(f"  Crash windows: {n_crash}")
    print("=" * 60)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="TDA Market Crash Prediction — data pipeline.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--demo",       action="store_true", help="Synthetic prices, no network.")
    parser.add_argument("--full-sp500", action="store_true", help="Download full S&P 500 via yfinance.")
    parser.add_argument("--sector",     action="store_true", help="Build per-GICS-sector EWMA matrices.")
    parser.add_argument("--robustness", action="store_true", help="Build alt-lambda and Spearman variants.")
    parser.add_argument("--topology",   action="store_true", help="Run topology analysis and visualisations.")
    args = parser.parse_args()

    main(
        use_demo=args.demo,
        full_sp500=args.full_sp500,
        run_sector=args.sector,
        run_robustness=args.robustness,
        run_topology=args.topology,
    )
