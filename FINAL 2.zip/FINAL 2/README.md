# TDA Market Crash Prediction — Integrated Project (Weeks 1–8)

Kunal Jha (TDA) · Octavian Gurau-Golban (Data) · Sina Kia (ML)

A single, integrated, end-to-end pipeline: S&P 500 price data → EWMA/Mantegna
correlation-distance matrices → persistent homology → topological + standard
features → crash-prediction models, with the full statistical apparatus
(DeLong test, leave-one-crisis-out, bootstrap CIs) needed to defend the results.

## Quick start

```bash
pip install -r requirements.txt

python run_all.py --demo        # full stack on signal-bearing synthetic data, ~20s
python run_all.py               # full stack on real data (yfinance + FRED)

pytest tests/ tda/tests/ ml/tests/ -q     # 150 tests, all three workstreams
```

`--demo` runs the entire pipeline on synthetic data that has real embedded crash
structure (correlation surges + sell-offs in three stress windows), so every
metric comes out finite and meaningful — it proves the machinery is correct
end to end without needing live market data. It is a correctness proof, not a
source of paper numbers.

## The four stages

| Stage | Owner | Entry point | Produces |
|---|---|---|---|
| 1. Data | Octavian | `run_pipeline.py` | returns, EWMA/Mantegna matrices, baseline+macro features, crash labels |
| 2. TDA Weeks 1–3 | Kunal | `tda/run_tda.py` | Betti curves, persistence images, Wasserstein velocity, diagram-level scalars |
| 3. TDA Weeks 4–8 | Kunal | `tda/run_tda_weeks4_8.py` | filtration sensitivity (RQ2), significance tests, H2, Gidea–Katz, sector TDA |
| 4. ML | Sina | `run_ml.py`, `run_ml_week4-8.py` | F1/F2/F3 models, DeLong, leave-one-crisis-out, SHAP, lead time |

## What was completed in this integration pass

### Kunal — TDA extended from Weeks 1–3 to Weeks 4–8 (previously nonexistent)

The Weeks 1–3 persistent-homology stack (ripser wrapper, Betti curves,
persistence images, Wasserstein velocity) was already built. This pass adds the
Weeks 4–8 analytical layer that turns raw topology into research answers:

- **`tda/filtration_sensitivity.py` (W4, RQ2):** model-free AUROC of single-scale
  β₁(ε) vs the crash label, for every ε — directly answers "which filtration
  scale is most predictive" and maps it back to an implied correlation ρ.
- **`tda/multi_universe.py` (W4–5):** runs the full TDA pipeline over Octavian's
  per-sector, robustness (λ-alt, Spearman), and credit/international distance
  matrices, so cross-asset and sector-leadership ML consume real topology.
  Also a standalone (no-ML) Wasserstein-velocity early-warning precision/recall.
- **`tda/significance_and_evolution.py` (W6–8):** Mann–Whitney test that β₁
  differs pre-crash vs calm; H2 (voids) feasibility with self-timing;
  crash-specific diagram evolution (T-30/-20/-10/T); and a Gidea & Katz (2018)
  L2-norm replication scored against the crash label.
- **`tda/vectorisation_and_figures.py` (W6–7):** ablation of the four topological
  vectorisations (curves / images / scalars / Wasserstein) scored on the ML
  stage's own evaluator, plus publication persistence-diagram and RQ2 figures.
- **`common/stats_tests.py`:** DeLong test for correlated AUROCs + bootstrap CI,
  shared by the TDA and ML stages.
- 22 new TDA tests, all passing.

### Octavian — bugs fixed

1. **Survivorship bias (was: claimed but not implemented).** `get_sp500_at_date`
   existed and was tested but was never called; the pipeline used today's
   members only. Now the downloader fetches the full historical union
   (current + every added/removed ticker, so delisted firms like Lehman are
   included) and the matrix builder intersects each window's universe with the
   point-in-time membership on that date. When membership data is absent the
   run logs "point-in-time OFF" rather than silently claiming otherwise.
2. **Spearman robustness variant** dropped any row with any NaN, collapsing the
   wide staggered-listing panel — now uses the same per-window active-stock
   filter as the primary EWMA path.
3. **Crash-label compounding** mixed log returns with `(1+r).cumprod()` — fixed
   to `exp(cumsum)`, the correct reconstruction for log returns.
4. **Betti npz key mismatch** — the topology loader looked for `betti_curves`
   while Kunal saves `betti`, so the phase-portrait/event-study branch silently
   did nothing; now matches (with backward-compatible fallbacks).
5. **Mantegna range** documented correctly as [0, 2], not [0, √2].

### Sina — gaps closed

1. **DeLong test** (was missing) — now implemented in `common/stats_tests.py`
   and wired into the F3-vs-F2 comparison, so "topology beats VIX" can be
   stated with a p-value.
2. **VIX-baseline lead time** (`ml/vix_lead_time_baseline.py`) — computes VIX's
   own 95th-percentile-crossing lead time and the topology-minus-VIX
   differential, which is the actual claim the plan requires.
3. **Leave-one-crisis-out** (`ml/leave_one_crisis_out.py`) — trains on all but
   one crisis (with an embargo) and tests on the held-out one, the honest
   headline metric given only ~2 independent crisis episodes.
4. **Crash-label compounding** fixed to match the corrected data pipeline.
5. **Standalone tests** — a `conftest.py` puts the project root on the path so
   `pytest ml/tests` runs from a clean checkout.

## Example demo output (signal-bearing synthetic data)

```
RQ2 filtration sensitivity : peak epsilon≈1.14 (rho≈0.35), AUROC 0.82
Mann–Whitney beta_1 test   : p = 3.5e-15 (pre-crash differs from calm)
Gidea–Katz L2 replication  : AUROC 0.84
F1 / F2 / F3 AUROC         : 0.82 / 0.71 / 0.82
DeLong F3 vs F2            : diff +0.12, p = 0.036 (significant)
Leave-one-crisis-out (F3)  : 2008 = 0.51, 2020 = 0.85
H2 (voids) feasibility     : ~1 ms/window at 30 assets
```

(These are synthetic-data numbers demonstrating the pipeline is correct, not
research findings.)

## Scientific notes carried forward

- On this synthetic data the Mann–Whitney direction is **pre-crash β₁ < calm**
  — loops *decrease* into stress, consistent with the earlier finding that a
  *uniform* correlation surge suppresses loops (only a genuinely cyclic
  contagion structure creates them). Worth checking against the real
  pre-2008/2020 sector correlation structure.
- Effective sample size remains the central caveat: with ~2 independent crises
  in 2004–2026, the leave-one-crisis-out result is the trustworthy headline;
  the expanding-window CV mean is an average over ~2 scored folds.
- Point-in-time membership relies on Yahoo Finance still resolving delisted
  tickers; some will not, and those gaps should be reported in the data
  section rather than silently reducing the historical universe.
