import numpy as np
import pandas as pd

from config import EWMA_INIT_DAYS, EWMA_LAMBDA, MIN_VALID_FRACTION, STEP_SIZE


def correlation_to_distance(correlation_matrix):
    """Mantegna distance: D_ij = sqrt(2*(1 - rho_ij)).

    Range is [0, 2], NOT [0, sqrt(2)]: rho=+1 -> 0, rho=0 -> sqrt(2) ~ 1.414,
    rho=-1 -> 2. sqrt(2) is the distance at ZERO correlation, not the maximum;
    negative correlations (common in real markets) legitimately produce
    distances above sqrt(2). The Vietoris-Rips filtration must therefore sweep
    epsilon up to 2.0, not sqrt(2), to capture anti-correlated pairs.
    """
    correlation_matrix = np.clip(correlation_matrix, -1, 1)
    distance_matrix = np.sqrt(2 * (1 - correlation_matrix))
    np.fill_diagonal(distance_matrix, 0)
    return distance_matrix


def check_distance_matrix(distance_matrix):
    """Validate symmetry, zero diagonal, and non-negativity before passing to TDA."""
    if np.isnan(distance_matrix).any():
        raise ValueError("Distance matrix contains NaN values.")
    if not np.allclose(distance_matrix, distance_matrix.T, atol=1e-6):
        raise ValueError("Distance matrix is not symmetric.")
    if not np.allclose(np.diag(distance_matrix), 0, atol=1e-6):
        raise ValueError("Distance matrix diagonal is not zero.")
    if distance_matrix.min() < -1e-8:
        raise ValueError("Distance matrix has negative values.")
    return True


def _cov_to_corr(cov):
    """Convert covariance to correlation, clipping to [-1, 1] for numerical safety."""
    std = np.sqrt(np.diag(cov))
    std[std < 1e-8] = 1e-8
    corr = cov / np.outer(std, std)
    corr = np.clip(corr, -1, 1)
    np.fill_diagonal(corr, 1.0)
    return corr


def _active_stocks(arr, t, lookback, min_valid_fraction,
                   tickers=None, pit_members=None):
    """Return indices of stocks eligible for the correlation matrix at time t.

    A stock is eligible if it has >= min_valid_fraction valid returns in the
    current lookback window (data availability). If `pit_members` is supplied
    (a set of tickers that were actual S&P 500 constituents on this window's
    date), the eligible set is additionally INTERSECTED with that membership.

    This is the survivorship-bias correction: without it, the universe is
    today's index members that happen to have enough history, so firms that
    were in the index during (say) 2008 but were later deleted or went bankrupt
    (Lehman, Bear Stearns, Wachovia) are silently absent -- exactly the firms
    whose pre-crash correlation behaviour matters most. With point-in-time
    membership, each window uses the index as it actually stood on that date.
    """
    start = max(0, t - lookback + 1)
    window = arr[start: t + 1]
    valid_ratio = 1.0 - np.isnan(window).mean(axis=0)
    eligible = valid_ratio >= min_valid_fraction

    if pit_members is not None and tickers is not None:
        in_index = np.array([tk in pit_members for tk in tickers])
        eligible = eligible & in_index

    return np.where(eligible)[0]


def build_ewma_rolling_matrices(
    returns,
    correlation_dir,
    distance_dir,
    lam=EWMA_LAMBDA,
    init_days=EWMA_INIT_DAYS,
    step_size=STEP_SIZE,
    min_valid_fraction=MIN_VALID_FRACTION,
    current_members=None,
    membership_changes=None,
):
    """
    Build rolling EWMA correlation and Mantegna distance matrices.
    Update rule: C_t = lam * C_{t-1} + (1-lam) * r_t * r_t^T
    Each NPZ contains the distance matrix, ticker array, and window date.

    Point-in-time membership (survivorship-bias correction)
    -------------------------------------------------------
    If both current_members (DataFrame with a 'ticker' column) and
    membership_changes (DataFrame: date, action in {added, removed}, ticker)
    are provided, each window intersects its data-available universe with the
    S&P 500 constituents reconstructed for that window's date via
    data_loader.get_sp500_at_date. If either is None, the builder falls back to
    the data-availability universe only (and logs that point-in-time
    correction is OFF, so the run is never silently survivorship-biased while
    claiming otherwise).
    """
    arr     = returns.values.astype(float)
    n_obs, n_assets = arr.shape
    tickers = np.array(list(returns.columns))

    use_pit = current_members is not None and membership_changes is not None
    if use_pit:
        from data_loader import get_sp500_at_date
        print("  Point-in-time S&P 500 membership: ON (survivorship-bias corrected).")
    else:
        print("  Point-in-time S&P 500 membership: OFF "
              "(data-availability universe only -- results are survivorship-biased).")

    if n_obs < init_days + step_size:
        raise ValueError(f"Need at least {init_days + step_size} observations, got {n_obs}.")

    init = np.where(np.isnan(arr[:init_days]), 0.0, arr[:init_days])
    cov  = (init.T @ init) / init_days

    metadata       = []
    flat_distances = []
    universe_sizes = []
    window_id      = 0

    for t in range(init_days, n_obs):
        r_clean = np.where(np.isnan(arr[t]), 0.0, arr[t])
        cov = lam * cov + (1 - lam) * np.outer(r_clean, r_clean)

        if (t - init_days) % step_size != 0:
            continue

        pit_members = None
        if use_pit:
            window_date = returns.index[t]
            pit_members = set(get_sp500_at_date(window_date, current_members, membership_changes))

        active_idx = _active_stocks(
            arr, t, init_days, min_valid_fraction,
            tickers=tickers, pit_members=pit_members,
        )
        if len(active_idx) < 3:
            window_id += 1
            continue

        cov_sub        = cov[np.ix_(active_idx, active_idx)]
        active_tickers = tickers[active_idx]

        corr = _cov_to_corr(cov_sub)
        dist = correlation_to_distance(corr)
        np.fill_diagonal(dist, 0.0)

        try:
            check_distance_matrix(dist)
        except ValueError:
            window_id += 1
            continue

        date_text = pd.Timestamp(returns.index[t]).strftime("%Y-%m-%d")
        corr_file = correlation_dir / f"correlation_{window_id:04d}_{date_text}.npz"
        dist_file = distance_dir    / f"distance_{window_id:04d}_{date_text}.npz"

        np.savez_compressed(corr_file, matrix=corr, tickers=active_tickers, date=date_text)
        np.savez_compressed(dist_file, matrix=dist, tickers=active_tickers, date=date_text)

        metadata.append({
            "window_id":        window_id,
            "date":             date_text,
            "n_assets":         len(active_idx),
            "ewma_lambda":      lam,
            "correlation_file": str(corr_file),
            "distance_file":    str(dist_file),
        })
        flat_distances.append(dist.flatten())
        universe_sizes.append(len(active_idx))
        window_id += 1

    metadata_df = pd.DataFrame(metadata)

    if universe_sizes:
        print(f"  Per-window universe: min={min(universe_sizes)}, "
              f"max={max(universe_sizes)}, mean={int(sum(universe_sizes)/len(universe_sizes))} stocks")

    embedding_df = create_distance_embedding(metadata_df, flat_distances)
    return metadata_df, embedding_df


def build_and_save_rolling_matrices(
    returns, correlation_dir, distance_dir, rolling_window=60, step_size=5
):
    """Pearson rolling-window matrices for robustness comparison against EWMA."""
    metadata       = []
    flat_distances = []
    tickers        = list(returns.columns)

    for window_id, end_pos in enumerate(range(rolling_window, len(returns), step_size)):
        window_returns = returns.iloc[end_pos - rolling_window: end_pos]
        date_text = pd.Timestamp(returns.index[end_pos - 1]).strftime("%Y-%m-%d")

        corr = window_returns.corr().values
        dist = correlation_to_distance(corr)

        try:
            check_distance_matrix(dist)
        except ValueError:
            continue

        corr_file = correlation_dir / f"correlation_{window_id:04d}_{date_text}.npz"
        dist_file = distance_dir    / f"distance_{window_id:04d}_{date_text}.npz"

        np.savez_compressed(corr_file, matrix=corr, tickers=np.array(tickers), date=date_text)
        np.savez_compressed(dist_file, matrix=dist, tickers=np.array(tickers), date=date_text)

        metadata.append({
            "window_id":        window_id,
            "date":             date_text,
            "n_assets":         len(tickers),
            "correlation_file": str(corr_file),
            "distance_file":    str(dist_file),
        })
        flat_distances.append(dist.flatten())

    metadata_df  = pd.DataFrame(metadata)
    embedding_df = create_distance_embedding(metadata_df, flat_distances)
    return metadata_df, embedding_df


def create_distance_embedding(metadata_df, flat_distances):
    """Two-component PCA embedding of distance matrices for visual sanity checks."""
    if len(flat_distances) < 2:
        return pd.DataFrame()

    # Pad variable-length distance vectors before PCA
    max_len = max(len(f) for f in flat_distances)
    padded  = np.zeros((len(flat_distances), max_len))
    for i, f in enumerate(flat_distances):
        padded[i, :len(f)] = f

    x = padded - padded.mean(axis=0)
    try:
        u, s, _ = np.linalg.svd(x, full_matrices=False)
        coords  = u[:, :2] * s[:2]
    except Exception:
        coords = np.zeros((len(flat_distances), 2))

    return pd.DataFrame({
        "date":        metadata_df["date"].values,
        "component_1": coords[:, 0],
        "component_2": coords[:, 1],
    })
