# Data Quality Report

Report created: 2026-07-04 00:40

## Data universe
Initial number of assets: 20
Final number of assets used: 20
Assets used: STOCK_000, STOCK_001, STOCK_002, STOCK_003, STOCK_004, STOCK_005, STOCK_006, STOCK_007, STOCK_008, STOCK_009, STOCK_010, STOCK_011, STOCK_012, STOCK_013, STOCK_014, STOCK_015, STOCK_016, STOCK_017, STOCK_018, STOCK_019

No assets were removed.

## Data size
Price rows after cleaning: 1499
Return rows: 1498
Rolling windows created: 288
Baseline feature rows: 1438
Crash label rows: 1478

## Missing data handling
Tickers with more than 50% missing observations are dropped globally.
Gaps of up to 5 consecutive days are forward-filled.
Per-window universe filtering then excludes stocks with less than 80%
valid returns in a given rolling window, without dropping them globally.

## Main outputs
- cleaned price data
- daily log returns
- EWMA correlation and distance matrices (NPZ per window)
- window metadata CSV
- baseline features (realised vol, avg correlation, eigenvalue ratio)
- crash labels (forward drawdown labels)
- FRED macro features (VIX, yield curve, credit spreads)

## Survivorship bias note
S&P 500 membership is reconstructed point-in-time from the Wikipedia
additions/removals table. Residual bias: yfinance may lack full price
history for stocks removed due to bankruptcy (Brown, 1995).