"""
Per-sector EWMA correlation matrices using GICS classifications.
Each sector's matrices are saved separately so the TDA stage can analyse
intra-sector topology independently from the full market.
"""
import pandas as pd

from config import CREDIT_DIR, EWMA_INIT_DAYS, EWMA_LAMBDA, SECTOR_DIR, STEP_SIZE
from data_processing import calculate_log_returns, clean_price_data
from matrix_builder import build_ewma_rolling_matrices


def build_sector_map(returns, sector_assignments):
    """
    Map each GICS sector name to the tickers present in returns.
    Only sectors with at least 3 constituents are included.

    Parameters
    ----------
    returns            : DataFrame (dates x tickers)
    sector_assignments : DataFrame with columns [ticker, gics_sector]

    Returns
    -------
    dict {sector_name: [ticker, ...]}
    """
    sector_map = {}
    for sector, group in sector_assignments.groupby("gics_sector"):
        tickers = [t for t in group["ticker"].tolist() if t in returns.columns]
        if len(tickers) >= 3:
            safe_name = sector.replace(" ", "_").replace("/", "_")
            sector_map[safe_name] = tickers
    return sector_map


def build_sector_ewma_matrices(
    returns,
    sector_assignments,
    sector_dir=SECTOR_DIR,
    lam=EWMA_LAMBDA,
    init_days=EWMA_INIT_DAYS,
    step_size=STEP_SIZE,
):
    """
    Build EWMA correlation and distance matrices for each GICS sector.
    Outputs are saved under sector_dir/<SectorName>/correlations/ and /distances/.
    Returns a dict mapping sector name -> metadata DataFrame.
    """
    sector_map = build_sector_map(returns, sector_assignments)

    if not sector_map:
        print("  Sector builder: no sectors with sufficient tickers.")
        return {}

    results = {}
    for sector_name, tickers in sector_map.items():
        print(f"  Sector [{sector_name}]: {len(tickers)} stocks")
        sector_returns = returns[tickers].dropna(how="all")

        corr_dir = sector_dir / sector_name / "correlations"
        dist_dir = sector_dir / sector_name / "distances"
        corr_dir.mkdir(parents=True, exist_ok=True)
        dist_dir.mkdir(parents=True, exist_ok=True)

        try:
            meta, _ = build_ewma_rolling_matrices(
                sector_returns, corr_dir, dist_dir,
                lam=lam, init_days=init_days, step_size=step_size,
            )
            meta.to_csv(sector_dir / f"{sector_name}_metadata.csv", index=False)
            results[sector_name] = meta
            print(f"    {len(meta)} windows saved.")
        except Exception as exc:
            print(f"    Skipped ({exc})")

    return results


def build_credit_ewma_matrices(
    credit_prices,
    credit_dir=CREDIT_DIR,
    lam=EWMA_LAMBDA,
    init_days=EWMA_INIT_DAYS,
    step_size=STEP_SIZE,
):
    """Build EWMA matrices for a set of credit instruments (e.g. IG/HY proxies)."""
    if credit_prices.empty or credit_prices.shape[1] < 2:
        print("  Credit: insufficient data, skipping.")
        return pd.DataFrame()

    cleaned        = clean_price_data(credit_prices)
    credit_returns = calculate_log_returns(cleaned)

    corr_dir = credit_dir / "correlations"
    dist_dir = credit_dir / "distances"
    corr_dir.mkdir(parents=True, exist_ok=True)
    dist_dir.mkdir(parents=True, exist_ok=True)

    try:
        meta, _ = build_ewma_rolling_matrices(
            credit_returns, corr_dir, dist_dir,
            lam=lam, init_days=init_days, step_size=step_size,
        )
        meta.to_csv(credit_dir / "credit_metadata.csv", index=False)
        assets = ", ".join(credit_returns.columns.tolist())
        print(f"  Credit [{assets}]: {len(meta)} windows saved.")
        return meta
    except Exception as exc:
        print(f"  Credit: failed ({exc})")
        return pd.DataFrame()
