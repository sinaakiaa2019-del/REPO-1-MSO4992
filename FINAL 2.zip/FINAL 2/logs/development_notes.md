# Development Notes

The data pipeline downloads S&P 500 prices via yfinance and FRED macro series
via pandas_datareader, cleans missing values, computes log returns, and builds
EWMA correlation and Mantegna distance matrices saved as NPZ files.

S&P 500 membership is reconstructed point-in-time from the Wikipedia
additions/removals history to reduce survivorship bias.

Per-window universe filtering retains all tickers globally but excludes those
with insufficient history in a given rolling window, so the asset count varies
across windows. This is standard practice for long datasets spanning multiple
index compositions.

Output files are organised so they can be consumed directly by the TDA and
machine-learning stages without any additional preprocessing.
