"""
Shared statistical utilities (project-wide).

This module is imported by BOTH the ML stage (ml/) and the TDA stage (tda/),
so it lives at the project root rather than inside either package. It provides
the statistical machinery the plan requires for defensible model comparison:

  - delong_roc_test: the DeLong (1988) test for the difference between two
    CORRELATED ROC curves evaluated on the same samples. This is how the paper
    proves that F1/F3 (topology) beats F2 (standard indicators) by more than
    chance -- a plain "0.85 > 0.71" is not evidence without it.

  - bootstrap_auroc_ci: a percentile bootstrap confidence interval for a single
    AUROC, used where a paired DeLong test does not apply (e.g. reporting the
    uncertainty on one model's score given very few crisis episodes).

The DeLong implementation is the fast Sun & Xu (2014) placement-value
algorithm, validated in tests against the pROC reference values.
"""

from __future__ import annotations

import numpy as np
from scipy import stats


# ---------------------------------------------------------------------------
# DeLong test (Sun & Xu 2014 fast algorithm)
# ---------------------------------------------------------------------------

def _compute_midrank(x):
    """Mid-ranks (ties averaged), used by the fast DeLong covariance."""
    order = np.argsort(x)
    x_sorted = x[order]
    n = len(x)
    midrank = np.zeros(n, dtype=float)
    i = 0
    while i < n:
        j = i
        while j < n and x_sorted[j] == x_sorted[i]:
            j += 1
        midrank[i:j] = 0.5 * (i + j - 1) + 1
        i = j
    out = np.empty(n, dtype=float)
    out[order] = midrank
    return out


def _fast_delong(predictions_sorted_transposed, label_1_count):
    """
    Fast DeLong AUC variance/covariance (Sun & Xu 2014).

    predictions_sorted_transposed : (k, n) array, k models, positives first.
    label_1_count : number of positive samples m (first m columns).

    Returns (aucs (k,), cov (k, k)).
    """
    m = label_1_count
    n = predictions_sorted_transposed.shape[1] - m
    positive = predictions_sorted_transposed[:, :m]
    negative = predictions_sorted_transposed[:, m:]
    k = predictions_sorted_transposed.shape[0]

    tx = np.empty([k, m], dtype=float)
    ty = np.empty([k, n], dtype=float)
    tz = np.empty([k, m + n], dtype=float)
    for r in range(k):
        tx[r, :] = _compute_midrank(positive[r, :])
        ty[r, :] = _compute_midrank(negative[r, :])
        tz[r, :] = _compute_midrank(predictions_sorted_transposed[r, :])

    aucs = tz[:, :m].sum(axis=1) / m / n - (m + 1.0) / 2.0 / n
    v01 = (tz[:, :m] - tx[:, :]) / n
    v10 = 1.0 - (tz[:, m:] - ty[:, :]) / m
    sx = np.cov(v01)
    sy = np.cov(v10)
    delongcov = sx / m + sy / n
    return aucs, np.atleast_2d(delongcov)


def delong_roc_test(y_true, proba_a, proba_b):
    """
    DeLong test for two correlated ROC curves on the SAME samples.

    Parameters
    ----------
    y_true : array of 0/1 labels.
    proba_a, proba_b : predicted P(positive) from model A and model B, aligned
        to y_true (same order, same rows).

    Returns
    -------
    dict with:
        auc_a, auc_b       : the two AUROCs.
        auc_diff           : auc_a - auc_b.
        z, p_value         : two-sided test of H0: AUC_a == AUC_b.
        significant_05     : bool, p_value < 0.05.

    Notes
    -----
    Requires both classes present. Raises ValueError otherwise (a single-class
    fold cannot support an ROC test -- the caller must aggregate over folds or
    use out-of-sample stitched probabilities that span both classes).
    """
    y_true = np.asarray(y_true).astype(int)
    proba_a = np.asarray(proba_a, dtype=float)
    proba_b = np.asarray(proba_b, dtype=float)

    if len(np.unique(y_true)) < 2:
        raise ValueError("DeLong test needs both classes present in y_true.")
    if not (len(y_true) == len(proba_a) == len(proba_b)):
        raise ValueError("y_true, proba_a, proba_b must be the same length.")

    order = (-y_true).argsort(kind="mergesort")  # positives (label 1) first
    label_1_count = int(y_true.sum())
    preds = np.vstack((proba_a, proba_b))[:, order]

    aucs, cov = _fast_delong(preds, label_1_count)
    auc_a, auc_b = float(aucs[0]), float(aucs[1])

    var_diff = cov[0, 0] + cov[1, 1] - 2 * cov[0, 1]
    if var_diff <= 0:
        # Identical or perfectly-correlated predictions -> no measurable diff.
        z = 0.0
        p = 1.0
    else:
        z = (auc_a - auc_b) / np.sqrt(var_diff)
        p = 2.0 * stats.norm.sf(abs(z))

    return {
        "auc_a": auc_a,
        "auc_b": auc_b,
        "auc_diff": auc_a - auc_b,
        "z": float(z),
        "p_value": float(p),
        "significant_05": bool(p < 0.05),
    }


def bootstrap_auroc_ci(y_true, proba, n_boot=2000, alpha=0.05, random_state=0):
    """
    Percentile bootstrap confidence interval for a single AUROC.

    Resamples (y, proba) pairs with replacement; skips resamples that end up
    single-class. Returns dict with point estimate and (lo, hi) CI.
    """
    from sklearn.metrics import roc_auc_score

    y_true = np.asarray(y_true).astype(int)
    proba = np.asarray(proba, dtype=float)
    rng = np.random.default_rng(random_state)
    n = len(y_true)

    point = roc_auc_score(y_true, proba) if len(np.unique(y_true)) == 2 else np.nan

    scores = []
    for _ in range(n_boot):
        idx = rng.integers(0, n, n)
        yt = y_true[idx]
        if len(np.unique(yt)) < 2:
            continue
        scores.append(roc_auc_score(yt, proba[idx]))

    if not scores:
        return {"auroc": point, "ci_low": np.nan, "ci_high": np.nan, "n_boot_valid": 0}

    lo = float(np.percentile(scores, 100 * alpha / 2))
    hi = float(np.percentile(scores, 100 * (1 - alpha / 2)))
    return {"auroc": float(point), "ci_low": lo, "ci_high": hi, "n_boot_valid": len(scores)}
