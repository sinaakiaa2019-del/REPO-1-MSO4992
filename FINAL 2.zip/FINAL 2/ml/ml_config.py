"""
ML & Validation configuration (Sina Kia).

This file holds settings specific to the machine-learning and validation stage.
It deliberately reuses the data-engineering paths from the top-level config.py so
that Sina's code reads exactly the files Octavian's pipeline produces, and writes
its own outputs into a separate ml_reports folder.

Nothing here downloads or recomputes data. The ML stage only consumes the
artefacts already written by run_pipeline.py.
"""

from pathlib import Path

# Reuse the data-engineering configuration so file locations stay in one place.
# This import works when the project root is on the path (see run_ml.py).
import config as data_config


# ============================================================
# INPUT FILES (produced by the data-engineering pipeline)
# ============================================================

# Daily log returns, dates as index, one column per ticker.
RETURNS_FILE = data_config.RETURNS_FILE

# One row per rolling window: window_id, date, n_assets, correlation_file,
# distance_file. This is the spine that aligns every feature set by date.
METADATA_FILE = data_config.METADATA_FILE

# Preliminary crash labels (date index, crash_label column).
CRASH_LABELS_FILE = data_config.CRASH_LABELS_FILE

# Octavian's baseline features (date index). Used as a convenient source of the
# eigenvalue gap and realised volatility if the macro file is not yet present.
BASELINE_FEATURES_FILE = data_config.BASELINE_FEATURES_FILE

# Optional macro feature file handed over in Week 3:
# dates x [VIX, eigenvalue_gap, realised_vol_20d, T10Y2Y, credit_spread].
# If this file is absent, the F2 builder falls back to baseline_features.csv +
# market_indicators.csv (VIX / yield proxy pulled from Yahoo by Octavian).
MACRO_FEATURES_FILE = data_config.PROCESSED_DATA_DIR / "macro_features.csv"
MARKET_INDICATORS_FILE = data_config.MARKET_INDICATORS_FILE

# Topology feature handover from Kunal's tda/ package (tda/run_tda.py writes
# all four of these; F1 uses whichever combination is present, see
# f1_topology_features.py). Paths come from the single shared config so the
# ml stage and the tda stage can never disagree about a filename again.
BETTI_CURVE_FILE = data_config.BETTI_CURVE_FILE
TOPOLOGY_FEATURES_FILE = data_config.TOPOLOGY_FEATURES_FILE
PERSISTENCE_IMAGE_FILE = data_config.PERSISTENCE_IMAGE_FILE
WASSERSTEIN_VELOCITY_FILE = data_config.WASSERSTEIN_VELOCITY_FILE


# ============================================================
# OUTPUT FILES (produced by the ML stage)
# ============================================================

ML_REPORT_DIR = data_config.OUTPUT_DIR / "ml_reports"
ML_FIGURE_DIR = data_config.FIGURE_DIR

F2_BASELINE_AUROC_FILE = ML_REPORT_DIR / "f2_baseline_auroc.csv"
F1_VS_F2_TABLE_FILE = ML_REPORT_DIR / "f1_vs_f2_auroc.csv"
TUNING_RESULT_FILE = ML_REPORT_DIR / "f2_tuning_result.csv"
SHAP_BEESWARM_FILE = ML_FIGURE_DIR / "shap_beeswarm_f2.png"
CLASS_BALANCE_FILE = ML_REPORT_DIR / "class_balance.csv"

# Week 4 outputs
F1_VS_F2_VS_F3_TABLE_FILE = ML_REPORT_DIR / "f1_vs_f2_vs_f3_auroc.csv"
SHAP_HEATMAP_F3_FILE = ML_FIGURE_DIR / "shap_heatmap_f3.png"
F3_SHAP_IMPORTANCE_FILE = ML_REPORT_DIR / "f3_shap_importance.csv"
LEAD_TIME_TABLE_FILE = ML_REPORT_DIR / "lead_time_analysis.csv"
LEAD_TIME_THRESHOLD = 0.5
LEAD_TIME_LOOKBACK_DAYS = 120

# ============================================================
# WEEK 5: cross-asset + sector leadership
# ============================================================

# Credit and international topology handover (Kunal). Same two-shape contract
# as the equity F1 source (see ml/f1_topology_features.py): a flat scalar CSV
# and/or a raw Betti curve NPZ. Neither exists yet -- synthetic fallback used
# until handed over (see ml/synthetic_data.py).
CREDIT_TOPOLOGY_FEATURES_FILE = data_config.CREDIT_DIR / "topology_features.csv"
CREDIT_BETTI_CURVE_FILE = data_config.CREDIT_DIR / "betti_curves.npz"
INTERNATIONAL_TOPOLOGY_FEATURES_FILE = data_config.INTERNATIONAL_DIR / "topology_features.csv"
INTERNATIONAL_BETTI_CURVE_FILE = data_config.INTERNATIONAL_DIR / "betti_curves.npz"

# Sector-level topology handover (Kunal, Week 4). One set of files per sector,
# following sector_builder.py's naming convention (spaces -> underscores).
GICS_SECTORS = [
    "Information_Technology", "Health_Care", "Financials",
    "Consumer_Discretionary", "Communication_Services", "Industrials",
    "Consumer_Staples", "Energy", "Utilities", "Real_Estate", "Materials",
]


def sector_topology_file(sector_name):
    return data_config.SECTOR_DIR / sector_name / "topology_features.csv"


def sector_betti_file(sector_name):
    return data_config.SECTOR_DIR / sector_name / "betti_curves.npz"


CROSS_ASSET_AUROC_TABLE_FILE = ML_REPORT_DIR / "cross_asset_auroc.csv"
SECTOR_LEADERSHIP_TABLE_FILE = ML_REPORT_DIR / "sector_leadership_lead_times.csv"
SECTOR_LEADERSHIP_HEATMAP_FILE = ML_FIGURE_DIR / "sector_leadership_heatmap.png"
CROSS_ASSET_LEAD_TIME_THRESHOLD = 0.5
SECTOR_LEAD_TIME_LOOKBACK_DAYS = 120

# ============================================================
# WEEK 6: ablation, calibration, CV robustness
# ============================================================

ABLATION_TABLE_FILE = ML_REPORT_DIR / "f3_ablation_auroc.csv"
CALIBRATION_TABLE_FILE = ML_REPORT_DIR / "f3_calibration_bins.csv"
CALIBRATION_PLOT_FILE = ML_FIGURE_DIR / "f3_calibration_curve.png"
CALIBRATION_N_BINS = 10
CV_ROBUSTNESS_TABLE_FILE = ML_REPORT_DIR / "cv_robustness.csv"

# ============================================================
# WEEK 7: full SHAP suite, international generalisation, dashboard
# ============================================================

SHAP_DEPENDENCE_DIR = ML_FIGURE_DIR / "shap_dependence"
SHAP_WATERFALL_DIR = ML_FIGURE_DIR / "shap_waterfall"
SHAP_WATERFALL_INDEX_FILE = ML_REPORT_DIR / "shap_waterfall_index.csv"
SHAP_DEPENDENCE_TOP_N = 6

INTERNATIONAL_GENERALISATION_TABLE_FILE = ML_REPORT_DIR / "international_generalisation.csv"

# Out-of-sample F3 probability series, saved so the Streamlit dashboard can
# display it without retraining a model on every page load.
OOS_PROBA_FILE = ML_REPORT_DIR / "f3_oos_probabilities.csv"

# ============================================================
# WEEK 8: confusion matrix, lead-time histogram, LSTM benchmark, live dashboard
# ============================================================

CONFUSION_MATRIX_THRESHOLD = 0.5
CONFUSION_MATRIX_FILE = ML_REPORT_DIR / "confusion_matrix.csv"
CONFUSION_MATRIX_PLOT_FILE = ML_FIGURE_DIR / "confusion_matrix.png"
THRESHOLD_SWEEP_FILE = ML_REPORT_DIR / "threshold_sweep.csv"
THRESHOLD_SWEEP_PLOT_FILE = ML_FIGURE_DIR / "threshold_sweep.png"

LEAD_TIME_HISTOGRAM_TABLE_FILE = ML_REPORT_DIR / "lead_time_histogram_episodes.csv"
LEAD_TIME_HISTOGRAM_PLOT_FILE = ML_FIGURE_DIR / "lead_time_histogram.png"
LEAD_TIME_HISTOGRAM_MAX_GAP_DAYS = 10

LSTM_VS_XGBOOST_TABLE_FILE = ML_REPORT_DIR / "lstm_vs_xgboost_auroc.csv"
LSTM_SEQ_LEN = 20
LSTM_HIDDEN_SIZE = 16
LSTM_EPOCHS = 15

MODEL_DIR = data_config.OUTPUT_DIR / "models"
F2_LITE_MODEL_FILE = MODEL_DIR / "f2_lite_model.joblib"


# ============================================================
# CROSS-VALIDATION SETTINGS
# ============================================================

# Number of expanding-window folds. The plan specifies 5.
N_CV_FOLDS = 5

# Smallest fraction of the series used as the very first training block before
# the first test fold. The remaining data is split into N_CV_FOLDS test blocks.
INITIAL_TRAIN_FRACTION = 0.40

# An optional gap (in rows) inserted between the end of each training block and
# the start of its test block. Because the crash label looks 20 trading days
# into the future, the last 20 training rows partly "see" the test period.
# A purge gap removes that overlap. Default matches the label horizon.
PURGE_GAP = data_config.CRASH_LOOKAHEAD_DAYS


# ============================================================
# XGBOOST SETTINGS
# ============================================================

# Fixed seed so every run is reproducible (required for the paper).
RANDOM_STATE = 42

# Sensible, conservative defaults for the baseline model. Hyperparameter tuning
# in Week 3 searches around these.
XGB_BASE_PARAMS = {
    "n_estimators": 300,
    "max_depth": 3,
    "learning_rate": 0.05,
    "subsample": 0.8,
    "colsample_bytree": 0.8,
    "objective": "binary:logistic",
    "eval_metric": "auc",
    "random_state": RANDOM_STATE,
    "n_jobs": -1,
}

# Search space for the time-series-safe random search (Week 3).
XGB_SEARCH_SPACE = {
    "n_estimators": [200, 300, 500, 700],
    "max_depth": [2, 3, 4, 5],
    "learning_rate": [0.02, 0.05, 0.1],
    "subsample": [0.7, 0.8, 1.0],
    "colsample_bytree": [0.7, 0.8, 1.0],
    "min_child_weight": [1, 3, 5],
}

# Number of random parameter combinations to try in the search.
N_SEARCH_ITERATIONS = 30


# ============================================================
# CRASH-LABEL SETTINGS (re-stated for clarity / verification)
# ============================================================

CRASH_LOOKAHEAD_DAYS = data_config.CRASH_LOOKAHEAD_DAYS
CRASH_DRAWDOWN_LIMIT = data_config.CRASH_DRAWDOWN_LIMIT

# Crisis windows used to verify the labels fire on the three reference crashes.
# Each tuple is (name, start_date, end_date). A crash label is expected to be
# positive somewhere inside each window.
REFERENCE_CRASHES = [
    ("2000 dot-com", "2000-03-01", "2001-04-30"),
    ("2008 GFC", "2008-09-01", "2009-03-31"),
    ("2020 COVID", "2020-02-15", "2020-04-15"),
]


def ensure_output_dirs():
    """Create the ML output folders if they do not exist yet."""
    ML_REPORT_DIR.mkdir(parents=True, exist_ok=True)
    ML_FIGURE_DIR.mkdir(parents=True, exist_ok=True)
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
