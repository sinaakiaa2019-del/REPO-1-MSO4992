"""
F1 topology-only feature set (Sina Kia).

The plan's Week 3 F1 matrix is built by flattening Kunal's Betti curves plus a
few topological scalars (persistence entropy, max persistence, Wasserstein
velocity). Kunal hands the Betti curve array over by Thursday of Week 3.

This module accepts Kunal's output in either of two shapes so Sina is not blocked
on the exact handover format:

  A) topology_features.csv : a flat, already-vectorised frame with a date index
     and one column per topology feature. Used directly if present.

  B) betti_curves.npz : the raw Betti curve array of shape
     (n_windows, n_epsilon, 2)  -> (windows x epsilon grid x [H0, H1]),
     optionally with a 'dates' array. This module flattens the H1 curve (and,
     optionally, H0), and derives persistence entropy and max persistence from
     the curves so F1 has scalar summaries alongside the raw curve dimensions.

When neither file exists yet, build_f1_from_betti_array can be called directly on
an in-memory array, which is how the synthetic end-to-end test drives it.
"""

import numpy as np
import pandas as pd


def _persistence_entropy_from_curve(curve):
    """
    Approximate persistence entropy from a single Betti curve.

    A Betti curve beta_d(epsilon) sampled on a grid is treated as an unnormalised
    distribution over epsilon. We normalise it and take Shannon entropy. This is a
    pragmatic curve-level proxy; Kunal's exact diagram-based entropy can replace it
    once handed over.
    """
    total = curve.sum()
    if total <= 0:
        return 0.0
    p = curve / total
    p = p[p > 0]
    return float(-(p * np.log(p)).sum())


def build_f1_from_betti_array(betti_array, dates, include_h0=False):
    """
    Build an F1 feature frame from a raw Betti curve array.

    Parameters
    ----------
    betti_array : np.ndarray, shape (n_windows, n_epsilon, 2)
        Axis 2 index 0 = H0 curve, index 1 = H1 curve.
    dates : array-like of length n_windows
        Window end dates aligning each row to a calendar date.
    include_h0 : bool
        Whether to also flatten the H0 curve into the feature matrix. H1 (loops)
        is the topologically interesting signal for crashes, so H0 is off by
        default to keep dimensionality down.

    Returns
    -------
    pd.DataFrame with a date index. Columns:
        h1_eps_000 ... h1_eps_NNN  (flattened H1 curve)
        [optional h0_eps_*]
        h1_persistence_entropy, h1_max_persistence
    """
    betti_array = np.asarray(betti_array, dtype=float)
    if betti_array.ndim != 3 or betti_array.shape[2] < 2:
        raise ValueError("betti_array must have shape (n_windows, n_epsilon, 2).")

    n_windows, n_epsilon, _ = betti_array.shape
    if len(dates) != n_windows:
        raise ValueError("Length of dates must match the number of windows.")

    h1 = betti_array[:, :, 1]
    columns = {}
    for j in range(n_epsilon):
        columns[f"h1_eps_{j:03d}"] = h1[:, j]

    if include_h0:
        h0 = betti_array[:, :, 0]
        for j in range(n_epsilon):
            columns[f"h0_eps_{j:03d}"] = h0[:, j]

    # Scalar topological summaries derived from the H1 curve.
    columns["h1_persistence_entropy"] = np.array(
        [_persistence_entropy_from_curve(h1[i]) for i in range(n_windows)]
    )
    columns["h1_max_persistence"] = h1.max(axis=1)

    features = pd.DataFrame(columns)
    features.index = pd.to_datetime(pd.Index(dates))
    features = features.sort_index()
    return features


def load_f1_features(topology_csv_path=None, betti_npz_path=None, include_h0=False):
    """
    Load F1 features from Kunal's handover artefacts.

    The plan's Week 3 F1 spec is "flatten Betti curves + persistence entropy +
    max persistence + Wasserstein velocity" -- i.e. the full flattened curve
    AND the scalar summaries together, not one or the other. Kunal's
    tda/run_tda.py produces both betti_curves.npz (the flattened-curve source)
    and topology_features.csv (true diagram-level scalars: persistence
    entropy, max/total persistence, the Gidea & Katz L2-norm, and Wasserstein
    velocity). When both are present, this merges them by date: the flattened
    H1 (and optional H0) curve comes from betti_curves.npz, while the scalar
    columns come from topology_features.csv and OVERWRITE the curve-only
    approximations (_persistence_entropy_from_curve, h1_max_persistence) with
    Kunal's true diagram-level values, which are exact rather than a
    proxy computed after the fact from a 200-point sampling of the curve.

    Returns (features_df, source_description). Raises FileNotFoundError if
    neither source exists.
    """
    from pathlib import Path

    has_topology_csv = topology_csv_path is not None and Path(topology_csv_path).exists()
    has_betti_npz = betti_npz_path is not None and Path(betti_npz_path).exists()

    if not has_topology_csv and not has_betti_npz:
        raise FileNotFoundError(
            "No F1 source found. Expected topology_features.csv or betti_curves.npz."
        )

    topo_df = None
    if has_topology_csv:
        topo_df = pd.read_csv(topology_csv_path, index_col=0)
        topo_df.index = pd.to_datetime(topo_df.index)
        topo_df = topo_df.sort_index()

    if has_betti_npz:
        data = np.load(betti_npz_path, allow_pickle=True)
        betti_array = data["betti"] if "betti" in data else data["arr_0"]
        if "dates" not in data:
            raise ValueError("betti_curves.npz has no 'dates' array to align on.")
        curve_df = build_f1_from_betti_array(betti_array, data["dates"], include_h0=include_h0)
        source = f"betti_curves.npz (array shape {tuple(betti_array.shape)})"

        if topo_df is not None:
            # Diagram-level scalars take priority over the curve-derived proxies.
            overlap = [c for c in topo_df.columns if c in curve_df.columns]
            curve_df = curve_df.drop(columns=overlap)
            merged = curve_df.join(topo_df, how="inner")
            source = (f"betti_curves.npz (flattened curve) + topology_features.csv "
                       f"(diagram-level scalars), {len(merged)} rows after date alignment")
            return merged, source

        return curve_df, source

    # Only the flat scalar table is available (no flattened curve dimensions).
    return topo_df, f"topology_features.csv ({topo_df.shape[1]} columns, no flattened curve)"
