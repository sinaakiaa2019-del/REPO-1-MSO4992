"""
XGBoost training and evaluation under expanding-window CV (Sina Kia).

Covers the Week 2 baseline (F2 AUROC per fold) and the Week 3 time-series-safe
random search. Critically, NO sklearn GridSearchCV / RandomizedSearchCV is used,
because their default CV shuffles and leaks future data. All splitting goes
through ExpandingWindowSplit.

scale_pos_weight is set per fold from the training labels only, so the imbalance
correction never peeks at the test fold.
"""

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score
from xgboost import XGBClassifier

from ml.cross_validation import ExpandingWindowSplit, check_no_leakage
from ml.ml_config import (
    INITIAL_TRAIN_FRACTION,
    N_CV_FOLDS,
    N_SEARCH_ITERATIONS,
    PURGE_GAP,
    RANDOM_STATE,
    XGB_BASE_PARAMS,
    XGB_SEARCH_SPACE,
)


def _fit_one(X_train, y_train, X_test, params):
    """Fit a single XGBoost model with per-fold scale_pos_weight and return test scores."""
    n_pos = int(y_train.sum())
    n_neg = int(len(y_train) - n_pos)
    scale_pos_weight = (n_neg / n_pos) if n_pos > 0 else 1.0

    model_params = dict(params)
    model_params["scale_pos_weight"] = scale_pos_weight

    model = XGBClassifier(**model_params)
    model.fit(X_train, y_train)
    proba = model.predict_proba(X_test)[:, 1]
    return model, proba


def cross_validated_auroc(X, y, params=None, splitter=None, return_models=False):
    """
    Run expanding-window CV and return AUROC per fold for one parameter set.

    Parameters
    ----------
    X : pd.DataFrame (date-indexed, already aligned to y)
    y : pd.Series of 0/1 labels, same index as X
    params : dict or None
        XGBoost params; defaults to XGB_BASE_PARAMS.
    splitter : ExpandingWindowSplit or None
        Defaults to the project standard 5-fold expanding split with purge gap.
    return_models : bool
        If True, also return the fitted model from each fold.

    Returns
    -------
    dict with keys:
        fold_auroc : list of per-fold AUROC (np.nan for folds with one test class)
        mean_auroc, std_auroc : summary over valid folds
        fold_detail : list of dicts (sizes, positives, auroc)
        models : list (only if return_models)
    """
    if params is None:
        params = XGB_BASE_PARAMS
    if splitter is None:
        splitter = ExpandingWindowSplit(
            n_splits=N_CV_FOLDS,
            initial_train_fraction=INITIAL_TRAIN_FRACTION,
            purge_gap=PURGE_GAP,
        )

    X_values = X.values
    y_values = np.asarray(y).astype(int)

    fold_auroc = []
    fold_detail = []
    models = []

    for fold, (train_idx, test_idx) in enumerate(splitter.split(len(X_values))):
        check_no_leakage(train_idx, test_idx)

        X_train, y_train = X_values[train_idx], y_values[train_idx]
        X_test, y_test = X_values[test_idx], y_values[test_idx]

        model, proba = _fit_one(X_train, y_train, X_test, params)

        # AUROC is undefined if the test fold has only one class. PR-AUC
        # (average precision) is technically defined either way, but with a
        # single-class fold it is either trivially 1.0 (all-positive) or
        # trivially equal to the positive rate (all-negative, here 0) and
        # carries no information -- treat it as undefined too, for the same
        # reason and so the two columns are NaN on exactly the same folds.
        if len(np.unique(y_test)) < 2:
            auroc = np.nan
            pr_auc = np.nan
        else:
            auroc = roc_auc_score(y_test, proba)
            pr_auc = average_precision_score(y_test, proba)

        fold_auroc.append(auroc)
        fold_detail.append({
            "fold": fold,
            "train_size": int(len(train_idx)),
            "test_size": int(len(test_idx)),
            "test_positives": int(y_test.sum()),
            "auroc": auroc,
            "pr_auc": pr_auc,
        })
        if return_models:
            models.append(model)

    valid = [a for a in fold_auroc if not np.isnan(a)]
    valid_pr = [d["pr_auc"] for d in fold_detail if not np.isnan(d["pr_auc"])]
    n_scored = len(valid)
    n_total = len(fold_auroc)
    result = {
        "fold_auroc": fold_auroc,
        "mean_auroc": float(np.mean(valid)) if valid else np.nan,
        "std_auroc": float(np.std(valid)) if valid else np.nan,
        "mean_pr_auc": float(np.mean(valid_pr)) if valid_pr else np.nan,
        "std_pr_auc": float(np.std(valid_pr)) if valid_pr else np.nan,
        "fold_detail": fold_detail,
        # How many folds actually had both classes in the test block. A score
        # built on few folds is fragile; the paper must report this honestly.
        "n_scored_folds": n_scored,
        "n_total_folds": n_total,
        "single_class_folds": n_total - n_scored,
    }
    if return_models:
        result["models"] = models
    return result


def time_series_random_search(X, y, search_space=None, n_iter=N_SEARCH_ITERATIONS,
                              random_state=RANDOM_STATE):
    """
    Time-series-safe random hyperparameter search.

    Draws n_iter random parameter combinations from search_space, scores each with
    expanding-window CV, and returns the best by mean AUROC. No sklearn search CV
    is used anywhere, so no shuffling and no leakage.

    Returns
    -------
    dict with best_params, best_mean_auroc, best_std_auroc, and a results table
    (pd.DataFrame) of every combination tried.
    """
    if search_space is None:
        search_space = XGB_SEARCH_SPACE

    rng = np.random.default_rng(random_state)
    keys = list(search_space.keys())

    rows = []
    best = {"mean_auroc": -np.inf, "params": None, "std_auroc": np.nan}

    for it in range(n_iter):
        sampled = {k: search_space[k][rng.integers(len(search_space[k]))] for k in keys}
        params = dict(XGB_BASE_PARAMS)
        params.update(sampled)

        cv = cross_validated_auroc(X, y, params=params)
        row = dict(sampled)
        row["mean_auroc"] = cv["mean_auroc"]
        row["std_auroc"] = cv["std_auroc"]
        rows.append(row)

        if not np.isnan(cv["mean_auroc"]) and cv["mean_auroc"] > best["mean_auroc"]:
            best = {
                "mean_auroc": cv["mean_auroc"],
                "std_auroc": cv["std_auroc"],
                "params": params,
            }

    results_table = pd.DataFrame(rows).sort_values("mean_auroc", ascending=False)

    if best["params"] is None:
        # Every candidate scored NaN -- typically because every expanding-window
        # fold was single-class (no positive label in the test block). This is a
        # real possibility flagged in the project README, not just a synthetic-
        # data edge case, so fail soft (fall back to the base params) rather than
        # crashing the whole run on `best["params"].items()` downstream.
        best["params"] = dict(XGB_BASE_PARAMS)
        print("  WARNING: no parameter combination scored a valid AUROC "
              "(every fold was single-class). Falling back to XGB_BASE_PARAMS; "
              "treat this tuning result as uninformative.")

    return {
        "best_params": best["params"],
        "best_mean_auroc": best["mean_auroc"],
        "best_std_auroc": best["std_auroc"],
        "results_table": results_table.reset_index(drop=True),
    }


def compare_feature_sets(feature_sets, y, params=None):
    """
    Run CV for several named feature matrices and build a comparison table.

    Parameters
    ----------
    feature_sets : dict[str, pd.DataFrame]
        e.g. {"F1": f1_df, "F2": f2_df, "F3": f3_df}. Each must already be aligned
        to the same index as y.
    y : pd.Series of labels.

    Returns
    -------
    pd.DataFrame with one row per feature set: mean_auroc, std_auroc, n_features,
    and per-fold columns.
    """
    rows = []
    for name, X in feature_sets.items():
        cv = cross_validated_auroc(X, y, params=params)
        row = {
            "feature_set": name,
            "n_features": X.shape[1],
            "mean_auroc": cv["mean_auroc"],
            "std_auroc": cv["std_auroc"],
        }
        for d in cv["fold_detail"]:
            row[f"fold{d['fold']}_auroc"] = d["auroc"]
        rows.append(row)
    return pd.DataFrame(rows)
