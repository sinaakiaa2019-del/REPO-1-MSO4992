"""
SHAP interpretability wrapper for XGBoost (Sina Kia).

Week 3 task: shap.TreeExplainer -> shap_values, beeswarm plot for the F2 model so
the team can see which standard features matter most. Kept thin and reusable so it
works for F1/F3 models in later weeks too.

The plot function uses a non-interactive matplotlib backend so it runs headless
(on HPC / CI) and writes a PNG.
"""

import matplotlib
matplotlib.use("Agg")  # headless backend; must be set before pyplot import
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import shap


def compute_shap_values(model, X):
    """
    Compute SHAP values for a fitted tree model using TreeExplainer.

    Returns
    -------
    (shap_values, explainer)
        shap_values : np.ndarray of shape (n_samples, n_features) for the positive
        class. SHAP versions differ in return shape, so this normalises to 2D.
    """
    explainer = shap.TreeExplainer(model)
    raw = explainer.shap_values(X)

    # Newer SHAP returns an ndarray; some configs return a list per class.
    if isinstance(raw, list):
        shap_values = raw[1] if len(raw) > 1 else raw[0]
    else:
        shap_values = raw

    shap_values = np.asarray(shap_values)
    if shap_values.ndim == 3:
        # shape (n_samples, n_features, n_classes) -> take positive class
        shap_values = shap_values[:, :, -1]
    return shap_values, explainer


def mean_abs_importance(shap_values, feature_names):
    """
    Rank features by mean absolute SHAP value. Returns a sorted DataFrame.
    """
    import pandas as pd
    mean_abs = np.abs(shap_values).mean(axis=0)
    df = pd.DataFrame({"feature": feature_names, "mean_abs_shap": mean_abs})
    return df.sort_values("mean_abs_shap", ascending=False).reset_index(drop=True)


def save_beeswarm(shap_values, X, output_path, max_display=15, title=None):
    """
    Render and save a SHAP beeswarm summary plot to PNG.
    """
    plt.figure()
    shap.summary_plot(
        shap_values, X, max_display=max_display, show=False, plot_size=(8, 6)
    )
    if title:
        plt.title(title)
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close()
    return output_path


def compute_shap_values_oos(X, y, params=None, splitter=None, return_base_values=False):
    """
    Out-of-sample SHAP values (Week 4) — every row is explained by the model
    that predicted it out-of-sample under expanding-window CV, not by a model
    that saw it during training. This is what makes the resulting heatmap a
    legitimate "how did feature attribution evolve before each crash" figure
    rather than an in-sample artefact.

    Parameters
    ----------
    return_base_values : bool
        If True, also return a date-indexed Series of each row's model
        base_value (TreeExplainer.expected_value from the fold that produced
        it). Needed for waterfall plots (Week 7), which must start from the
        SAME baseline the SHAP values were computed relative to -- a
        different fold's base_value would make the waterfall not sum to the
        predicted margin. Off by default so existing Week 4/5/6 callers that
        unpack a single DataFrame are unaffected.

    Returns
    -------
    pd.DataFrame (as before), or (pd.DataFrame, pd.Series) if
    return_base_values=True.
    """
    import numpy as np
    from xgboost import XGBClassifier

    from ml.cross_validation import ExpandingWindowSplit, check_no_leakage
    from ml.ml_config import INITIAL_TRAIN_FRACTION, N_CV_FOLDS, PURGE_GAP, XGB_BASE_PARAMS

    if params is None:
        params = XGB_BASE_PARAMS
    if splitter is None:
        splitter = ExpandingWindowSplit(
            n_splits=N_CV_FOLDS,
            initial_train_fraction=INITIAL_TRAIN_FRACTION,
            purge_gap=PURGE_GAP,
        )

    X_values = X.values
    y_values = np.asarray(y).astype(int)
    dates = X.index
    feature_names = list(X.columns)

    rows_by_date = {}
    base_value_by_date = {}
    for train_idx, test_idx in splitter.split(len(X_values)):
        check_no_leakage(train_idx, test_idx)

        X_train, y_train = X_values[train_idx], y_values[train_idx]
        X_test = X_values[test_idx]

        n_pos = int(y_train.sum())
        n_neg = int(len(y_train) - n_pos)
        scale_pos_weight = (n_neg / n_pos) if n_pos > 0 else 1.0

        model_params = dict(params)
        model_params["scale_pos_weight"] = scale_pos_weight
        model = XGBClassifier(**model_params)
        model.fit(X_train, y_train)

        fold_shap, explainer = compute_shap_values(model, X.iloc[test_idx])
        base_value = explainer.expected_value
        if isinstance(base_value, (list, np.ndarray)):
            base_value = base_value[-1] if len(np.shape(base_value)) else float(base_value)
        for i, pos in enumerate(test_idx):
            rows_by_date[dates[pos]] = fold_shap[i]
            base_value_by_date[dates[pos]] = float(base_value)

    if not rows_by_date:
        empty = pd.DataFrame(columns=feature_names)
        return (empty, pd.Series(dtype=float)) if return_base_values else empty

    ordered_dates = sorted(rows_by_date.keys())
    matrix = np.vstack([rows_by_date[d] for d in ordered_dates])
    shap_df = pd.DataFrame(matrix, index=pd.DatetimeIndex(ordered_dates), columns=feature_names)

    if return_base_values:
        base_series = pd.Series(
            [base_value_by_date[d] for d in ordered_dates],
            index=pd.DatetimeIndex(ordered_dates), name="base_value",
        )
        return shap_df, base_series
    return shap_df


def save_shap_heatmap(shap_df, output_path, top_n=15, title=None):
    """
    Render a time x feature heatmap of out-of-sample SHAP values (Week 4).

    Rows are dates (chronological, test-fold coverage only), columns are the
    top_n features by mean |SHAP| over the whole period. Colour = signed SHAP
    contribution, so red bands show which features are pushing the crash
    probability up (and when), not just which features matter on average.
    """
    ranking = shap_df.abs().mean(axis=0).sort_values(ascending=False)
    top_features = ranking.head(top_n).index.tolist()
    plot_df = shap_df[top_features]

    fig_height = max(4, 0.35 * len(top_features))
    plt.figure(figsize=(11, fig_height))
    vmax = float(plot_df.abs().to_numpy().max()) if plot_df.size else 1.0
    plt.imshow(
        plot_df.T.values, aspect="auto", cmap="RdBu_r", vmin=-vmax, vmax=vmax,
        interpolation="nearest",
    )
    plt.colorbar(label="SHAP value (out-of-sample)")
    plt.yticks(range(len(top_features)), top_features, fontsize=8)

    n_dates = len(plot_df.index)
    tick_positions = np.linspace(0, n_dates - 1, min(8, n_dates)).astype(int)
    plt.xticks(
        tick_positions,
        [plot_df.index[i].strftime("%Y-%m") for i in tick_positions],
        rotation=45, ha="right", fontsize=8,
    )
    plt.title(title or "Out-of-sample SHAP heatmap (top features over time)")
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close()
    return output_path
