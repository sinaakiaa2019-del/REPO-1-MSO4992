"""
Cross-validation robustness check (Sina Kia) — Week 6.

Two separate questions this addresses:

1. Robustness: does the headline AUROC change a lot if we pick a different
   (but still reasonable) CV configuration? If the number of folds, the
   initial training fraction, or the purge gap moves the mean AUROC by a lot,
   that AUROC is fragile and should be reported with that caveat.

2. A specific, previously-flagged issue: with n_splits=5 and rare, clustered
   crashes, several test folds end up single-class (AUROC undefined there).
   This module checks whether fewer folds / a larger initial training block
   reduces how often that happens, and reports PR-AUC alongside AUROC on every
   configuration (PR-AUC is well-behaved under class imbalance in a way AUROC
   is not, and does not have the single-class-fold blind spot the same way).

A THIRD, deliberately included configuration removes the purge gap entirely
(purge_gap=0). This is not a "reasonable alternative" -- it is a known-bad
config kept in the table on purpose, as a sanity check: since the crash label
looks 20 trading days into the future, a purge_gap=0 run is expected to leak
information from the tail of the training block into the adjacent test block
and score noticeably BETTER than the purge_gap=20 baseline. If it doesn't,
that is itself worth investigating (either the leakage effect is smaller than
expected on this data, or something else is masking it).
"""

import pandas as pd

from ml.cross_validation import ExpandingWindowSplit
from ml.ml_config import CRASH_LOOKAHEAD_DAYS
from ml.models import cross_validated_auroc


def default_robustness_configs():
    """
    A handful of CV configurations spanning fold count, initial train
    fraction, and purge gap. The 'no_purge_gap' row is a known-bad control,
    not a candidate configuration -- see module docstring.
    """
    return [
        {"label": "baseline (5 folds, 40% initial, purge=20)",
         "n_splits": 5, "initial_train_fraction": 0.40, "purge_gap": CRASH_LOOKAHEAD_DAYS},
        {"label": "fewer folds (3 folds)",
         "n_splits": 3, "initial_train_fraction": 0.40, "purge_gap": CRASH_LOOKAHEAD_DAYS},
        {"label": "more folds (8 folds)",
         "n_splits": 8, "initial_train_fraction": 0.40, "purge_gap": CRASH_LOOKAHEAD_DAYS},
        {"label": "larger initial train (60%)",
         "n_splits": 5, "initial_train_fraction": 0.60, "purge_gap": CRASH_LOOKAHEAD_DAYS},
        {"label": "smaller initial train (25%)",
         "n_splits": 5, "initial_train_fraction": 0.25, "purge_gap": CRASH_LOOKAHEAD_DAYS},
        {"label": "NO PURGE GAP (known-bad control, expect leakage-inflated AUROC)",
         "n_splits": 5, "initial_train_fraction": 0.40, "purge_gap": 0},
    ]


def run_cv_robustness(X, y, configs=None, params=None):
    """
    Run cross_validated_auroc under each configuration and collect a
    comparison table.

    Returns pd.DataFrame with one row per configuration.
    """
    if configs is None:
        configs = default_robustness_configs()

    rows = []
    for cfg in configs:
        splitter = ExpandingWindowSplit(
            n_splits=cfg["n_splits"],
            initial_train_fraction=cfg["initial_train_fraction"],
            purge_gap=cfg["purge_gap"],
        )
        cv = cross_validated_auroc(X, y, params=params, splitter=splitter)
        rows.append({
            "config": cfg["label"],
            "n_splits": cfg["n_splits"],
            "initial_train_fraction": cfg["initial_train_fraction"],
            "purge_gap": cfg["purge_gap"],
            "mean_auroc": cv["mean_auroc"],
            "std_auroc": cv["std_auroc"],
            "mean_pr_auc": cv["mean_pr_auc"],
            "n_scored_folds": cv["n_scored_folds"],
            "n_total_folds": cv["n_total_folds"],
            "single_class_folds": cv["single_class_folds"],
        })

    return pd.DataFrame(rows)


def summarise_robustness(table):
    """
    Print a short, honest summary: the spread of mean_auroc across the
    "reasonable" configurations (everything except the no-purge-gap control),
    and an explicit check of the purge-gap leakage direction.
    """
    lines = []
    reasonable = table[~table["config"].str.contains("NO PURGE GAP")]
    valid = reasonable["mean_auroc"].dropna()
    if len(valid) >= 2:
        lines.append(
            f"AUROC across {len(valid)} reasonable configs: "
            f"min={valid.min():.3f}, max={valid.max():.3f}, "
            f"range={valid.max() - valid.min():.3f}"
        )
    else:
        lines.append("Not enough valid configs to summarise a range "
                     "(too many single-class folds).")

    no_purge = table[table["config"].str.contains("NO PURGE GAP")]
    baseline = table[table["config"].str.contains("baseline")]
    if not no_purge.empty and not baseline.empty:
        np_auroc = no_purge["mean_auroc"].iloc[0]
        bl_auroc = baseline["mean_auroc"].iloc[0]
        if pd.notna(np_auroc) and pd.notna(bl_auroc):
            direction = "HIGHER" if np_auroc > bl_auroc else "not higher"
            lines.append(
                f"No-purge-gap control: {np_auroc:.3f} vs baseline {bl_auroc:.3f} "
                f"-- {direction} than baseline "
                f"({'as expected if the purge gap is doing its job' if direction == 'HIGHER' else 'unexpected -- worth a closer look'})."
            )
    return "\n".join(lines)
