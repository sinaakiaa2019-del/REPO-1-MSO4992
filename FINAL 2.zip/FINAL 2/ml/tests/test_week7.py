"""
Unit tests for Week 7: international generalisation (transfer) and SHAP suite.
"""
import numpy as np
import pandas as pd
import pytest

from ml.international_generalisation import (
    evaluate_transfer,
    run_international_generalisation,
    train_source_model,
)
from ml.shap_suite import nearest_date_before, save_crisis_waterfalls


# ---------------- international generalisation ----------------

def _make_separable_f1(n=300, seed=0):
    rng = np.random.default_rng(seed)
    idx = pd.date_range("2000-01-01", periods=n, freq="D")
    y = pd.Series((rng.random(n) < 0.15).astype(int), index=idx)
    # Feature that's cleanly separable by the label, so a fitted model should
    # score meaningfully above chance -- lets us test the transfer plumbing
    # without depending on it learning a good rule from noise.
    X = pd.DataFrame({
        "h1_eps_000": y.values + rng.normal(0, 0.1, n),
        "h1_eps_001": rng.normal(0, 1, n),
    }, index=idx)
    return X, y


def test_train_source_model_returns_fitted_model_and_cv():
    X, y = _make_separable_f1()
    model, cv = train_source_model(X, y)
    assert model is not None
    assert cv["n_total_folds"] > 0
    # Fitted model must actually be usable for prediction.
    proba = model.predict_proba(X.values)[:, 1]
    assert len(proba) == len(X)


def test_evaluate_transfer_raises_on_column_mismatch():
    X, y = _make_separable_f1()
    model, _ = train_source_model(X, y)

    target = X.rename(columns={"h1_eps_001": "h1_eps_002"})  # different schema
    with pytest.raises(ValueError, match="schema"):
        evaluate_transfer(model, list(X.columns), target, y, "credit")


def test_evaluate_transfer_matching_schema_scores_above_chance():
    X, y = _make_separable_f1(seed=1)
    model, _ = train_source_model(X, y)

    # A second, independently generated but SAME-schema dataset with the same
    # separable structure -- transfer should do meaningfully better than
    # random (0.5 AUROC) on this, since the signal is literally the same
    # feature construction.
    X_target, y_target = _make_separable_f1(seed=2)
    result = evaluate_transfer(model, list(X.columns), X_target, y_target, "test_asset")

    assert result["asset_class"] == "test_asset"
    assert result["n_rows"] == len(y_target)
    assert result["transfer_auroc"] > 0.6


def test_evaluate_transfer_single_class_target_returns_nan_not_crash():
    X, y = _make_separable_f1()
    model, _ = train_source_model(X, y)

    all_negative_target = pd.Series(np.zeros(50, dtype=int),
                                    index=pd.date_range("2010-01-01", periods=50))
    X_target = pd.DataFrame({
        "h1_eps_000": np.zeros(50), "h1_eps_001": np.zeros(50),
    }, index=all_negative_target.index)

    result = evaluate_transfer(model, list(X.columns), X_target, all_negative_target, "degenerate")
    assert np.isnan(result["transfer_auroc"])
    assert np.isnan(result["transfer_pr_auc"])


def test_run_international_generalisation_includes_source_and_every_target():
    X_equity, y_equity = _make_separable_f1(seed=3)
    X_credit, y_credit_labels = _make_separable_f1(seed=4)
    X_intl, y_intl_labels = _make_separable_f1(seed=5)

    # run_international_generalisation aligns each target internally against
    # a SHARED crash_labels series (see ml.data_access.align_features_labels),
    # so build one shared label series and matching feature frames.
    crash_labels = y_equity.to_frame("crash_label")

    table, source_cv = run_international_generalisation(
        X_equity, y_equity,
        target_datasets={
            "credit": (X_credit.set_axis(y_equity.index[:len(X_credit)]), crash_labels.iloc[:len(X_credit)]),
        },
    )
    assert "credit" in table["asset_class"].values
    assert any("source" in a for a in table["asset_class"].values)


# ---------------- SHAP suite helpers ----------------

def test_nearest_date_before_picks_latest_qualifying_date():
    idx = pd.DatetimeIndex(["2020-01-01", "2020-01-10", "2020-01-20", "2020-02-01"])
    result = nearest_date_before(idx, "2020-01-25")
    assert result == pd.Timestamp("2020-01-20")


def test_nearest_date_before_returns_none_when_nothing_precedes_target():
    idx = pd.DatetimeIndex(["2020-06-01", "2020-07-01"])
    result = nearest_date_before(idx, "2020-01-01")
    assert result is None


def test_nearest_date_before_respects_lookback_guard():
    idx = pd.DatetimeIndex(["2018-01-01"])  # more than 2 years before target
    result = nearest_date_before(idx, "2020-01-01", max_lookback_days=30)
    assert result is None


def test_save_crisis_waterfalls_reports_none_not_crash_when_unexplainable(tmp_path):
    # No out-of-sample data at all -> every crisis should come back with
    # explained_date=None and path=None, not raise.
    empty_shap = pd.DataFrame(columns=["h1_eps_000"])
    empty_base = pd.Series(dtype=float)
    empty_X = pd.DataFrame(columns=["h1_eps_000"])

    result = save_crisis_waterfalls(
        empty_shap, empty_base, empty_X, tmp_path,
        reference_crashes=[("Test crisis", "2020-03-01", "2020-04-01")],
    )
    assert result.iloc[0]["explained_date"] is None
    assert result.iloc[0]["path"] is None
