"""
Unit tests for the time-series cross-validation framework (Sina Kia).

The plan's Week 2 deliverable explicitly requires:
  - assert no test data leaks into train
  - assert folds are temporally ordered

These tests cover those two guarantees plus the purge-gap behaviour and the
expanding (non-shrinking) training set. Run with:  pytest ml/tests
"""

import numpy as np
import pytest

from ml.cross_validation import (
    ExpandingWindowSplit,
    check_no_leakage,
    describe_splits,
)


def test_no_train_test_overlap():
    """No index appears in both train and test of the same fold."""
    splitter = ExpandingWindowSplit(n_splits=5, initial_train_fraction=0.4, purge_gap=0)
    for train_idx, test_idx in splitter.split(1000):
        assert len(np.intersect1d(train_idx, test_idx)) == 0


def test_train_strictly_before_test():
    """Every training position precedes every test position (no look-ahead)."""
    splitter = ExpandingWindowSplit(n_splits=5, initial_train_fraction=0.4, purge_gap=0)
    for train_idx, test_idx in splitter.split(1000):
        assert train_idx.max() < test_idx.min()
        check_no_leakage(train_idx, test_idx)


def test_folds_temporally_ordered():
    """Test blocks advance in time: each fold's test starts after the previous one's."""
    splitter = ExpandingWindowSplit(n_splits=5, initial_train_fraction=0.4, purge_gap=0)
    test_starts = [test_idx.min() for _, test_idx in splitter.split(1000)]
    assert test_starts == sorted(test_starts)
    assert len(set(test_starts)) == len(test_starts)  # strictly increasing, no repeats


def test_training_set_expands():
    """The training set grows (never shrinks) across folds — that is the point."""
    splitter = ExpandingWindowSplit(n_splits=5, initial_train_fraction=0.4, purge_gap=0)
    train_sizes = [len(train_idx) for train_idx, _ in splitter.split(1000)]
    assert all(b >= a for a, b in zip(train_sizes, train_sizes[1:]))


def test_purge_gap_removes_overlap_region():
    """With a purge gap, the last training index is at least `gap` before the test."""
    gap = 20
    splitter = ExpandingWindowSplit(n_splits=5, initial_train_fraction=0.4, purge_gap=gap)
    for train_idx, test_idx in splitter.split(1000):
        assert test_idx.min() - train_idx.max() > gap - 1


def test_n_splits_respected():
    splitter = ExpandingWindowSplit(n_splits=5, initial_train_fraction=0.4, purge_gap=0)
    folds = list(splitter.split(1000))
    assert len(folds) == 5
    assert splitter.get_n_splits() == 5


def test_describe_splits_is_consistent():
    splitter = ExpandingWindowSplit(n_splits=4, initial_train_fraction=0.5, purge_gap=10)
    summary = describe_splits(splitter, 800)
    assert len(summary) >= 1
    for s in summary:
        assert s["train_end"] < s["test_start"]
        assert s["test_start"] <= s["test_end"]


def test_rejects_too_few_samples():
    splitter = ExpandingWindowSplit(n_splits=5)
    with pytest.raises(ValueError):
        list(splitter.split(3))


def test_rejects_bad_fraction():
    with pytest.raises(ValueError):
        ExpandingWindowSplit(initial_train_fraction=1.5)


def test_check_no_leakage_catches_overlap():
    with pytest.raises(AssertionError):
        check_no_leakage(np.array([0, 1, 2, 3]), np.array([3, 4, 5]))


def test_check_no_leakage_catches_future_in_train():
    with pytest.raises(AssertionError):
        check_no_leakage(np.array([0, 1, 9]), np.array([5, 6, 7]))
