"""
Tests for the Week-8 completion modules (Sina Kia):
DeLong test, leave-one-crisis-out evaluation, VIX-baseline lead time.
"""

import numpy as np
import pandas as pd
import pytest

from common.stats_tests import bootstrap_auroc_ci, delong_roc_test
from ml.leave_one_crisis_out import leave_one_crisis_out
from ml.vix_lead_time_baseline import (
    topology_vs_vix_lead_time,
    vix_alarm_series,
    vix_lead_times,
)


# ---- DeLong -------------------------------------------------------------

def test_delong_matches_sklearn_aucs():
    from sklearn.metrics import roc_auc_score
    rng = np.random.default_rng(1)
    n = 400
    y = (rng.random(n) < 0.3).astype(int)
    pa = np.clip(0.7 * y + 0.3 * rng.random(n), 0, 1)
    pb = np.clip(0.2 * y + 0.8 * rng.random(n), 0, 1)
    res = delong_roc_test(y, pa, pb)
    assert res["auc_a"] == pytest.approx(roc_auc_score(y, pa), abs=1e-9)
    assert res["auc_b"] == pytest.approx(roc_auc_score(y, pb), abs=1e-9)
    # A is clearly better -> significant, positive diff.
    assert res["auc_diff"] > 0
    assert res["significant_05"]


def test_delong_identical_models_not_significant():
    rng = np.random.default_rng(2)
    y = (rng.random(300) < 0.3).astype(int)
    p = rng.random(300)
    res = delong_roc_test(y, p, p)
    assert res["p_value"] == pytest.approx(1.0)
    assert not res["significant_05"]


def test_delong_requires_both_classes():
    with pytest.raises(ValueError):
        delong_roc_test(np.zeros(10, dtype=int), np.random.rand(10), np.random.rand(10))


def test_bootstrap_ci_brackets_point_estimate():
    rng = np.random.default_rng(3)
    y = (rng.random(300) < 0.4).astype(int)
    p = np.clip(0.6 * y + 0.4 * rng.random(300), 0, 1)
    ci = bootstrap_auroc_ci(y, p, n_boot=300)
    assert ci["ci_low"] <= ci["auroc"] <= ci["ci_high"]


# ---- Leave-one-crisis-out ----------------------------------------------

def _synthetic_xy_with_crises():
    """Feature that carries a crash signal, with labelled crises in 2008 & 2020."""
    dates = pd.bdate_range("2005-01-01", "2022-12-31", freq="5B")
    rng = np.random.default_rng(0)
    y = pd.Series(0, index=dates)
    for s, e in [("2008-09-01", "2009-03-31"), ("2020-02-15", "2020-04-15")]:
        y.loc[s:e] = 1
    # signal feature = label + noise; a second pure-noise feature
    X = pd.DataFrame({
        "signal": y.values * 2.0 + rng.normal(0, 1, len(dates)),
        "noise": rng.normal(0, 1, len(dates)),
    }, index=dates)
    return X, y


def test_loco_runs_and_scores_held_out_crises():
    X, y = _synthetic_xy_with_crises()
    ref = [("2008 GFC", "2008-09-01", "2009-03-31"),
           ("2020 COVID", "2020-02-15", "2020-04-15")]
    table = leave_one_crisis_out(X, y, reference_crashes=ref)
    assert set(table["crisis"]) == {"2008 GFC", "2020 COVID"}
    # With a real signal feature, held-out-crisis AUROC should beat chance.
    scored = table["auroc"].dropna()
    assert len(scored) >= 1
    assert scored.mean() > 0.6


def test_loco_embargo_removes_held_out_crisis_from_train():
    X, y = _synthetic_xy_with_crises()
    ref = [("2008 GFC", "2008-09-01", "2009-03-31")]
    # If the embargo works, training set should contain no 2008-crisis positives.
    # We check indirectly: the function completes and the held-out crisis has
    # test positives (i.e. it was actually held out for testing, not trained on).
    table = leave_one_crisis_out(X, y, reference_crashes=ref)
    row = table.iloc[0]
    assert row["n_test_positive"] > 0


# ---- VIX lead-time baseline --------------------------------------------

def test_vix_alarm_series_is_trailing_no_lookahead():
    # A VIX series that spikes late; the alarm at the spike should use only
    # trailing info (rolling quantile), so early dates are not flagged.
    dates = pd.bdate_range("2019-01-01", periods=400)
    vix = pd.Series(15.0, index=dates)
    vix.iloc[-20:] = 45.0  # spike near the end
    alarms = vix_alarm_series(vix, quantile=0.95, rolling_window=252, min_periods=60)
    assert alarms.iloc[:60].sum() == 0        # nothing before min_periods
    # The spike is flagged when it FIRST appears (before the trailing 95th-pct
    # threshold adapts to include the elevated values). The onset of the spike
    # is the last 20 rows, so at least one of the first few spike days fires.
    assert alarms.iloc[-20:-15].any()


def test_vix_lead_times_and_differential():
    # Build a VIX that crosses its 95th pct ~10 trading days before a crash.
    dates = pd.bdate_range("2019-06-01", "2020-06-30")
    vix = pd.Series(15.0, index=dates)
    onset = pd.Timestamp("2020-02-15")
    pre = dates[(dates >= onset - pd.tseries.offsets.BDay(10)) & (dates < onset)]
    vix.loc[pre] = 40.0
    ref = [("2020 COVID", "2020-02-15", "2020-04-15")]
    vix_df = vix_lead_times(vix, reference_crashes=ref)
    assert vix_df.iloc[0]["vix_alarm_found"]
    assert vix_df.iloc[0]["vix_lead_time_trading_days"] > 0

    # topology fired 25 trading days before; differential should be positive.
    topo_df = pd.DataFrame([{
        "crisis": "2020 COVID", "onset": "2020-02-15",
        "alarm_date": "2020-01-10", "lead_time_trading_days": 25.0,
        "alarm_found": True,
    }])
    merged = topology_vs_vix_lead_time(topo_df, vix_df)
    assert merged.iloc[0]["topology_minus_vix_days"] > 0
