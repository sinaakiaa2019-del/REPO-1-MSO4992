"""
Unit tests for Week 4: F3 combined features and lead-time analysis.
"""
import numpy as np
import pandas as pd
import pytest

from ml.f3_combined_features import build_f1_f2_f3, build_f3_features
from ml.lead_time_analysis import compute_lead_times


# ---------------- F3 construction ----------------

def test_f3_is_column_union_of_f1_and_f2():
    idx = pd.date_range("2020-01-01", periods=5, freq="D")
    f1 = pd.DataFrame({"h1_eps_000": range(5), "h1_eps_001": range(5)}, index=idx)
    f2 = pd.DataFrame({"vix": range(5), "eigenvalue_gap": range(5)}, index=idx)

    f3 = build_f3_features(f1, f2)

    assert set(f3.columns) == {"h1_eps_000", "h1_eps_001", "vix", "eigenvalue_gap"}
    assert len(f3) == 5


def test_f3_disambiguates_overlapping_column_names():
    idx = pd.date_range("2020-01-01", periods=5, freq="D")
    f1 = pd.DataFrame({"shared": range(5)}, index=idx)
    f2 = pd.DataFrame({"shared": range(5, 10)}, index=idx)

    f3 = build_f3_features(f1, f2)

    assert "f1_shared" in f3.columns
    assert "f2_shared" in f3.columns
    assert "shared" not in f3.columns
    assert (f3["f1_shared"] != f3["f2_shared"]).all()
    # attrs must reflect the RENAMED names, not the original "shared" -- this
    # is what ml.ablation relies on to classify columns correctly after a
    # collision (see test_run_ablation_uses_f3_attrs_membership_after_collision_rename).
    assert f3.attrs["f1_columns"] == ["f1_shared"]
    assert f3.attrs["f2_columns"] == ["f2_shared"]


def test_f3_row_count_matches_common_index_only():
    # F1 has an extra early date F2 doesn't have -- F3 must not include it.
    f1 = pd.DataFrame(
        {"x": [1, 2, 3]},
        index=pd.to_datetime(["2020-01-01", "2020-01-02", "2020-01-03"]),
    )
    f2 = pd.DataFrame(
        {"y": [1, 2]},
        index=pd.to_datetime(["2020-01-02", "2020-01-03"]),
    )
    f3 = build_f3_features(f1, f2)
    assert len(f3) == 2
    assert pd.Timestamp("2020-01-01") not in f3.index


def test_build_f1_f2_f3_aligns_to_labels_and_returns_three_sets():
    idx = pd.date_range("2020-01-01", periods=10, freq="D")
    f1 = pd.DataFrame({"topo": np.arange(10.0)}, index=idx)
    f2 = pd.DataFrame({"vix": np.arange(10.0) * 2}, index=idx)
    labels = pd.DataFrame({"crash_label": [0, 0, 1, 0, 0, 1, 0, 0, 0, 1]}, index=idx)

    aligned, y = build_f1_f2_f3(f1, f2, labels)

    assert set(aligned.keys()) == {"F1", "F2", "F3"}
    assert len(aligned["F3"]) == len(y) == 10
    assert list(aligned["F3"].columns) == ["topo", "vix"]


# ---------------- lead-time analysis ----------------

def _reference_crashes():
    return [("Test crisis", "2020-03-01", "2020-04-01")]


def test_lead_time_finds_alarm_and_reports_trading_days_not_row_count():
    # Build a proba series stepped every 5 CALENDAR days (not 5 trading days,
    # to keep the test simple/deterministic) so a naive "count rows" bug would
    # give a different answer than counting actual trading days.
    dates = pd.date_range("2020-01-01", "2020-02-28", freq="5D")
    proba = pd.Series(0.1, index=dates)
    # Force an alarm starting at an actual grid date well before onset.
    alarm_date = dates[dates >= "2020-02-11"][0]
    proba.loc[proba.index >= alarm_date] = 0.9

    result = compute_lead_times(proba, threshold=0.5,
                                reference_crashes=_reference_crashes(),
                                lookback_days=120)

    row = result.iloc[0]
    assert row["alarm_found"]
    assert row["alarm_date"] == alarm_date.date().isoformat()
    # np.busday_count between 2020-02-11 and 2020-03-01 (exclusive of end) = 13
    expected = int(np.busday_count(alarm_date.date(), pd.Timestamp("2020-03-01").date()))
    assert row["lead_time_trading_days"] == expected
    # Sanity: this must NOT equal a naive row-count (which would be much smaller
    # since rows are 5 calendar days apart).
    naive_row_count = int((proba.index >= alarm_date).sum() - 1)
    assert row["lead_time_trading_days"] != naive_row_count or expected == naive_row_count


def test_lead_time_no_alarm_reports_not_found():
    dates = pd.date_range("2020-01-01", "2020-02-28", freq="5D")
    proba = pd.Series(0.05, index=dates)  # never crosses threshold

    result = compute_lead_times(proba, threshold=0.5,
                                reference_crashes=_reference_crashes(),
                                lookback_days=120)

    row = result.iloc[0]
    assert not row["alarm_found"]
    assert row["alarm_date"] is None
    assert pd.isna(row["lead_time_trading_days"])
    assert row["max_proba_in_window"] == pytest.approx(0.05)


def test_lead_time_lookback_window_is_trading_days_not_row_count():
    # Two alarms: one far outside a 10-trading-day lookback, one just inside.
    dates = pd.date_range("2019-01-01", "2020-02-28", freq="1D")
    dates = dates[dates.weekday < 5]  # trading days only
    proba = pd.Series(0.1, index=dates)

    far_alarm = pd.Timestamp("2019-06-01")   # far outside any reasonable lookback
    near_alarm = pd.Timestamp("2020-02-20")  # within 10 trading days of 2020-03-01
    proba.loc[proba.index == far_alarm] = 0.9
    proba.loc[proba.index >= near_alarm] = 0.9

    result = compute_lead_times(proba, threshold=0.5,
                                reference_crashes=_reference_crashes(),
                                lookback_days=10)

    row = result.iloc[0]
    assert row["alarm_found"]
    # Must pick the NEAR alarm (within the 10-trading-day window), not the far one.
    assert row["alarm_date"] == near_alarm.date().isoformat()


def test_lead_time_empty_proba_series_handled_gracefully():
    empty = pd.Series([], dtype=float)
    result = compute_lead_times(empty, threshold=0.5,
                                reference_crashes=_reference_crashes())
    row = result.iloc[0]
    assert not row["alarm_found"]
    assert row["n_oos_obs_in_window"] == 0
