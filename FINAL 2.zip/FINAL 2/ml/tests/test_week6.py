"""
Unit tests for Week 6: ablation grouping, calibration curve math, CV robustness.
"""
import numpy as np
import pandas as pd
import pytest

from ml.ablation import group_f3_columns, run_ablation
from ml.calibration import (
    brier_score,
    compute_calibration_curve,
    expected_calibration_error,
)
from ml.cross_validation import ExpandingWindowSplit
from ml.cv_robustness import default_robustness_configs, run_cv_robustness
from ml.models import cross_validated_auroc


# ---------------- ablation grouping ----------------

def test_group_f3_columns_separates_curve_scalar_and_standard():
    f1_cols = ["h1_eps_000", "h1_eps_001", "h1_persistence_entropy", "h1_max_persistence"]
    f2_cols = ["vix", "eigenvalue_gap"]
    groups = group_f3_columns(f1_cols + f2_cols, f1_columns=f1_cols, f2_columns=f2_cols)

    assert groups["f1_curve"] == ["h1_eps_000", "h1_eps_001"]
    assert set(groups["f1_scalar"]) == {"h1_persistence_entropy", "h1_max_persistence"}
    assert groups["vix"] == ["vix"]
    assert groups["eigenvalue_gap"] == ["eigenvalue_gap"]


def test_group_f3_columns_omits_empty_groups():
    f1_cols = []  # no topology columns at all
    f2_cols = ["vix", "eigenvalue_gap"]
    groups = group_f3_columns(f2_cols, f1_columns=f1_cols, f2_columns=f2_cols)
    assert "f1_curve" not in groups
    assert "f1_scalar" not in groups


def test_group_f3_columns_never_misfiles_an_unrecognised_topology_scalar_as_standard():
    # Regression guard: Kunal's real topology_features.csv handover is
    # documented to eventually include a "Gidea & Katz L2-norm" column and
    # other scalar names that don't match any hardcoded substring. Since
    # membership is now taken EXPLICITLY from f1_columns/f2_columns rather
    # than guessed from the name, an arbitrarily-named F1 column must still
    # land in f1_scalar, never silently become its own "standard feature".
    f1_cols = ["h1_eps_000", "gidea_katz_l2_norm", "some_future_kunal_metric"]
    f2_cols = ["vix"]
    groups = group_f3_columns(f1_cols + f2_cols, f1_columns=f1_cols, f2_columns=f2_cols)

    assert set(groups["f1_scalar"]) == {"gidea_katz_l2_norm", "some_future_kunal_metric"}
    assert "gidea_katz_l2_norm" not in groups  # not its own standalone group
    assert "some_future_kunal_metric" not in groups


def test_group_f3_columns_raises_on_column_not_in_either_set():
    with pytest.raises(ValueError):
        group_f3_columns(["mystery_column"], f1_columns=["h1_eps_000"], f2_columns=["vix"])


def _f1_f2_columns(X):
    f1 = [c for c in X.columns if c.startswith("h1_")]
    f2 = [c for c in X.columns if not c.startswith("h1_")]
    return f1, f2


def test_run_ablation_every_ablated_set_has_fewer_or_equal_columns_than_full():
    idx = pd.date_range("2020-01-01", periods=200, freq="D")
    rng = np.random.default_rng(0)
    X = pd.DataFrame({
        "h1_eps_000": rng.normal(size=200),
        "h1_eps_001": rng.normal(size=200),
        "h1_persistence_entropy": rng.normal(size=200),
        "vix": rng.normal(size=200),
        "eigenvalue_gap": rng.normal(size=200),
    }, index=idx)
    y = pd.Series((rng.random(200) < 0.1).astype(int), index=idx)
    f1_cols, f2_cols = _f1_f2_columns(X)

    table = run_ablation(X, y, f1_columns=f1_cols, f2_columns=f2_cols)

    full_row = table[table["ablation"] == "full_F3"].iloc[0]
    assert full_row["n_features_used"] == X.shape[1]
    for _, row in table.iterrows():
        if row["ablation"] != "full_F3":
            assert row["n_features_used"] < full_row["n_features_used"]


def test_run_ablation_delta_is_zero_for_full_row():
    idx = pd.date_range("2020-01-01", periods=100, freq="D")
    rng = np.random.default_rng(1)
    X = pd.DataFrame({"vix": rng.normal(size=100), "h1_eps_000": rng.normal(size=100)}, index=idx)
    y = pd.Series((rng.random(100) < 0.2).astype(int), index=idx)
    f1_cols, f2_cols = _f1_f2_columns(X)

    table = run_ablation(X, y, f1_columns=f1_cols, f2_columns=f2_cols)
    full_row = table[table["ablation"] == "full_F3"].iloc[0]
    assert full_row["delta_auroc_vs_full"] == pytest.approx(0.0)


def test_run_ablation_uses_f3_attrs_membership_after_collision_rename():
    # End-to-end regression: build_f3_features renames on a name collision,
    # and the resulting F3.attrs must be the thing ablation trusts -- not a
    # name-pattern guess -- so a collided column is classified correctly.
    from ml.f3_combined_features import build_f3_features

    idx = pd.date_range("2020-01-01", periods=150, freq="D")
    rng = np.random.default_rng(3)
    f1 = pd.DataFrame({
        "shared": rng.normal(size=150),          # will collide -> renamed f1_shared
        "h1_eps_000": rng.normal(size=150),
    }, index=idx)
    f2 = pd.DataFrame({
        "shared": rng.normal(size=150),          # will collide -> renamed f2_shared
    }, index=idx)

    f3 = build_f3_features(f1, f2)
    assert "f1_shared" in f3.attrs["f1_columns"]
    assert "f2_shared" in f3.attrs["f2_columns"]

    y = pd.Series((rng.random(150) < 0.15).astype(int), index=idx)
    table = run_ablation(
        f3, y, f1_columns=f3.attrs["f1_columns"], f2_columns=f3.attrs["f2_columns"],
    )
    # The renamed F2 column must appear as its own standard-feature ablation
    # group, not get folded into f1_scalar just because it starts with "f1_"-
    # adjacent naming or shares a base name with an F1 column.
    assert "minus_f2_shared" in table["ablation"].values


# ---------------- calibration ----------------

def test_calibration_curve_perfectly_calibrated_predictions():
    # Predictions that exactly equal the empirical positive rate per bin.
    proba = np.array([0.05] * 100 + [0.95] * 100)
    y = np.array([0] * 95 + [1] * 5 + [1] * 95 + [0] * 5)  # 5% and 95% positive resp.

    table = compute_calibration_curve(proba, y, n_bins=10)
    ece = expected_calibration_error(table)
    assert ece < 0.02  # should be very close to perfectly calibrated


def test_calibration_curve_bin_boundaries_cover_zero_and_one():
    proba = np.array([0.0, 1.0, 0.5])
    y = np.array([0, 1, 0])
    table = compute_calibration_curve(proba, y, n_bins=10)
    # No prediction should be dropped for landing exactly on an edge.
    assert table["count"].sum() == 3


def test_brier_score_perfect_predictions_is_zero():
    proba = np.array([0.0, 1.0, 1.0, 0.0])
    y = np.array([0, 1, 1, 0])
    assert brier_score(proba, y) == pytest.approx(0.0)


def test_brier_score_worst_case_predictions_is_one():
    proba = np.array([1.0, 0.0])
    y = np.array([0, 1])
    assert brier_score(proba, y) == pytest.approx(1.0)


def test_expected_calibration_error_empty_table_is_nan():
    empty = pd.DataFrame(columns=["bin_low", "bin_high", "mean_predicted",
                                  "observed_frequency", "count"])
    assert np.isnan(expected_calibration_error(empty))


def test_calibration_curve_raises_on_mismatched_lengths():
    with pytest.raises(ValueError):
        compute_calibration_curve([0.1, 0.2], [1])


# ---------------- CV robustness ----------------

def test_default_robustness_configs_include_a_no_purge_gap_control():
    configs = default_robustness_configs()
    purge_gaps = [c["purge_gap"] for c in configs]
    assert 0 in purge_gaps
    assert any(c["purge_gap"] > 0 for c in configs)


def test_run_cv_robustness_one_row_per_config():
    idx = pd.date_range("2000-01-01", periods=2000, freq="D")
    rng = np.random.default_rng(2)
    X = pd.DataFrame({"f": rng.normal(size=2000)}, index=idx)
    y = pd.Series((rng.random(2000) < 0.1).astype(int), index=idx)

    configs = default_robustness_configs()
    table = run_cv_robustness(X, y, configs=configs)

    assert len(table) == len(configs)
    assert set(table["config"]) == {c["label"] for c in configs}


def test_no_purge_gap_uses_more_training_rows_than_baseline_near_test_boundary():
    # Direct mechanical check on ExpandingWindowSplit itself: with purge_gap=0
    # the training block extends right up to the test block; with purge_gap=20
    # it must stop 20 rows earlier, for every fold.
    n = 500
    baseline = ExpandingWindowSplit(n_splits=3, initial_train_fraction=0.4, purge_gap=20)
    no_purge = ExpandingWindowSplit(n_splits=3, initial_train_fraction=0.4, purge_gap=0)

    for (train_b, test_b), (train_np, test_np) in zip(
        baseline.split(n), no_purge.split(n)
    ):
        assert test_b.min() == test_np.min()  # same test block
        assert len(train_np) - len(train_b) == 20  # purge gap removed exactly 20 rows
