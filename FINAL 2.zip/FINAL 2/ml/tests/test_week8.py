"""
Unit tests for Week 8: confusion matrix, lead-time histogram, LSTM sequence
building, model persistence, and live-feature fallback behaviour.
"""
import numpy as np
import pandas as pd
import pytest

from ml.confusion_matrix_analysis import (
    best_f1_threshold,
    compute_confusion_matrix,
    sweep_thresholds,
)
from ml.lead_time_histogram import detect_crash_episodes
from ml.live_features import LiveDataUnavailableError, fetch_live_f2_snapshot
from ml.lstm_benchmark import build_sequences
from ml.model_persistence import load_model, save_model, score_with_saved_model


# ---------------- confusion matrix ----------------

def test_confusion_matrix_perfect_predictions():
    proba = np.array([0.9, 0.9, 0.1, 0.1])
    y = np.array([1, 1, 0, 0])
    cm = compute_confusion_matrix(proba, y, threshold=0.5)
    assert cm == {
        "threshold": 0.5, "tp": 2, "fp": 0, "tn": 2, "fn": 0,
        "precision": 1.0, "recall": 1.0, "specificity": 1.0, "f1": 1.0, "accuracy": 1.0,
    }


def test_confusion_matrix_no_predicted_positives_gives_zero_not_nan():
    proba = np.array([0.1, 0.2, 0.3])
    y = np.array([0, 1, 0])
    cm = compute_confusion_matrix(proba, y, threshold=0.9)
    assert cm["tp"] == 0 and cm["fp"] == 0
    assert cm["precision"] == 0.0  # not NaN
    assert cm["f1"] == 0.0


def test_confusion_matrix_raises_on_length_mismatch():
    with pytest.raises(ValueError):
        compute_confusion_matrix([0.1, 0.2], [1])


def test_sweep_thresholds_higher_threshold_never_increases_recall():
    rng = np.random.default_rng(0)
    proba = rng.random(200)
    y = (rng.random(200) < 0.2).astype(int)
    sweep = sweep_thresholds(proba, y)
    # Recall is monotonically non-increasing as threshold rises.
    assert (sweep["recall"].diff().dropna() <= 1e-9).all()


def test_best_f1_threshold_matches_max_row():
    rng = np.random.default_rng(1)
    proba = rng.random(200)
    y = (rng.random(200) < 0.3).astype(int)
    sweep = sweep_thresholds(proba, y)
    best = best_f1_threshold(sweep)
    assert best["f1"] == sweep["f1"].max()


def test_best_f1_threshold_empty_table_returns_none():
    assert best_f1_threshold(pd.DataFrame()) is None


# ---------------- crash episode detection ----------------

def test_detect_crash_episodes_merges_nearby_runs():
    dates = pd.date_range("2020-01-01", periods=30, freq="D")
    labels = pd.Series(0, index=dates)
    labels.iloc[0:3] = 1     # run 1: days 0-2
    labels.iloc[5:8] = 1     # run 2: days 5-7 (gap of 2 days from run 1 -- should merge)
    labels.iloc[20:22] = 1   # run 3: days 20-21 (far from run 2 -- separate episode)

    episodes = detect_crash_episodes(labels, max_gap_days=10)

    assert len(episodes) == 2
    name1, start1, end1 = episodes[0]
    assert start1 == dates[0]
    assert end1 == dates[7]  # merged run 1 + run 2
    name2, start2, end2 = episodes[1]
    assert start2 == dates[20]


def test_detect_crash_episodes_respects_max_gap():
    dates = pd.date_range("2020-01-01", periods=30, freq="D")
    labels = pd.Series(0, index=dates)
    labels.iloc[0:2] = 1
    labels.iloc[15:17] = 1  # gap of 13 days -- should NOT merge with max_gap_days=10

    episodes = detect_crash_episodes(labels, max_gap_days=10)
    assert len(episodes) == 2


def test_detect_crash_episodes_no_positives_returns_empty():
    dates = pd.date_range("2020-01-01", periods=10, freq="D")
    labels = pd.Series(0, index=dates)
    assert detect_crash_episodes(labels) == []


def test_detect_crash_episodes_accepts_dataframe_input():
    dates = pd.date_range("2020-01-01", periods=5, freq="D")
    df = pd.DataFrame({"crash_label": [0, 1, 1, 0, 0]}, index=dates)
    episodes = detect_crash_episodes(df)
    assert len(episodes) == 1


# ---------------- LSTM sequence building ----------------

def test_build_sequences_shape_and_alignment():
    idx = pd.date_range("2020-01-01", periods=50, freq="D")
    X = pd.DataFrame({"f1": np.arange(50), "f2": np.arange(50) * 2}, index=idx)
    y = pd.Series((np.arange(50) % 7 == 0).astype(int), index=idx)

    seq_len = 10
    sequences, labels, dates = build_sequences(X, y, seq_len=seq_len)

    assert sequences.shape == (50 - seq_len + 1, seq_len, 2)
    assert len(labels) == len(dates) == sequences.shape[0]
    # First sequence should be rows 0..9, label from row 9.
    np.testing.assert_array_equal(sequences[0, :, 0], np.arange(0, 10))
    assert labels[0] == y.iloc[9]
    assert dates[0] == idx[9]


def test_build_sequences_raises_when_too_short():
    idx = pd.date_range("2020-01-01", periods=5, freq="D")
    X = pd.DataFrame({"f1": range(5)}, index=idx)
    y = pd.Series([0, 0, 1, 0, 0], index=idx)
    with pytest.raises(ValueError):
        build_sequences(X, y, seq_len=10)


def test_build_sequences_last_sequence_ends_at_last_row():
    idx = pd.date_range("2020-01-01", periods=20, freq="D")
    X = pd.DataFrame({"f1": np.arange(20)}, index=idx)
    y = pd.Series(np.zeros(20, dtype=int), index=idx)
    sequences, labels, dates = build_sequences(X, y, seq_len=5)
    assert dates[-1] == idx[-1]
    assert sequences[-1, -1, 0] == 19


# ---------------- model persistence ----------------

class _FakeModel:
    """Minimal stand-in with the same predict_proba contract as XGBClassifier."""
    def predict_proba(self, X):
        # Return a fixed, checkable probability regardless of input.
        return np.tile([0.3, 0.7], (len(X), 1))


def test_save_and_load_model_round_trip(tmp_path):
    model = _FakeModel()
    columns = ["vix", "realised_vol_20d", "yield_curve_slope"]
    path, meta_path = save_model(model, columns, tmp_path / "model.joblib")

    loaded_model, metadata = load_model(path)
    assert metadata["feature_columns"] == columns
    assert metadata["n_features"] == 3
    assert "trained_at_utc" in metadata


def test_load_model_missing_file_raises_clear_error(tmp_path):
    with pytest.raises(FileNotFoundError):
        load_model(tmp_path / "does_not_exist.joblib")


def test_score_with_saved_model_enforces_column_order():
    model = _FakeModel()
    metadata = {"feature_columns": ["a", "b", "c"]}
    row = {"c": 3, "a": 1, "b": 2}  # deliberately out of order
    proba = score_with_saved_model(model, metadata, row)
    assert proba == pytest.approx(0.7)


def test_score_with_saved_model_raises_on_missing_column():
    model = _FakeModel()
    metadata = {"feature_columns": ["a", "b", "c"]}
    row = {"a": 1, "b": 2}  # missing "c"
    with pytest.raises(ValueError, match="missing columns"):
        score_with_saved_model(model, metadata, row)


# ---------------- live features fallback ----------------

def test_fetch_live_f2_snapshot_raises_typed_error_when_unavailable():
    # In this sandboxed test environment, network access to Yahoo
    # Finance / FRED is not available -- this test asserts the FAILURE path
    # raises the documented exception type (not an unrelated bare exception),
    # so the dashboard's except clause actually catches it. It does NOT
    # exercise the success path, which requires real network access.
    with pytest.raises(LiveDataUnavailableError):
        fetch_live_f2_snapshot()
