"""
pytest configuration for the ML test suite.

ml/ml_config.py imports the project-level config.py (Octavian's data-engineering
config) so the two stages never disagree about file paths. That import only
resolves when the PROJECT ROOT is on sys.path. When pytest is invoked from the
project root this already works, but running `pytest ml/tests` from elsewhere,
or importing the package in isolation, previously failed at collection with
`ModuleNotFoundError: No module named 'config'`.

Adding the project root here makes the suite runnable from anywhere, so the
"all tests pass" claim is reproducible from a clean checkout without needing to
know the invocation trick.
"""

import sys
from pathlib import Path

# ml/tests/conftest.py -> ml/tests -> ml -> project root
PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
