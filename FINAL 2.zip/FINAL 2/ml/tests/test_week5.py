"""
Unit tests for Week 5: cross-asset AUROC stacking and sector leadership pivot.
"""
import numpy as np
import pandas as pd

from ml.cross_asset_validation import build_cross_asset_auroc_table, load_asset_class_features
from ml.lead_time_analysis import compute_lead_times
from ml.sector_leadership import (
    SECTOR_LEAD_BIAS_DAYS,
    load_sector_f1_features,
    pivot_leadership_heatmap,
)


# ---------------- cross-asset table stacking ----------------

def test_cross_asset_table_stacks_and_tags_asset_class():
    equity = pd.DataFrame({"asset_class": ["equity"], "feature_set": ["F1"], "mean_auroc": [0.9]})
    credit = pd.DataFrame({"asset_class": ["credit"], "feature_set": ["F1"], "mean_auroc": [0.8]})
    intl = pd.DataFrame({"asset_class": ["international"], "feature_set": ["F1"], "mean_auroc": [0.7]})

    stacked = build_cross_asset_auroc_table(equity, credit, intl)

    assert len(stacked) == 3
    assert list(stacked["asset_class"]) == ["equity", "credit", "international"]
    assert list(stacked["mean_auroc"]) == [0.9, 0.8, 0.7]


def test_cross_asset_table_preserves_row_order_within_each_table():
    equity = pd.DataFrame({
        "asset_class": ["equity", "equity"],
        "feature_set": ["F1", "F2"],
        "mean_auroc": [0.9, 0.85],
    })
    stacked = build_cross_asset_auroc_table(equity)
    assert list(stacked["feature_set"]) == ["F1", "F2"]


# ---------------- sector leadership pivot ----------------

def _long_table(rows):
    """rows: list of (sector, crisis, lead_time_trading_days)."""
    return pd.DataFrame(rows, columns=["sector", "crisis", "lead_time_trading_days"])


def test_pivot_orders_sectors_by_descending_mean_lead_time():
    long_table = _long_table([
        ("Financials", "2008 GFC", 25),
        ("Financials", "2020 COVID", 25),
        ("Utilities", "2008 GFC", 2),
        ("Utilities", "2020 COVID", 2),
        ("Materials", "2008 GFC", 10),
        ("Materials", "2020 COVID", 10),
    ])
    pivot = pivot_leadership_heatmap(
        long_table, crash_names=["2008 GFC", "2020 COVID"]
    )
    # Best (most warning) sector first.
    assert list(pivot.index) == ["Financials", "Materials", "Utilities"]


def test_pivot_handles_missing_alarms_as_nan_not_dropped():
    long_table = _long_table([
        ("Financials", "2008 GFC", 25),
        ("Financials", "2020 COVID", None),  # no alarm found for this crisis
        ("Utilities", "2008 GFC", None),
        ("Utilities", "2020 COVID", None),
    ])
    pivot = pivot_leadership_heatmap(
        long_table, crash_names=["2008 GFC", "2020 COVID"]
    )
    # Both sectors must still appear (not silently dropped for missing data).
    assert set(pivot.index) == {"Financials", "Utilities"}
    assert np.isnan(pivot.loc["Financials", "2020 COVID"])
    assert pivot.loc["Financials", "2008 GFC"] == 25


def test_pivot_column_order_matches_requested_crash_names_even_if_unsorted_input():
    long_table = _long_table([
        ("Financials", "2020 COVID", 5),
        ("Financials", "2000 dot-com", 30),
        ("Financials", "2008 GFC", 15),
    ])
    pivot = pivot_leadership_heatmap(
        long_table, crash_names=["2000 dot-com", "2008 GFC", "2020 COVID"]
    )
    assert list(pivot.columns) == ["2000 dot-com", "2008 GFC", "2020 COVID"]
    assert pivot.loc["Financials", "2000 dot-com"] == 30


# ---------------- real-data-takes-precedence-over-synthetic ----------------
# This fallback pattern (real handover file first, synthetic placeholder only
# if it's missing) is the backbone of every week's data loading, but was never
# directly tested anywhere in the project before now.

def test_cross_asset_loader_prefers_real_topology_csv_over_synthetic(tmp_path):
    real_csv = tmp_path / "topology_features.csv"
    idx = pd.date_range("2020-01-01", periods=6, freq="D")
    pd.DataFrame({"real_marker_col": range(6)}, index=idx).to_csv(real_csv)

    f1, f2, provenance = load_asset_class_features(
        "credit",
        topology_csv_path=real_csv,
        betti_npz_path=tmp_path / "does_not_exist.npz",
        real_returns=None,
    )

    assert provenance["f1"].startswith("real:")
    assert "real_marker_col" in f1.columns
    assert "synthetic" not in provenance["f1"]


def test_cross_asset_loader_falls_back_to_synthetic_when_no_real_file():
    f1, f2, provenance = load_asset_class_features(
        "credit",
        topology_csv_path="/nonexistent/topology_features.csv",
        betti_npz_path="/nonexistent/betti_curves.npz",
        real_returns=None,
    )
    assert "synthetic" in provenance["f1"]
    assert not f1.empty


def test_sector_loader_prefers_real_topology_csv_over_synthetic(monkeypatch, tmp_path):
    real_csv = tmp_path / "sector_topology.csv"
    idx = pd.date_range("2020-01-01", periods=6, freq="D")
    pd.DataFrame({"real_sector_marker": range(6)}, index=idx).to_csv(real_csv)

    import ml.ml_config as ml_config
    monkeypatch.setattr(ml_config, "sector_topology_file", lambda name: real_csv)
    monkeypatch.setattr(ml_config, "sector_betti_file", lambda name: tmp_path / "missing.npz")

    f1, source = load_sector_f1_features("Financials")
    assert source.startswith("real:")
    assert "real_sector_marker" in f1.columns


def test_sector_leadership_bias_dict_covers_every_gics_sector():
    from ml.ml_config import GICS_SECTORS
    assert set(SECTOR_LEAD_BIAS_DAYS.keys()) == set(GICS_SECTORS)


# ---------------- dtype-consistency regression ----------------
# compute_lead_times results get concatenated across many sectors (see
# ml.sector_leadership.build_sector_leadership_table). A per-crisis result
# that happens to be all "no alarm found" has no numeric value to force
# promotion to float64, and used to leave the column as object dtype --
# fine in isolation, but fragile once concatenated with float64 results from
# other sectors (silently degrades the WHOLE stacked column to object,
# making downstream .mean()/.astype(float) calls rely on lucky coercion
# rather than a guaranteed numeric dtype).

def test_compute_lead_times_is_float_dtype_even_when_no_alarms_found():
    empty_ish = pd.Series([0.01, 0.02], index=pd.date_range("2020-01-01", periods=2, freq="D"))
    result = compute_lead_times(
        empty_ish, threshold=0.99,
        reference_crashes=[("Crisis A", "2020-03-01", "2020-04-01")],
    )
    assert result["lead_time_trading_days"].dtype == np.float64
    assert result["max_proba_in_window"].dtype == np.float64


def test_compute_lead_times_dtype_is_consistent_across_calls_before_concat():
    # Call 1: no alarm at all (would be object dtype without the fix).
    low = pd.Series([0.01, 0.02], index=pd.date_range("2020-01-01", periods=2, freq="D"))
    result_no_alarm = compute_lead_times(
        low, threshold=0.99,
        reference_crashes=[("Crisis A", "2020-03-01", "2020-04-01")],
    )
    # Call 2: alarm found (numeric value present).
    high = pd.Series([0.9, 0.9], index=pd.date_range("2020-01-01", periods=2, freq="D"))
    result_alarm = compute_lead_times(
        high, threshold=0.5,
        reference_crashes=[("Crisis A", "2020-03-01", "2020-04-01")],
    )

    assert result_no_alarm["lead_time_trading_days"].dtype == np.float64
    # (The alarm-found call may legitimately stay int64 if every row got a
    # value -- pd.to_numeric only promotes to float when NaN is present.
    # That's fine: int64 + float64 concatenates to float64 below. The bug this
    # test guards against is int64/float64 + OBJECT concatenating to object.)

    stacked = pd.concat([result_no_alarm, result_alarm], ignore_index=True)
    # The whole point of the fix: concatenating an all-NaN result with a
    # numeric result must NOT degrade to object dtype.
    assert stacked["lead_time_trading_days"].dtype == np.float64
    # And .mean() must work directly, without needing a manual coercion step.
    assert not np.isnan(stacked["lead_time_trading_days"].mean())
