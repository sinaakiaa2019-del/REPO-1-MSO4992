"""
F2 standard (non-topological) feature set (Sina Kia).

The plan's F2 baseline is:
    - VIX level
    - eigenvalue gap of the correlation matrix (lambda_1 / sum_lambdas)
    - 20-day realised volatility
    - T10Y2Y yield-curve slope

F2 is the benchmark every topological model must beat.

Data sources, in priority order:
  1. macro_features.csv (handed over by Octavian in Week 3) if present. Expected
     columns include VIX, eigenvalue_gap, realised_vol_20d, T10Y2Y, credit_spread.
  2. baseline_features.csv (already produced by data_processing.py) as a fallback
     for the correlation-derived features (eigenvalue gap, realised vol).
  3. market_indicators.csv (Octavian's raw Yahoo Finance pull of SPY/^VIX/^TNX/
     LQD/HYG) as a fallback for VIX and the yield proxy specifically.

The builder is defensive: it maps several plausible column names onto the four
canonical F2 features and reports which ones were actually found, so the
benchmark is honest about what went into it.
"""

import numpy as np
import pandas as pd


# Canonical F2 feature names and the alternative column names we accept for each.
#
# The "eigenvalue_gap" / "vix" / "yield_curve_slope" entries originally only
# listed the names used by the planned macro_features.csv handover and by the
# synthetic-data fallback. Octavian's actual pipeline output uses different
# names (largest_eigenvalue_ratio_60d, vix_close, ten_year_yield_proxy) which
# were not recognised, so F2 silently collapsed to a single feature
# (realised_vol_20d) whenever it was built from real pipeline output instead
# of the synthetic stand-in. All real, planned, and synthetic spellings are
# now listed so this cannot happen silently again.
F2_COLUMN_ALIASES = {
    "vix": ["vix", "VIX", "VIXCLS", "vix_level", "vix_close"],
    "eigenvalue_gap": [
        "eigenvalue_gap", "lambda1_ratio", "eig_gap",
        "largest_eigenvalue_ratio_60d",
    ],
    "realised_vol_20d": ["realised_vol_20d", "realised_vol_60d", "realized_vol_20d",
                          "realised_vol", "vol_20d"],
    "yield_curve_slope": [
        "T10Y2Y", "t10y2y", "yield_curve_slope", "term_spread",
        "ten_year_yield_proxy",
    ],
}

# Some accepted aliases are NOT the same quantity as the canonical feature and
# are only there so the pipeline runs end-to-end before the real series is
# wired in. Flag these explicitly wherever they are used, instead of letting
# them masquerade as the real thing.
F2_PROXY_CAVEATS = {
    "ten_year_yield_proxy": (
        "this is the raw 10-year Treasury YIELD LEVEL (^TNX), not the "
        "T10Y2Y (10y minus 2y) SLOPE the plan specifies. It is a placeholder, "
        "not the real feature -- pull T10Y2Y from FRED before reporting results."
    ),
}


def _first_present(df, candidates):
    """Return the first candidate column that exists in df, else None."""
    for name in candidates:
        if name in df.columns:
            return name
    return None


def build_f2_features(macro_df=None, baseline_df=None, indicators_df=None):
    """
    Build the F2 feature matrix from whatever standard sources are available.

    Parameters
    ----------
    macro_df : pd.DataFrame or None
        Macro feature frame (date index) from Octavian, if available.
    baseline_df : pd.DataFrame or None
        Octavian's baseline_features.csv (date index), used as a fallback for
        correlation-derived features.
    indicators_df : pd.DataFrame or None
        Octavian's market_indicators.csv (date index: vix_close,
        ten_year_yield_proxy, spy_close, ...), used as a fallback for VIX and
        the yield proxy specifically.

    Returns
    -------
    (features, provenance)
        features : pd.DataFrame, date index, canonical F2 columns (those found).
        provenance : dict mapping canonical name -> (source_name, column_used).
    """
    sources = []
    if macro_df is not None:
        sources.append(("macro", macro_df))
    if baseline_df is not None:
        sources.append(("baseline", baseline_df))
    if indicators_df is not None:
        sources.append(("market_indicators", indicators_df))

    if not sources:
        raise ValueError("No feature source supplied for F2 (need macro, baseline, or indicators).")

    collected = {}
    provenance = {}

    for canonical, aliases in F2_COLUMN_ALIASES.items():
        for source_name, df in sources:
            col = _first_present(df, aliases)
            if col is not None:
                collected[canonical] = df[col]
                provenance[canonical] = (source_name, col)
                break  # prefer the higher-priority source

    if not collected:
        raise ValueError("None of the expected F2 columns were found in the sources.")

    features = pd.DataFrame(collected)
    features.index = pd.to_datetime(features.index)
    features = features.sort_index()
    return features, provenance


def summarise_f2(features, provenance):
    """Return a short text summary of which F2 features were assembled and from where."""
    lines = ["F2 standard feature set assembled:"]
    for canonical in F2_COLUMN_ALIASES:
        if canonical in features.columns:
            source, col = provenance[canonical]
            lines.append(f"  - {canonical}: from {source} column '{col}'")
            if col in F2_PROXY_CAVEATS:
                lines.append(f"      CAVEAT: {F2_PROXY_CAVEATS[col]}")
        else:
            lines.append(f"  - {canonical}: MISSING (not available in any source)")
    lines.append(f"  Rows: {len(features)}  Columns: {list(features.columns)}")
    return "\n".join(lines)
