"""
Model persistence (Sina Kia) — Week 8.

The live dashboard tab needs a trained model available WITHOUT retraining on
every page load (Streamlit reruns the whole script on every interaction).
This module saves/loads a fitted XGBoost model plus the metadata needed to
use it correctly later: the exact feature column order it was trained on
(XGBoost does not itself validate this) and when it was trained.
"""

import json
from datetime import datetime, timezone
from pathlib import Path

import joblib


def save_model(model, feature_columns, output_path, extra_metadata=None):
    """
    Save a fitted model plus a metadata sidecar (JSON, same basename) with the
    feature column order and a timestamp. Returns (model_path, metadata_path).
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, output_path)

    metadata = {
        "feature_columns": list(feature_columns),
        "trained_at_utc": datetime.now(timezone.utc).isoformat(),
        "n_features": len(feature_columns),
    }
    if extra_metadata:
        metadata.update(extra_metadata)

    metadata_path = output_path.with_suffix(".meta.json")
    metadata_path.write_text(json.dumps(metadata, indent=2))
    return output_path, metadata_path


def load_model(model_path):
    """
    Load a model saved by save_model, plus its metadata.

    Returns (model, metadata_dict). Raises FileNotFoundError with a clear
    message if either the model or its metadata sidecar is missing.
    """
    model_path = Path(model_path)
    metadata_path = model_path.with_suffix(".meta.json")

    if not model_path.exists():
        raise FileNotFoundError(
            f"No saved model at {model_path} -- run run_ml_week8.py first."
        )
    if not metadata_path.exists():
        raise FileNotFoundError(
            f"Model file exists at {model_path} but its metadata sidecar "
            f"{metadata_path} is missing -- cannot verify feature column order. "
            "Re-run run_ml_week8.py to regenerate both together."
        )

    model = joblib.load(model_path)
    metadata = json.loads(metadata_path.read_text())
    return model, metadata


def score_with_saved_model(model, metadata, feature_row):
    """
    Score a single feature row (dict or 1-row DataFrame) with a loaded model,
    enforcing the SAME column order it was trained on.

    Raises ValueError if feature_row is missing any expected column -- a
    silently-reordered or partially-missing row would produce a confident-
    looking but meaningless prediction.
    """
    import pandas as pd

    if isinstance(feature_row, dict):
        feature_row = pd.DataFrame([feature_row])

    expected = metadata["feature_columns"]
    missing = [c for c in expected if c not in feature_row.columns]
    if missing:
        raise ValueError(
            f"feature_row is missing columns the model was trained on: {missing}"
        )

    ordered = feature_row[expected]
    proba = model.predict_proba(ordered.values)[:, 1]
    return float(proba[0]) if len(proba) == 1 else proba
