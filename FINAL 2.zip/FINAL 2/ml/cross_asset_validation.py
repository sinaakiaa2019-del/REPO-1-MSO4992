"""
Cross-asset generalisation (Sina Kia) — Week 5, RQ4.

Question: does the topology signal generalise beyond the equity universe? This
module builds the SAME F1 (topology-only) / F2 (standard) / F3 (combined)
feature-set comparison used in Weeks 2-4, but for credit and international
instruments, and reports one master AUROC table across all three asset
classes so they can be compared directly.

Crash labels are the SAME index-based labels used throughout the project (a
"crash" is a global market event, not asset-class-specific) — the question
this module answers is whether each asset class's OWN correlation-network
topology can predict that same global event, not whether each asset class has
its own separate crash definition.

Data sourcing, per asset class, in priority order:
  1. Real topology handover from Kunal (topology_features.csv / betti_curves.npz
     under data/processed/credit/ or data/processed/international/).
  2. Real returns for that asset class if present, with topology falling back
     to a synthetic Betti curve built from those real returns.
  3. Fully synthetic returns + topology (asset class not yet wired in at all).

Every fallback is reported in the returned provenance dict so this cannot be
mistaken for a real cross-asset result before Octavian/Kunal hand the data
over.
"""

from pathlib import Path

import pandas as pd

from ml.f1_topology_features import build_f1_from_betti_array, load_f1_features
from ml.f3_combined_features import build_f1_f2_f3
from ml.models import compare_feature_sets
from ml import synthetic_data


def load_asset_class_features(
    asset_name,
    topology_csv_path,
    betti_npz_path,
    real_returns=None,
    synthetic_seed=23,
    synthetic_betti_seed=29,
    synthetic_macro_seed=31,
):
    """
    Load (or synthesise) the F1 and F2 feature sets for one non-equity asset
    class, following the same real-first / synthetic-fallback pattern as the
    equity Week 1-3 pipeline.

    Returns
    -------
    (f1_features, f2_features, provenance) where provenance is a dict
    describing which source was used for each piece (for honest reporting).
    """
    provenance = {}

    # ---- F1: topology ----
    try:
        f1_features, source = load_f1_features(
            topology_csv_path=topology_csv_path, betti_npz_path=betti_npz_path,
        )
        provenance["f1"] = f"real: {source}"
    except FileNotFoundError:
        if real_returns is not None:
            print(f"  [{asset_name}] no topology handover -> synthetic Betti "
                  f"curve built from REAL {asset_name} returns")
            betti_array, dates = synthetic_data.make_synthetic_asset_class_betti(
                real_returns, seed=synthetic_betti_seed,
            )
            f1_features = build_f1_from_betti_array(betti_array, dates)
            provenance["f1"] = f"synthetic Betti curve over real {asset_name} returns"
        else:
            print(f"  [{asset_name}] no real returns or topology found -> "
                  f"fully synthetic {asset_name} data")
            fallback_returns = synthetic_data.make_synthetic_asset_class_returns(
                seed=synthetic_seed,
            )
            betti_array, dates = synthetic_data.make_synthetic_asset_class_betti(
                fallback_returns, seed=synthetic_betti_seed,
            )
            f1_features = build_f1_from_betti_array(betti_array, dates)
            provenance["f1"] = f"fully synthetic {asset_name} returns + Betti curve"

    # ---- F2: asset-class macro/vol proxy ----
    # F2's synthetic generator needs SOME returns series to derive realised
    # vol from, independent of which branch F1 took above. Real topology being
    # present (F1 branch) does not imply real_returns was supplied -- e.g.
    # run_ml_week5.py never passes real_returns for credit/international today
    # -- so this must not assume `returns` was set by the F1 branch (it used
    # to, and crashed with AttributeError whenever F1 loaded a real CSV but
    # real_returns was None).
    f2_source_returns = real_returns
    if f2_source_returns is None:
        f2_source_returns = synthetic_data.make_synthetic_asset_class_returns(
            seed=synthetic_seed,
        )
    f2_features = synthetic_data.make_synthetic_asset_class_macro(
        f2_source_returns, seed=synthetic_macro_seed,
    )
    provenance["f2"] = (
        f"synthetic {asset_name} realised-vol/spread-level proxy "
        "(real macro handover not yet wired in for this asset class)"
    )

    return f1_features, f2_features, provenance


def evaluate_asset_class(asset_name, f1_features, f2_features, crash_labels):
    """
    Run the F1 vs F2 vs F3 comparison for one asset class against the shared
    (equity-derived) crash labels, and tag every row with the asset class.

    Returns pd.DataFrame with an extra 'asset_class' column.
    """
    aligned, y = build_f1_f2_f3(f1_features, f2_features, crash_labels)
    print(f"  [{asset_name}] common rows: {len(y)}  "
          f"(F1={aligned['F1'].shape[1]}f, F2={aligned['F2'].shape[1]}f, "
          f"F3={aligned['F3'].shape[1]}f)")
    table = compare_feature_sets(aligned, y)
    table.insert(0, "asset_class", asset_name)
    return table


def build_cross_asset_auroc_table(*asset_tables):
    """Stack per-asset-class comparison tables into one master table."""
    return pd.concat(asset_tables, ignore_index=True)
