"""
Leave-one-crisis-out (LOCO) evaluation (Sina Kia) -- addresses the effective
sample-size problem.

Why this exists
---------------
The project's ~1,000 rolling windows are NOT ~1,000 independent observations:
adjacent 60-day windows stepped by 5 days share ~92% of their data, and the
positive label only fires around a handful of historical crises (in the
2004-2026 sample, effectively two: 2008 and 2020). Standard 5-fold
expanding-window CV keeps producing folds with zero crashes in the test block,
so a "mean AUROC over 5 folds" is really an average over 2 scored folds -- a
fragile number.

Leave-one-crisis-out is the honest alternative: TRAIN on all data except one
crisis episode and everything within a buffer around it, TEST specifically on
the held-out crisis window (plus a calm control span). Repeat, holding out each
crisis in turn. This directly answers "does the signal generalise to a crisis
the model never saw?" -- the question that actually matters -- instead of
rewarding a model for interpolating between adjacent, near-duplicate windows.

This is reported ALONGSIDE the expanding-window CV, not instead of it, and is
the number the paper should lead with.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score
from xgboost import XGBClassifier

from ml.ml_config import REFERENCE_CRASHES, XGB_BASE_PARAMS


def _crisis_windows(reference_crashes, buffer_days=60):
    """Return list of (name, test_start, test_end, embargo_start, embargo_end)."""
    out = []
    for name, start, end in reference_crashes:
        s, e = pd.Timestamp(start), pd.Timestamp(end)
        embargo_start = s - pd.tseries.offsets.BDay(buffer_days)
        embargo_end = e + pd.tseries.offsets.BDay(buffer_days)
        out.append((name, s, e, embargo_start, embargo_end))
    return out


def leave_one_crisis_out(X, y, reference_crashes=REFERENCE_CRASHES,
                         params=None, buffer_days=60, test_lookback_days=180):
    """
    Evaluate the model with each reference crisis held out in turn.

    For crisis c:
      - TEST rows  = rows whose date is in [onset - test_lookback_days, end_c].
      - TRAIN rows = all rows OUTSIDE an embargo of `buffer_days` around crisis
                     c (so no near-duplicate window of the held-out crisis leaks
                     into training), AND strictly before the test span OR after
                     the embargo -- other crises stay in training, which is the
                     point (learn from 2008, predict 2020).

    Parameters
    ----------
    X : pd.DataFrame, date-indexed.
    y : pd.Series 0/1, aligned to X.
    reference_crashes : list of (name, start, end).

    Returns
    -------
    pd.DataFrame, one row per crisis with test AUROC / PR-AUC and counts, plus
    attrs['mean_auroc'] over crises that had both classes in their test span.
    """
    if params is None:
        params = XGB_BASE_PARAMS

    X = X.copy()
    X.index = pd.to_datetime(X.index)
    y = pd.Series(np.asarray(y).astype(int), index=X.index)

    rows = []
    for name, s, e, emb_s, emb_e in _crisis_windows(reference_crashes, buffer_days):
        test_start = s - pd.tseries.offsets.BDay(test_lookback_days)
        test_mask = (X.index >= test_start) & (X.index <= e)
        # Train = everything not in the embargo around this crisis.
        embargo_mask = (X.index >= emb_s) & (X.index <= emb_e)
        train_mask = ~embargo_mask

        X_train, y_train = X[train_mask], y[train_mask]
        X_test, y_test = X[test_mask], y[test_mask]

        n_test_pos = int(y_test.sum())
        if len(X_test) == 0 or len(np.unique(y_test)) < 2 or y_train.sum() == 0:
            rows.append({
                "crisis": name, "n_train": int(len(X_train)),
                "n_test": int(len(X_test)), "n_test_positive": n_test_pos,
                "auroc": np.nan, "pr_auc": np.nan,
                "note": "test span single-class or no training positives",
            })
            continue

        n_pos = int(y_train.sum())
        n_neg = int(len(y_train) - n_pos)
        model_params = dict(params)
        model_params["scale_pos_weight"] = (n_neg / n_pos) if n_pos > 0 else 1.0
        model = XGBClassifier(**model_params)
        model.fit(X_train.values, y_train.values)
        proba = model.predict_proba(X_test.values)[:, 1]

        rows.append({
            "crisis": name, "n_train": int(len(X_train)),
            "n_test": int(len(X_test)), "n_test_positive": n_test_pos,
            "auroc": float(roc_auc_score(y_test, proba)),
            "pr_auc": float(average_precision_score(y_test, proba)),
            "note": "",
        })

    table = pd.DataFrame(rows)
    scored = table["auroc"].dropna()
    table.attrs["mean_auroc"] = float(scored.mean()) if len(scored) else np.nan
    table.attrs["n_crises_scored"] = int(len(scored))
    return table
