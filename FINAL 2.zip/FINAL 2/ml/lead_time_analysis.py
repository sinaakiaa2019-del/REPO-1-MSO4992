"""
Lead-time analysis (Sina Kia) — Week 4 (first cut), extended in Week 8.

RQ-relevant question: when the model's predicted crash probability first rises
above a threshold, how many trading days of warning does that give before the
crash actually starts? This is only meaningful computed OUT-OF-SAMPLE — using
in-sample (training) probabilities would let the model "predict" a crash it was
fit on, which is not a lead time, it's memorisation.

This module therefore:
  1. Re-runs the expanding-window CV, but instead of just scoring AUROC, it
     stitches together the TEST-FOLD predicted probabilities only, indexed by
     date. A date that never fell in a test fold (the initial training block)
     has no out-of-sample prediction and is left out.
  2. For each reference crash window, finds the first out-of-sample date within
     a lookback horizon before the crash "turns on" whose predicted probability
     crosses the alarm threshold, and reports the lead time in trading days.
"""

import numpy as np
import pandas as pd
from xgboost import XGBClassifier

from ml.cross_validation import ExpandingWindowSplit, check_no_leakage
from ml.ml_config import (
    INITIAL_TRAIN_FRACTION,
    N_CV_FOLDS,
    PURGE_GAP,
    REFERENCE_CRASHES,
    XGB_BASE_PARAMS,
)


def out_of_sample_probabilities(X, y, params=None, splitter=None):
    """
    Stitch together test-fold predicted probabilities from expanding-window CV.

    Every prediction used here comes from a model that was trained ONLY on data
    strictly before (and outside the purge gap of) the date being predicted, so
    the resulting series is a valid out-of-sample probability track — safe to
    use for lead-time analysis, calibration curves, or a live dashboard.

    Parameters
    ----------
    X : pd.DataFrame, date-indexed, aligned to y.
    y : pd.Series of 0/1 labels, same index as X.

    Returns
    -------
    pd.Series of predicted P(crash), indexed by date, covering only the dates
    that fell inside a test fold (i.e. NOT the initial training block).
    """
    if params is None:
        params = XGB_BASE_PARAMS
    if splitter is None:
        splitter = ExpandingWindowSplit(
            n_splits=N_CV_FOLDS,
            initial_train_fraction=INITIAL_TRAIN_FRACTION,
            purge_gap=PURGE_GAP,
        )

    X_values = X.values
    y_values = np.asarray(y).astype(int)
    dates = X.index

    proba_by_date = {}
    for train_idx, test_idx in splitter.split(len(X_values)):
        check_no_leakage(train_idx, test_idx)

        X_train, y_train = X_values[train_idx], y_values[train_idx]
        X_test = X_values[test_idx]

        n_pos = int(y_train.sum())
        n_neg = int(len(y_train) - n_pos)
        scale_pos_weight = (n_neg / n_pos) if n_pos > 0 else 1.0

        model_params = dict(params)
        model_params["scale_pos_weight"] = scale_pos_weight
        model = XGBClassifier(**model_params)
        model.fit(X_train, y_train)
        proba = model.predict_proba(X_test)[:, 1]

        for i, pos in enumerate(test_idx):
            proba_by_date[dates[pos]] = proba[i]

    series = pd.Series(proba_by_date, name="oos_proba").sort_index()
    return series


def compute_lead_times(
    proba_series,
    threshold=0.5,
    reference_crashes=REFERENCE_CRASHES,
    lookback_days=120,
):
    """
    For each reference crisis, find the first out-of-sample alarm before onset.

    IMPORTANT — units: proba_series is built from feature matrices sampled on
    the rolling-window STEP_SIZE grid (every ~5 trading days, see config.py),
    not one row per trading day. Counting rows as if they were trading days
    would understate the true lead time by roughly a factor of STEP_SIZE and
    would silently widen "lookback_days" from a 120-trading-day window into a
    multi-year one. To avoid that, this function does the lookback filter and
    the lead-time count using real calendar dates (np.busday_count for trading
    days between two actual dates), not row positions.

    "Onset" is taken as the crisis window's start date. We look backward up to
    `lookback_days` TRADING days before onset for the first out-of-sample date
    whose probability >= threshold, then report the actual number of trading
    days between that alarm and onset.

    Returns
    -------
    pd.DataFrame, one row per crisis, with columns:
        crisis, onset, alarm_date, lead_time_trading_days, threshold,
        max_proba_in_window, alarm_found, n_oos_obs_in_window
    """
    rows = []
    has_datetime_index = isinstance(proba_series.index, pd.DatetimeIndex)
    for name, start, end in reference_crashes:
        onset = pd.Timestamp(start)
        window_start = onset - pd.tseries.offsets.BDay(lookback_days)

        if not has_datetime_index or proba_series.empty:
            window = proba_series.iloc[0:0]
        else:
            window = proba_series.loc[
                (proba_series.index < onset) & (proba_series.index >= window_start)
            ]

        alarms = window[window >= threshold]
        if len(alarms) == 0:
            rows.append({
                "crisis": name,
                "onset": onset.date().isoformat(),
                "alarm_date": None,
                "lead_time_trading_days": None,
                "threshold": threshold,
                "max_proba_in_window": float(window.max()) if len(window) else None,
                "alarm_found": False,
                "n_oos_obs_in_window": int(len(window)),
            })
            continue

        first_alarm_date = alarms.index.min()
        lead_time_trading_days = int(np.busday_count(
            first_alarm_date.date(), onset.date()
        ))
        rows.append({
            "crisis": name,
            "onset": onset.date().isoformat(),
            "alarm_date": first_alarm_date.date().isoformat(),
            "lead_time_trading_days": lead_time_trading_days,
            "threshold": threshold,
            "max_proba_in_window": float(window.max()),
            "alarm_found": True,
            "n_oos_obs_in_window": int(len(window)),
        })

    result = pd.DataFrame(rows)
    # Force numeric dtype explicitly. Without this, a crisis where every row in
    # THIS call happens to be "no alarm found" (all None, no numeric value to
    # force promotion) produces an object-dtype column, while a call with a
    # mix of None and a real number produces float64. Concatenating many such
    # results (see ml.sector_leadership, which stacks 11 sectors x 3 crises)
    # then silently degrades the whole column to object dtype, which makes
    # later numeric ops (.mean() for sorting, .astype(float) for plotting)
    # fragile -- they happen to work via pandas' object-dtype coercion today,
    # but that is not guaranteed. Casting here makes every caller's output
    # float64 with a real NaN, regardless of which rows happened to alarm.
    for col in ("lead_time_trading_days", "max_proba_in_window"):
        result[col] = pd.to_numeric(result[col], errors="coerce")
    return result
