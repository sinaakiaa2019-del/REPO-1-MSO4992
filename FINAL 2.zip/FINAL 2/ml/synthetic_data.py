"""
Synthetic stand-in data generator (Sina Kia).

This is NOT part of the scientific pipeline. It exists so the ML modules can be
run and tested end-to-end before Octavian's real returns/matrices and Kunal's
real Betti curves are handed over. Every function here is clearly labelled and is
only invoked when the corresponding real artefact is missing.

The synthetic series deliberately embeds three "stress" regimes positioned around
2000, 2008 and 2020 so that the crash-label verification has something to fire on,
and so F1 (topology) and F2 (standard) features carry a real (if synthetic) signal.
"""

import numpy as np
import pandas as pd


def make_synthetic_index(start="1998-01-01", end="2023-12-31", seed=42):
    """Generate a synthetic daily index level with three stress regimes."""
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range(start=start, end=end)
    n = len(dates)

    drift = 0.0003
    vol = np.full(n, 0.008)

    # Inject elevated-vol, negative-drift stress windows near the three crises.
    stress_windows = [("2000-03-01", "2001-04-30"),
                      ("2008-09-01", "2009-03-31"),
                      ("2020-02-15", "2020-04-15")]
    drift_arr = np.full(n, drift)
    for s, e in stress_windows:
        mask = (dates >= s) & (dates <= e)
        vol[mask] = 0.03
        drift_arr[mask] = -0.004

    daily_returns = rng.normal(drift_arr, vol)
    level = 100 * np.exp(np.cumsum(daily_returns))
    return pd.Series(level, index=dates, name="index_level")


def make_synthetic_returns(n_assets=30, start="1998-01-01", end="2023-12-31", seed=7):
    """
    Generate a synthetic returns matrix whose cross-asset correlation RISES during
    the stress windows (the 'everything correlates to 1' effect). This gives the
    eigenvalue-gap feature and the topology features a genuine signal to learn.
    """
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range(start=start, end=end)
    n = len(dates)

    base_corr = 0.2
    corr_path = np.full(n, base_corr)
    for s, e in [("2000-03-01", "2001-04-30"),
                 ("2008-09-01", "2009-03-31"),
                 ("2020-02-15", "2020-04-15")]:
        mask = (dates >= s) & (dates <= e)
        corr_path[mask] = 0.8

    market = rng.normal(0, 1, n)
    returns = np.zeros((n, n_assets))
    for a in range(n_assets):
        idio = rng.normal(0, 1, n)
        rho = corr_path
        returns[:, a] = np.sqrt(rho) * market + np.sqrt(1 - rho) * idio
    returns *= 0.01

    cols = [f"SYN{a:02d}" for a in range(n_assets)]
    return pd.DataFrame(returns, index=dates, columns=cols)


def make_synthetic_macro(returns, seed=11):
    """
    Build a synthetic macro/F2 feature frame aligned to a 5-day step grid, so it
    looks like Octavian's macro_features.csv. Features carry the stress signal.
    """
    rng = np.random.default_rng(seed)
    step_dates = returns.index[::5]
    rows = []
    for d in step_dates:
        window = returns.loc[:d].tail(60)
        if len(window) < 60:
            continue
        corr = window.corr().values
        eig = np.sort(np.linalg.eigvalsh(corr))[::-1]
        eig_gap_ratio = eig[0] / eig.sum()
        realised_vol = window.mean(axis=1).std() * np.sqrt(252)
        # Synthetic VIX rises with realised vol; synthetic yield slope wiggles.
        vix = 12 + realised_vol * 300 + rng.normal(0, 1)
        t10y2y = rng.normal(1.0, 0.4)
        credit_spread = 1.5 + realised_vol * 50 + rng.normal(0, 0.1)
        rows.append({
            "date": d,
            "VIX": vix,
            "eigenvalue_gap": eig_gap_ratio,
            "realised_vol_20d": realised_vol,
            "T10Y2Y": t10y2y,
            "credit_spread": credit_spread,
        })
    return pd.DataFrame(rows).set_index("date")


def make_synthetic_betti(returns, n_epsilon=50, seed=13):
    """
    Build a synthetic Betti curve array aligned to the 5-day step grid, shaped
    (n_windows, n_epsilon, 2). The H1 curve's mass is modulated by the realised
    correlation so topology features carry a learnable crash signal.
    Returns (betti_array, dates).
    """
    rng = np.random.default_rng(seed)
    step_dates = returns.index[::5]
    eps_grid = np.linspace(0, np.sqrt(2), n_epsilon)

    betti = []
    dates = []
    for d in step_dates:
        window = returns.loc[:d].tail(60)
        if len(window) < 60:
            continue
        corr = window.corr().values
        avg_corr = corr[np.triu_indices_from(corr, k=1)].mean()

        # H0: starts near n_assets, decays to 1 across filtration.
        n_assets = returns.shape[1]
        h0 = n_assets * np.exp(-3 * eps_grid) + 1
        # H1: a bump in mid-filtration whose height shrinks as correlation rises
        # (tighter clustering => fewer persistent loops). Adds crash signal.
        centre = 0.7
        height = max(0.5, 6 * (1 - avg_corr))
        h1 = height * np.exp(-((eps_grid - centre) ** 2) / 0.05)
        h1 += rng.normal(0, 0.05, n_epsilon).clip(min=0)

        betti.append(np.stack([h0, h1], axis=1))
        dates.append(d)

    return np.array(betti), np.array([str(d.date()) for d in dates])


# ============================================================
# WEEK 5: cross-asset (credit / international) synthetic stand-ins
# ============================================================

_STRESS_WINDOWS = [
    ("2000-03-01", "2001-04-30"),
    ("2008-09-01", "2009-03-31"),
    ("2020-02-15", "2020-04-15"),
]


def make_synthetic_asset_class_returns(
    n_assets=10, start="1998-01-01", end="2023-12-31", seed=23,
    stress_corr=0.7, base_corr=0.15,
):
    """
    Generic synthetic returns generator for a non-equity asset class (credit
    instruments, international indices, ...). Same 'correlation rises in
    stress' construction as make_synthetic_returns, but with its own seed and
    a lower base correlation (credit/international baskets are usually less
    tightly coupled to each other day-to-day than a single-country equity
    universe), so cross-asset AUROC is not just re-deriving the same numbers.
    """
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range(start=start, end=end)
    n = len(dates)

    corr_path = np.full(n, base_corr)
    for s, e in _STRESS_WINDOWS:
        mask = (dates >= s) & (dates <= e)
        corr_path[mask] = stress_corr

    market = rng.normal(0, 1, n)
    returns = np.zeros((n, n_assets))
    for a in range(n_assets):
        idio = rng.normal(0, 1, n)
        rho = corr_path
        returns[:, a] = np.sqrt(rho) * market + np.sqrt(1 - rho) * idio
    returns *= 0.008

    cols = [f"ASSET{a:02d}" for a in range(n_assets)]
    return pd.DataFrame(returns, index=dates, columns=cols)


def make_synthetic_asset_class_betti(returns, n_epsilon=50, seed=29, lead_bias_days=0):
    """
    Same construction as make_synthetic_betti, but the H1 signal can be shifted
    earlier by lead_bias_days trading days relative to the stress window (used
    to give different sectors a different, testable "leadership" lag for the
    Week 5 sector leadership heatmap). lead_bias_days=0 reproduces the same
    concurrent-signal behaviour as the equity generator.
    """
    rng = np.random.default_rng(seed)
    step_dates = returns.index[::5]
    eps_grid = np.linspace(0, np.sqrt(2), n_epsilon)

    shifted_windows = []
    for s, e in _STRESS_WINDOWS:
        shifted_windows.append((
            pd.Timestamp(s) - pd.tseries.offsets.BDay(lead_bias_days),
            pd.Timestamp(e),
        ))

    betti, dates = [], []
    for d in step_dates:
        window = returns.loc[:d].tail(60)
        if len(window) < 60:
            continue
        in_stress = any(s <= d <= e for s, e in shifted_windows)
        avg_corr = 0.75 if in_stress else 0.2

        n_assets = returns.shape[1]
        h0 = n_assets * np.exp(-3 * eps_grid) + 1
        centre = 0.7
        height = max(0.5, 6 * (1 - avg_corr))
        h1 = height * np.exp(-((eps_grid - centre) ** 2) / 0.05)
        h1 += rng.normal(0, 0.05, n_epsilon).clip(min=0)

        betti.append(np.stack([h0, h1], axis=1))
        dates.append(d)

    return np.array(betti), np.array([str(d.date()) for d in dates])


def make_synthetic_asset_class_macro(returns, seed=31):
    """
    Minimal synthetic F2-style feature frame for a non-equity asset class:
    realised volatility of the equal-weighted basket, plus a level/vol pair
    modelled on a spread-like series (works as a stand-in for credit spread
    level + spread volatility, or an international index's own vol regime).
    """
    rng = np.random.default_rng(seed)
    step_dates = returns.index[::5]
    rows = []
    for d in step_dates:
        window = returns.loc[:d].tail(60)
        if len(window) < 60:
            continue
        realised_vol = window.mean(axis=1).std() * np.sqrt(252)
        level = 1.5 + realised_vol * 40 + rng.normal(0, 0.1)
        rows.append({
            "date": d,
            "realised_vol_20d": realised_vol,
            "spread_level": level,
        })
    return pd.DataFrame(rows).set_index("date")
