"""
Ablation study on F3 (Sina Kia) — Week 6.

Leave-one-feature-group-out ablation: for each named group of F3 columns,
drop that group and re-run the standard expanding-window CV, so we can see
which piece of F3 is actually carrying the predictive signal rather than just
reporting one aggregate AUROC. Also reports the two boundary cases (topology
only / standard only) so the ablation table sits alongside the plain F1-vs-F2
comparison from Week 3-4 as a consistency check -- "F3 minus every F2 group"
should score close to the F1-only row.

Which columns belong to F1 (topology) vs F2 (standard) is taken EXPLICITLY
from the caller (see run_ablation's f1_columns/f2_columns args), rather than
guessed from column-name patterns. This matters because Kunal's real
topology_features.csv handover is documented (see
ml/f1_topology_features.py) to eventually include a "Gidea & Katz L2-norm"
column and other diagram-level scalars whose exact names aren't fixed yet --
a name-pattern classifier would silently misfile an unrecognised topology
column into the "standard feature" bucket, which would quietly leak topology
information into the F2_only row and undermine the exact comparison this
table exists to make. Within F1, the curve-vs-scalar split IS still done by
pattern (h1_eps_###) since that split only affects which topology sub-group
is ablated, not which asset class a column belongs to.
"""

import numpy as np
import pandas as pd

from ml.models import cross_validated_auroc


def group_f1_columns(f1_columns):
    """
    Split F1's OWN columns (already known to be topology, not standard) into
    the flattened-curve group and the scalar-summary group.

    Returns dict {"f1_curve": [...], "f1_scalar": [...]}, empty groups omitted.
    """
    curve, scalar = [], []
    for col in f1_columns:
        if col.startswith("h1_eps_") or col.startswith("h0_eps_"):
            curve.append(col)
        else:
            scalar.append(col)
    groups = {}
    if curve:
        groups["f1_curve"] = curve
    if scalar:
        groups["f1_scalar"] = scalar
    return groups


def group_f3_columns(f3_columns, f1_columns, f2_columns):
    """
    Classify F3 columns into named ablation groups, using the EXPLICIT F1/F2
    membership passed in (see module docstring for why this must not be
    guessed from names).

    - "f1_curve"  : F1's flattened Betti curve dimensions (h1_eps_###, ...).
    - "f1_scalar" : F1's scalar summaries (persistence entropy, max
                    persistence, L2-norm, Wasserstein velocity -- whatever
                    Kunal's topology_features.csv actually contains; every
                    non-curve F1 column lands here, unconditionally).
    - one group per F2 column (each standard feature ablated individually).

    Any F3 column not accounted for by f1_columns/f2_columns raises, rather
    than silently falling into the wrong bucket.
    """
    f1_set, f2_set = set(f1_columns), set(f2_columns)
    unexplained = [c for c in f3_columns if c not in f1_set and c not in f2_set]
    if unexplained:
        raise ValueError(
            f"F3 columns not found in either f1_columns or f2_columns: {unexplained}. "
            "build_f3_features may have disambiguated a name collision (f1_*/f2_* "
            "prefix) -- pass the SAME f1_columns/f2_columns used to build F3."
        )

    groups = group_f1_columns([c for c in f3_columns if c in f1_set])
    for col in f3_columns:
        if col in f2_set:
            groups[col] = [col]
    return groups


def run_ablation(f3_features, y, f1_columns, f2_columns, params=None, splitter=None):
    """
    Run the full leave-one-group-out ablation plus the F1-only / F2-only
    boundary cases.

    Parameters
    ----------
    f3_features : pd.DataFrame, the combined F3 matrix.
    y : pd.Series of labels, aligned to f3_features.
    f1_columns, f2_columns : the exact column names that came from F1 and F2
        respectively (e.g. aligned["F1"].columns, aligned["F2"].columns from
        ml.f3_combined_features.build_f1_f2_f3) -- NOT re-derived by pattern
        matching. See module docstring.

    Returns
    -------
    pd.DataFrame with columns: ablation, n_features_removed, n_features_used,
    mean_auroc, std_auroc, mean_pr_auc, delta_auroc_vs_full (full - ablated;
    positive means removing that group HURT performance, i.e. it was useful).
    """
    groups = group_f3_columns(f3_features.columns, f1_columns, f2_columns)
    topology_cols = groups.get("f1_curve", []) + groups.get("f1_scalar", [])
    standard_cols = [c for name, cols in groups.items()
                     if name not in ("f1_curve", "f1_scalar") for c in cols]

    rows = []

    def _score(name, X, n_removed):
        cv = cross_validated_auroc(X, y, params=params, splitter=splitter)
        rows.append({
            "ablation": name,
            "n_features_removed": n_removed,
            "n_features_used": X.shape[1],
            "mean_auroc": cv["mean_auroc"],
            "std_auroc": cv["std_auroc"],
            "mean_pr_auc": cv["mean_pr_auc"],
        })
        return cv["mean_auroc"]

    full_auroc = _score("full_F3", f3_features, n_removed=0)

    for group_name, cols in groups.items():
        remaining = f3_features.drop(columns=cols)
        if remaining.shape[1] == 0:
            continue
        _score(f"minus_{group_name}", remaining, n_removed=len(cols))

    if topology_cols:
        _score("F1_only (all topology)", f3_features[topology_cols], n_removed=len(standard_cols))
    if standard_cols:
        _score("F2_only (all standard)", f3_features[standard_cols], n_removed=len(topology_cols))

    table = pd.DataFrame(rows)
    table["delta_auroc_vs_full"] = full_auroc - table["mean_auroc"]
    return table
