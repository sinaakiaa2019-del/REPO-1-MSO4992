"""
F3 combined feature set (Sina Kia) — Week 4.

F3 = F1 (topology) UNION F2 (standard). The plan's RQ3 asks whether topology
adds anything ON TOP OF the standard macro/vol feature set, so F3 is not a new
computation — it is F1 and F2 concatenated on their common date index, built
from feature matrices that are already aligned (see ml/data_access.py).

Column collisions are not expected in practice (F1 columns are all prefixed
h1_/h0_, F2 columns are vix/eigenvalue_gap/realised_vol_20d/yield_curve_slope),
but build_f3_features checks and disambiguates defensively rather than silently
dropping a column, since a silent drop would quietly bias the RQ3 comparison.
"""

import pandas as pd


def build_f3_features(f1_features, f2_features):
    """
    Concatenate F1 and F2 into the combined F3 matrix.

    Parameters
    ----------
    f1_features, f2_features : pd.DataFrame
        Date-indexed feature matrices. Should already be reduced to a common
        index (e.g. via ml.data_access.align_multiple) before calling this, so
        F3's row count matches F1's and F2's for a fair three-way comparison.

    Returns
    -------
    pd.DataFrame : column-wise concatenation of F1 and F2.
    """
    overlap = set(f1_features.columns) & set(f2_features.columns)
    f1 = f1_features.copy()
    f2 = f2_features.copy()
    if overlap:
        # Disambiguate rather than silently letting pandas keep only one copy.
        f1 = f1.rename(columns={c: f"f1_{c}" for c in overlap})
        f2 = f2.rename(columns={c: f"f2_{c}" for c in overlap})
        print(f"  F3: {len(overlap)} overlapping column name(s) disambiguated "
              f"with f1_/f2_ prefixes: {sorted(overlap)}")

    f3 = f1.join(f2, how="inner")
    # Attach the AUTHORITATIVE (post-rename) column membership directly to the
    # result, so downstream consumers (ml.ablation) never have to re-derive
    # F1-vs-F2 membership from aligned["F1"]/aligned["F2"].columns, which would
    # be WRONG after a collision rename above (those still hold the original,
    # pre-rename names). This is a plain dict, not something pandas
    # transformations could accidentally drop.
    f3.attrs["f1_columns"] = list(f1.columns)
    f3.attrs["f2_columns"] = list(f2.columns)
    return f3


def build_f1_f2_f3(f1_features, f2_features, crash_labels):
    """
    Convenience wrapper: align F1 and F2 to a common index + the labels, build
    F3 from the aligned pair, and return all three feature sets plus y — ready
    to hand straight to ml.models.compare_feature_sets.

    Returns
    -------
    (aligned_feature_sets, y)
        aligned_feature_sets : dict with keys "F1", "F2", "F3".
    """
    from ml.data_access import align_multiple

    aligned, y = align_multiple({"F1": f1_features, "F2": f2_features}, crash_labels)
    aligned["F3"] = build_f3_features(aligned["F1"], aligned["F2"])
    return aligned, y
