"""
Full SHAP suite (Sina Kia) — Week 7.

Extends the Week 4 out-of-sample SHAP infrastructure (beeswarm, heatmap) with:
  - Dependence plots: for the top-N features by mean |SHAP|, how does the
    feature's raw value relate to its SHAP contribution (and is there visible
    interaction with a second feature)?
  - Waterfall plots: for the single out-of-sample prediction closest to each
    reference crisis's onset, exactly which features pushed the predicted
    crash probability up (or down) from the model's baseline?

Everything here operates on the SAME out-of-sample SHAP values used
elsewhere (ml.shap_analysis.compute_shap_values_oos) -- no in-sample
shortcuts, consistent with every other explainability output in the project.
"""

from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import shap

from ml.ml_config import REFERENCE_CRASHES


def save_dependence_plots(shap_df, X, output_dir, top_n=6):
    """
    Save one dependence plot per top-N feature (by mean |SHAP| over the
    out-of-sample period) to output_dir. Interaction feature is picked
    automatically by shap ("auto").

    Returns list of saved file paths.
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    ranking = shap_df.abs().mean(axis=0).sort_values(ascending=False)
    top_features = ranking.head(top_n).index.tolist()

    # shap.dependence_plot expects shap_values/X aligned by row and in the
    # SAME order -- shap_df's index may not match X's full index (shap_df
    # only covers out-of-sample dates), so explicitly align first rather than
    # assuming .values order matches.
    X_aligned = X.loc[shap_df.index]

    paths = []
    for feature in top_features:
        fig = plt.figure()
        shap.dependence_plot(
            feature, shap_df.values, X_aligned, feature_names=list(X_aligned.columns),
            show=False, ax=plt.gca(),
        )
        plt.title(f"SHAP dependence — {feature}")
        plt.tight_layout()
        safe_name = feature.replace("/", "_")
        path = output_dir / f"shap_dependence_{safe_name}.png"
        plt.savefig(path, dpi=150, bbox_inches="tight")
        plt.close(fig)
        paths.append(path)

    return paths


def nearest_date_before(index, target_date, max_lookback_days=30):
    """
    Return the latest date in `index` that is < target_date and within
    max_lookback_days trading days, or None if none qualifies (including when
    `index` is empty or not a DatetimeIndex -- e.g. an empty DataFrame's
    default RangeIndex, which comparing against a Timestamp would otherwise
    raise TypeError on rather than cleanly returning "no qualifying date").
    """
    if not isinstance(index, pd.DatetimeIndex) or len(index) == 0:
        return None
    target = pd.Timestamp(target_date)
    candidates = index[index < target]
    if len(candidates) == 0:
        return None
    nearest = candidates.max()
    if (target - nearest).days > max_lookback_days * 1.5:  # generous calendar-day guard
        return None
    return nearest


def save_waterfall_for_date(shap_df, base_values, X, date, output_path, max_display=12):
    """
    Render a SHAP waterfall plot for a single out-of-sample date.

    Parameters
    ----------
    shap_df, base_values : outputs of
        ml.shap_analysis.compute_shap_values_oos(..., return_base_values=True)
    X : the same feature matrix shap_df/base_values were computed from
        (used to show each feature's raw value alongside its SHAP contribution).
    date : the exact date to plot (must be in shap_df.index).
    """
    if date not in shap_df.index:
        raise KeyError(f"{date} has no out-of-sample SHAP row.")

    explanation = shap.Explanation(
        values=shap_df.loc[date].values,
        base_values=float(base_values.loc[date]),
        data=X.loc[date].values,
        feature_names=list(X.columns),
    )
    plt.figure()
    shap.plots.waterfall(explanation, max_display=max_display, show=False)
    plt.tight_layout()
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close()
    return output_path


def save_crisis_waterfalls(shap_df, base_values, X, output_dir,
                           reference_crashes=REFERENCE_CRASHES, max_display=12):
    """
    For each reference crisis, find the nearest out-of-sample date before
    onset and save its waterfall plot. Crises with no qualifying out-of-sample
    date (e.g. inside the initial training block -- see Week 4 notes on the
    2000 dot-com crisis) are skipped and reported, not silently dropped.

    Returns pd.DataFrame: crisis, onset, explained_date, path (None if skipped).
    """
    output_dir = Path(output_dir)
    rows = []
    for name, start, end in reference_crashes:
        onset = pd.Timestamp(start)
        explained_date = nearest_date_before(shap_df.index, onset)
        if explained_date is None:
            rows.append({"crisis": name, "onset": onset.date().isoformat(),
                        "explained_date": None, "path": None})
            continue
        safe_name = name.replace(" ", "_")
        path = output_dir / f"shap_waterfall_{safe_name}.png"
        save_waterfall_for_date(shap_df, base_values, X, explained_date, path,
                                max_display=max_display)
        rows.append({
            "crisis": name, "onset": onset.date().isoformat(),
            "explained_date": explained_date.date().isoformat(), "path": str(path),
        })
    return pd.DataFrame(rows)
