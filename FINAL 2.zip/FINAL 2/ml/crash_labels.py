"""
Crash-label construction and verification (Sina Kia).

The plan defines a crash label as:
    label(t) = 1 if the maximum drawdown over the next 20 trading days of the
               S&P 500 index (SPY) is worse than -10%, else 0.

Octavian's data_processing.create_crash_labels already produces a preliminary
label from an equal-weighted portfolio of the 30-stock universe. That is fine
for early alignment, but the official label for the ML stage is index-based.
This module builds the index-based label and, crucially, VERIFIES that the three
reference crises (2000 dot-com, 2008 GFC, 2020 COVID) all receive a positive
label somewhere inside their known windows.

If a real SPY series is available it is used directly. If not, the module can
fall back to the equal-weighted portfolio of the available returns so the rest
of the pipeline still runs end-to-end before SPY is wired in.
"""

import numpy as np
import pandas as pd

from ml.ml_config import (
    CRASH_DRAWDOWN_LIMIT,
    CRASH_LOOKAHEAD_DAYS,
    REFERENCE_CRASHES,
)


def build_crash_labels_from_index(index_level, lookahead=CRASH_LOOKAHEAD_DAYS,
                                  drawdown_limit=CRASH_DRAWDOWN_LIMIT):
    """
    Build forward-looking crash labels from an index price/level series.

    Parameters
    ----------
    index_level : pd.Series
        Daily index level (e.g. SPY adjusted close), indexed by date.
    lookahead : int
        Number of trading days to look ahead.
    drawdown_limit : float
        Drawdown threshold (negative). A window whose minimum future level falls
        below current_level * (1 + drawdown_limit) is labelled a crash.

    Returns
    -------
    pd.DataFrame with a date index and a single 'crash_label' column.
    The last `lookahead` dates are dropped because their future window is
    incomplete (this is correct, not look-ahead leakage).
    """
    index_level = index_level.sort_index().dropna()
    values = index_level.values
    dates = index_level.index

    labels = np.zeros(len(values), dtype=int)
    for i in range(len(values) - lookahead):
        current = values[i]
        future_window = values[i + 1: i + 1 + lookahead]
        drawdown = (future_window.min() / current) - 1.0
        labels[i] = 1 if drawdown <= drawdown_limit else 0

    label_series = pd.Series(labels, index=dates, name="crash_label")
    # Drop the tail whose future window is incomplete.
    label_series = label_series.iloc[: len(values) - lookahead]
    return label_series.to_frame()


def build_crash_labels_from_returns(returns, lookahead=CRASH_LOOKAHEAD_DAYS,
                                    drawdown_limit=CRASH_DRAWDOWN_LIMIT):
    """
    Fallback when no index series is supplied: build an equal-weighted
    portfolio level from the returns matrix and label off that.

    This mirrors the logic in the data-engineering pipeline but lives here so the
    ML stage is self-contained.

    Octavian's returns are daily LOG returns, so the portfolio level is
    reconstructed with exp(cumsum(mean log return)), matching the corrected
    data_processing.create_simple_crash_labels. The previous (1+r).cumprod()
    mixed log returns with simple-return compounding and shifted the forward
    drawdown by ~3-4% at the -10% threshold, flipping borderline labels.
    """
    portfolio_returns = returns.mean(axis=1)
    portfolio_level = np.exp(portfolio_returns.cumsum())
    return build_crash_labels_from_index(portfolio_level, lookahead, drawdown_limit)


def verify_reference_crashes(crash_labels, reference_crashes=REFERENCE_CRASHES):
    """
    Check that each reference crisis window contains at least one positive label.

    Returns
    -------
    pd.DataFrame summarising, per crisis, whether a positive label was found and
    how many positive days fell inside the window.
    """
    labels = crash_labels["crash_label"]
    rows = []
    for name, start, end in reference_crashes:
        window = labels.loc[(labels.index >= start) & (labels.index <= end)]
        n_positive = int(window.sum()) if len(window) else 0
        rows.append({
            "crisis": name,
            "window_start": start,
            "window_end": end,
            "days_in_window": int(len(window)),
            "positive_days": n_positive,
            "fired": bool(n_positive > 0),
        })
    return pd.DataFrame(rows)


def class_balance(crash_labels):
    """
    Report the crash/non-crash class balance. The plan flags this as typically
    5-10% positive, which drives the scale_pos_weight choice in XGBoost.

    Returns a dict with counts, positive rate, and the implied scale_pos_weight
    (n_negative / n_positive).
    """
    labels = crash_labels["crash_label"]
    n_total = int(len(labels))
    n_positive = int(labels.sum())
    n_negative = n_total - n_positive
    positive_rate = n_positive / n_total if n_total else 0.0
    scale_pos_weight = (n_negative / n_positive) if n_positive > 0 else 1.0

    return {
        "n_total": n_total,
        "n_positive": n_positive,
        "n_negative": n_negative,
        "positive_rate": positive_rate,
        "scale_pos_weight": scale_pos_weight,
    }
