"""
Time-series expanding-window cross-validation (Sina Kia).

Why this exists
---------------
Standard k-fold cross-validation shuffles rows. For a time series that leaks
future information into the training set and gives optimistically biased scores
(Bergmeir & Benitez, 2012). This module implements an EXPANDING-WINDOW scheme
instead: each fold trains on everything up to a cut point and tests on the block
immediately after it. Training data is always strictly in the past of test data.

Two extra safeguards specific to this project:

1. Temporal ordering. Folds are produced in chronological order and the test
   block of fold i ends before the training set of fold i+1 grows past it.

2. Purge gap. The crash label at date t looks 20 trading days into the future.
   The final ~20 training rows therefore overlap the start of the test block.
   We drop a configurable gap of rows between train and test so no training row
   can "see" any day that is also used to build a test label.

This file is the Week 1 deliverable (the CV loop, no model) and is depended on by
every later ML experiment.
"""

import numpy as np


class ExpandingWindowSplit:
    """
    Generate expanding-window train/test index splits for a time-ordered series.

    Parameters
    ----------
    n_splits : int
        Number of test folds to produce.
    initial_train_fraction : float
        Fraction of the whole series reserved as the first training block, before
        the first test fold. Must be in (0, 1).
    purge_gap : int
        Number of rows to drop from the END of each training block so that no
        training row overlaps the look-ahead horizon of the test labels.

    Notes
    -----
    The split works on positional indices (0..n-1). The caller is responsible for
    passing data that is already sorted by date.
    """

    def __init__(self, n_splits=5, initial_train_fraction=0.40, purge_gap=0):
        if n_splits < 1:
            raise ValueError("n_splits must be at least 1.")
        if not 0.0 < initial_train_fraction < 1.0:
            raise ValueError("initial_train_fraction must be between 0 and 1.")
        if purge_gap < 0:
            raise ValueError("purge_gap cannot be negative.")

        self.n_splits = n_splits
        self.initial_train_fraction = initial_train_fraction
        self.purge_gap = purge_gap

    def get_n_splits(self):
        return self.n_splits

    def split(self, n_samples):
        """
        Yield (train_index, test_index) positional arrays.

        The region after the initial training block is divided into n_splits
        contiguous test blocks of roughly equal size. For each fold the training
        set is everything before that test block (expanding), minus the purge gap.
        """
        if n_samples < self.n_splits + 1:
            raise ValueError(
                f"Not enough samples ({n_samples}) for {self.n_splits} folds."
            )

        initial_train_end = int(round(n_samples * self.initial_train_fraction))
        # Make sure there is room for every test fold to contain at least one row.
        initial_train_end = max(self.n_splits, min(initial_train_end, n_samples - self.n_splits))

        test_region_size = n_samples - initial_train_end
        # Edges that divide the test region into n_splits contiguous blocks.
        block_edges = np.linspace(initial_train_end, n_samples, self.n_splits + 1)
        block_edges = np.round(block_edges).astype(int)

        for fold in range(self.n_splits):
            test_start = block_edges[fold]
            test_end = block_edges[fold + 1]

            if test_end <= test_start:
                # Degenerate block (can happen with very short series); skip it.
                continue

            train_end = test_start - self.purge_gap
            if train_end <= 0:
                # Purge gap consumed the whole training block; skip this fold.
                continue

            train_index = np.arange(0, train_end)
            test_index = np.arange(test_start, test_end)

            yield train_index, test_index


def check_no_leakage(train_index, test_index):
    """
    Assert that a single split does not leak: every training position is strictly
    before every test position, and the two index sets do not overlap.

    Raises AssertionError if the split is invalid. Returns True otherwise.
    """
    train_index = np.asarray(train_index)
    test_index = np.asarray(test_index)

    assert len(train_index) > 0, "Training index is empty."
    assert len(test_index) > 0, "Test index is empty."
    assert len(np.intersect1d(train_index, test_index)) == 0, (
        "Train and test indices overlap."
    )
    assert train_index.max() < test_index.min(), (
        "A training position is not strictly before the test block "
        "(possible look-ahead leakage)."
    )
    return True


def describe_splits(splitter, n_samples):
    """
    Build a small human-readable summary of the folds for logging / the paper.

    Returns a list of dicts, one per fold, with train/test sizes and boundaries.
    """
    summary = []
    for fold, (train_index, test_index) in enumerate(splitter.split(n_samples)):
        check_no_leakage(train_index, test_index)
        summary.append({
            "fold": fold,
            "train_size": int(len(train_index)),
            "test_size": int(len(test_index)),
            "train_start": int(train_index.min()),
            "train_end": int(train_index.max()),
            "test_start": int(test_index.min()),
            "test_end": int(test_index.max()),
        })
    return summary
