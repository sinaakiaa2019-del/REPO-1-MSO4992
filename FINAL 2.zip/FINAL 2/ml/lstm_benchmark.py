"""
LSTM benchmark (Sina Kia) — Week 8.

Positions the project against a standard deep-learning baseline (Jiang et al.
2021, DEEP reading list) using the SAME expanding-window CV, purge gap, and
leakage checks as every XGBoost result in this project -- an LSTM evaluated
under weaker CV would not be a fair comparison.

Key differences from the XGBoost pipeline that matter here:
  - LSTMs consume SEQUENCES, not single rows. build_sequences turns the
    feature matrix into overlapping windows of length seq_len; the label at
    position i is predicted from rows [i-seq_len+1 .. i].
  - Feature scaling is fit on the TRAINING portion of each fold only, then
    applied to that fold's test portion -- fitting a scaler on the full
    series first would leak test-set statistics into training, the same class
    of leakage the purge gap exists to prevent elsewhere in this project.
  - class imbalance is handled via pos_weight in BCEWithLogitsLoss (the LSTM
    analogue of XGBoost's scale_pos_weight), computed from the TRAINING
    labels of each fold only.
"""

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score

from ml.cross_validation import ExpandingWindowSplit, check_no_leakage
from ml.ml_config import INITIAL_TRAIN_FRACTION, N_CV_FOLDS, PURGE_GAP


def build_sequences(X, y, seq_len=20):
    """
    Turn a (n_rows, n_features) matrix into overlapping sequences of length
    seq_len. The label for sequence i is y at the LAST row of that sequence
    (i.e. "predict crash at time t from the seq_len rows ending at t").

    Returns (sequences, labels, dates) where sequences has shape
    (n_rows - seq_len + 1, seq_len, n_features), labels/dates are aligned to
    the LAST row of each sequence.
    """
    X_values = X.values.astype(np.float32)
    y_values = np.asarray(y).astype(int)
    n = len(X_values)
    if n < seq_len:
        raise ValueError(f"Need at least seq_len={seq_len} rows, got {n}.")

    sequences = np.stack([X_values[i - seq_len + 1: i + 1] for i in range(seq_len - 1, n)])
    labels = y_values[seq_len - 1:]
    dates = X.index[seq_len - 1:]
    return sequences, labels, dates


def _train_one_fold(X_train_seq, y_train, X_test_seq, hidden_size, epochs, lr, seed):
    import torch
    import torch.nn as nn

    torch.manual_seed(seed)

    # Scale using TRAIN statistics only, applied to both train and test --
    # the fold-local analogue of scale_pos_weight being computed from
    # training labels only elsewhere in this project.
    mean = X_train_seq.reshape(-1, X_train_seq.shape[-1]).mean(axis=0)
    std = X_train_seq.reshape(-1, X_train_seq.shape[-1]).std(axis=0)
    std[std < 1e-8] = 1e-8
    X_train_scaled = (X_train_seq - mean) / std
    X_test_scaled = (X_test_seq - mean) / std

    X_train_t = torch.tensor(X_train_scaled, dtype=torch.float32)
    y_train_t = torch.tensor(y_train, dtype=torch.float32)
    X_test_t = torch.tensor(X_test_scaled, dtype=torch.float32)

    n_pos = int(y_train.sum())
    n_neg = int(len(y_train) - n_pos)
    pos_weight = torch.tensor([n_neg / n_pos]) if n_pos > 0 else torch.tensor([1.0])

    input_size = X_train_seq.shape[-1]

    class SimpleLSTM(nn.Module):
        def __init__(self):
            super().__init__()
            self.lstm = nn.LSTM(input_size, hidden_size, num_layers=1, batch_first=True)
            self.head = nn.Linear(hidden_size, 1)

        def forward(self, x):
            out, _ = self.lstm(x)
            last = out[:, -1, :]  # final timestep's hidden state
            return self.head(last).squeeze(-1)

    model = SimpleLSTM()
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.BCEWithLogitsLoss(pos_weight=pos_weight)

    model.train()
    for _ in range(epochs):
        optimizer.zero_grad()
        logits = model(X_train_t)
        loss = loss_fn(logits, y_train_t)
        loss.backward()
        optimizer.step()

    model.eval()
    with torch.no_grad():
        test_logits = model(X_test_t)
        test_proba = torch.sigmoid(test_logits).numpy()

    return test_proba


def cross_validated_lstm_auroc(X, y, seq_len=20, hidden_size=16, epochs=15, lr=1e-2,
                               splitter=None, random_state=42):
    """
    Run the LSTM under expanding-window CV, in the same return shape as
    ml.models.cross_validated_auroc so results are directly comparable /
    interchangeable with the XGBoost table.
    """
    sequences, labels, dates = build_sequences(X, y, seq_len=seq_len)

    if splitter is None:
        splitter = ExpandingWindowSplit(
            n_splits=N_CV_FOLDS,
            initial_train_fraction=INITIAL_TRAIN_FRACTION,
            # The purge gap is expressed in ROWS elsewhere in the project; a
            # sequence already consumes seq_len-1 rows of history, so no
            # additional purge is needed on TOP of the label's own lookahead
            # gap already baked into PURGE_GAP for the underlying row index.
            purge_gap=max(0, PURGE_GAP),
        )

    fold_detail = []
    fold_auroc = []
    for fold, (train_idx, test_idx) in enumerate(splitter.split(len(sequences))):
        check_no_leakage(train_idx, test_idx)

        X_train_seq, y_train = sequences[train_idx], labels[train_idx]
        X_test_seq, y_test = sequences[test_idx], labels[test_idx]

        if len(np.unique(y_train)) < 2 or len(X_train_seq) < 2:
            # Nothing learnable this fold (e.g. all-negative training block).
            fold_auroc.append(np.nan)
            fold_detail.append({
                "fold": fold, "train_size": int(len(train_idx)), "test_size": int(len(test_idx)),
                "test_positives": int(y_test.sum()), "auroc": np.nan, "pr_auc": np.nan,
            })
            continue

        proba = _train_one_fold(
            X_train_seq, y_train, X_test_seq, hidden_size, epochs, lr,
            seed=random_state + fold,
        )

        if len(np.unique(y_test)) < 2:
            auroc, pr_auc = np.nan, np.nan
        else:
            auroc = roc_auc_score(y_test, proba)
            pr_auc = average_precision_score(y_test, proba)

        fold_auroc.append(auroc)
        fold_detail.append({
            "fold": fold, "train_size": int(len(train_idx)), "test_size": int(len(test_idx)),
            "test_positives": int(y_test.sum()), "auroc": auroc, "pr_auc": pr_auc,
        })

    valid = [a for a in fold_auroc if not np.isnan(a)]
    valid_pr = [d["pr_auc"] for d in fold_detail if not np.isnan(d["pr_auc"])]
    n_scored = len(valid)
    n_total = len(fold_auroc)

    return {
        "fold_auroc": fold_auroc,
        "mean_auroc": float(np.mean(valid)) if valid else np.nan,
        "std_auroc": float(np.std(valid)) if valid else np.nan,
        "mean_pr_auc": float(np.mean(valid_pr)) if valid_pr else np.nan,
        "std_pr_auc": float(np.std(valid_pr)) if valid_pr else np.nan,
        "fold_detail": fold_detail,
        "n_scored_folds": n_scored,
        "n_total_folds": n_total,
        "single_class_folds": n_total - n_scored,
        "seq_len": seq_len,
        "hidden_size": hidden_size,
        "epochs": epochs,
    }


def build_lstm_vs_xgboost_table(lstm_result, xgboost_result):
    """Small side-by-side comparison table for the two model families."""
    rows = [
        {"model": "XGBoost (F3)", "mean_auroc": xgboost_result["mean_auroc"],
         "std_auroc": xgboost_result["std_auroc"], "mean_pr_auc": xgboost_result["mean_pr_auc"],
         "n_scored_folds": xgboost_result["n_scored_folds"], "n_total_folds": xgboost_result["n_total_folds"]},
        {"model": f"LSTM (F3, seq_len={lstm_result['seq_len']})", "mean_auroc": lstm_result["mean_auroc"],
         "std_auroc": lstm_result["std_auroc"], "mean_pr_auc": lstm_result["mean_pr_auc"],
         "n_scored_folds": lstm_result["n_scored_folds"], "n_total_folds": lstm_result["n_total_folds"]},
    ]
    return pd.DataFrame(rows)
