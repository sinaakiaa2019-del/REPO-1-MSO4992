"""
Live market snapshot (Sina Kia) — Week 8.

Scope, and why it's narrower than the full F3 model: a genuinely live crash
probability needs F1 (topology), which requires Kunal's real-time TDA
pipeline (ripser on a live rolling correlation matrix) -- that does not exist
yet. It also needs the FULL F2 (including eigenvalue_gap, which needs the
complete ~30-asset correlation matrix, i.e. Octavian's full live data pull,
not just a couple of tickers).

What IS realistically available from a lightweight live pull, and what this
module actually fetches:
  - vix               : CBOE VIX level (^VIX)
  - realised_vol_20d  : 20-day realised vol of SPY returns, annualised
  - yield_curve_slope : T10Y2Y from FRED

This is deliberately called the "F2-lite" feature set (see LIVE_F2_LITE_
FEATURES) to keep it visually distinct from the full 4-feature F2 used
everywhere else in the project -- a live prediction from this smaller feature
set should never be presented as equivalent to the properly-validated F3
result, and the dashboard is written to say so explicitly.
"""

from datetime import datetime, timezone

import numpy as np
import pandas as pd

LIVE_F2_LITE_FEATURES = ["vix", "realised_vol_20d", "yield_curve_slope"]


class LiveDataUnavailableError(RuntimeError):
    """Raised when a live market data source could not be reached or parsed."""


def fetch_live_f2_snapshot():
    """
    Fetch today's VIX, SPY-derived realised vol, and T10Y2Y.

    Returns dict with LIVE_F2_LITE_FEATURES as keys plus 'as_of_utc'.
    Raises LiveDataUnavailableError (with the underlying cause chained) on
    ANY failure -- network unavailable, ticker delisted, FRED series renamed,
    empty response, etc. -- rather than letting an unrelated exception type
    propagate to the caller (the dashboard needs one exception type to catch).
    """
    try:
        import yfinance as yf
    except ImportError as exc:
        raise LiveDataUnavailableError(
            "yfinance is not installed. Run: pip install yfinance"
        ) from exc

    try:
        vix_history = yf.Ticker("^VIX").history(period="5d")
        if vix_history.empty:
            raise LiveDataUnavailableError("VIX history returned empty from yfinance.")
        vix = float(vix_history["Close"].iloc[-1])

        spy_history = yf.Ticker("SPY").history(period="60d")
        if len(spy_history) < 21:
            raise LiveDataUnavailableError(
                f"SPY history too short ({len(spy_history)} rows) to compute 20-day realised vol."
            )
        spy_returns = spy_history["Close"].pct_change().dropna()
        realised_vol_20d = float(spy_returns.tail(20).std() * np.sqrt(252))

    except LiveDataUnavailableError:
        raise
    except Exception as exc:
        raise LiveDataUnavailableError(f"yfinance fetch failed: {exc}") from exc

    try:
        import pandas_datareader.data as web
    except ImportError as exc:
        raise LiveDataUnavailableError(
            "pandas_datareader is not installed. Run: pip install pandas-datareader"
        ) from exc

    try:
        end = pd.Timestamp.today()
        start = end - pd.Timedelta(days=14)
        t10y2y = web.DataReader("T10Y2Y", "fred", start, end)
        if t10y2y.empty:
            raise LiveDataUnavailableError("T10Y2Y series returned empty from FRED.")
        yield_curve_slope = float(t10y2y.dropna().iloc[-1, 0])
    except LiveDataUnavailableError:
        raise
    except Exception as exc:
        raise LiveDataUnavailableError(f"FRED T10Y2Y fetch failed: {exc}") from exc

    return {
        "vix": vix,
        "realised_vol_20d": realised_vol_20d,
        "yield_curve_slope": yield_curve_slope,
        "as_of_utc": datetime.now(timezone.utc).isoformat(),
    }


def build_live_f2_lite_features(macro_df):
    """
    Build the historical F2-lite (3-column) training frame from whatever
    macro source is already available (same priority/columns as
    ml.f2_standard_features, restricted to the 3 live-obtainable columns).

    Returns pd.DataFrame with exactly LIVE_F2_LITE_FEATURES as columns.
    """
    from ml.f2_standard_features import F2_COLUMN_ALIASES, _first_present

    collected = {}
    for canonical in LIVE_F2_LITE_FEATURES:
        col = _first_present(macro_df, F2_COLUMN_ALIASES[canonical])
        if col is None:
            raise ValueError(
                f"macro_df has none of the recognised columns for '{canonical}': "
                f"{F2_COLUMN_ALIASES[canonical]}"
            )
        collected[canonical] = macro_df[col]

    features = pd.DataFrame(collected)
    features.index = pd.to_datetime(features.index)
    return features.sort_index()
