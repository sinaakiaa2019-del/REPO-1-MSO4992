"""
Data loading and alignment helpers for the ML stage (Sina Kia).

Every ML experiment needs feature matrices and the label series on a common,
strictly date-sorted index with no missing rows. These helpers centralise that
join so each experiment script does not re-implement it (and so leakage from
misaligned indices cannot creep in).
"""

import numpy as np
import pandas as pd


def load_returns(returns_file):
    """Load the returns CSV with a parsed DatetimeIndex."""
    returns = pd.read_csv(returns_file, index_col=0)
    returns.index = pd.to_datetime(returns.index)
    return returns.sort_index()


def load_metadata(metadata_file):
    """Load window metadata with parsed dates."""
    meta = pd.read_csv(metadata_file)
    meta["date"] = pd.to_datetime(meta["date"])
    return meta.sort_values("date").reset_index(drop=True)


def align_features_labels(features, labels, dropna=True):
    """
    Align a feature DataFrame and a label DataFrame/Series on their common dates.

    Parameters
    ----------
    features : pd.DataFrame (date index)
    labels : pd.DataFrame with 'crash_label' column, or pd.Series, date index.
    dropna : bool
        Drop any rows with missing feature values after the join.

    Returns
    -------
    (X, y) with identical, sorted DatetimeIndex.
    """
    if isinstance(labels, pd.DataFrame):
        label_series = labels["crash_label"]
    else:
        label_series = labels
    label_series = label_series.copy()
    label_series.index = pd.to_datetime(label_series.index)

    features = features.copy()
    features.index = pd.to_datetime(features.index)

    common = features.index.intersection(label_series.index)
    common = common.sort_values()

    X = features.loc[common]
    y = label_series.loc[common]

    if dropna:
        mask = ~X.isna().any(axis=1)
        X = X.loc[mask]
        y = y.loc[mask]

    if len(X) == 0:
        raise ValueError("No overlapping dates between features and labels after alignment.")

    return X, y.astype(int)


def align_multiple(feature_sets, labels):
    """
    Align several feature matrices AND the labels onto the SAME common index, so
    that F1/F2/F3 are compared on exactly the same rows.

    Returns (aligned_feature_sets, y) where aligned_feature_sets is a dict with
    the same keys, each reindexed to the shared dates.
    """
    label_series = labels["crash_label"] if isinstance(labels, pd.DataFrame) else labels
    label_series = label_series.copy()
    label_series.index = pd.to_datetime(label_series.index)

    common = label_series.index
    for X in feature_sets.values():
        idx = pd.to_datetime(X.index)
        common = common.intersection(idx)
    common = common.sort_values()

    aligned = {}
    for name, X in feature_sets.items():
        X = X.copy()
        X.index = pd.to_datetime(X.index)
        aligned[name] = X.loc[common]

    y = label_series.loc[common].astype(int)

    # Drop any date where ANY feature set has a missing value, to keep rows identical.
    bad = np.zeros(len(common), dtype=bool)
    for X in aligned.values():
        bad |= X.isna().any(axis=1).values
    keep = ~bad
    for name in aligned:
        aligned[name] = aligned[name].loc[keep]
    y = y.loc[keep]

    return aligned, y
