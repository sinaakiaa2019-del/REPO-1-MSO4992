"""
Sector leadership analysis (Sina Kia) — Week 5, RQ5.

Question: which GICS sector's own correlation-network topology shows stress
EARLIEST before a crash? For each of the 11 GICS sectors, this module:
  1. Loads (or synthesises) that sector's topology-only (F1) feature matrix.
  2. Trains the same expanding-window-CV XGBoost model used everywhere else in
     the project on that sector's F1 features alone, against the shared
     (global, index-based) crash labels.
  3. Runs the Week 4 out-of-sample lead-time logic per sector.
  4. Assembles a sectors x crash-events matrix of lead time in trading days,
     which is exactly the "sector leadership heatmap" the plan asks for.

Data sourcing: real per-sector topology handover from Kunal
(data/processed/sectors/<Sector>/topology_features.csv or betti_curves.npz) is
used when present. Until that handover exists, this uses a synthetic Betti
curve generator with a DETERMINISTIC, EXPLICITLY ARBITRARY per-sector lead
bias (SECTOR_LEAD_BIAS_DAYS below) so the heatmap has something to show and the
pipeline can be exercised end-to-end. These numbers carry NO empirical meaning
and must not be quoted in the paper — they exist purely so the leadership
heatmap code, the alignment logic, and the plotting are proven correct before
Kunal's real per-sector topology is dropped in, at which point it is consumed
automatically (see load_asset_class_features in cross_asset_validation.py for
the same real-first / synthetic-fallback pattern used here).
"""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from pathlib import Path

from ml import ml_config
from ml.data_access import align_features_labels
from ml.f1_topology_features import build_f1_from_betti_array, load_f1_features
from ml.lead_time_analysis import compute_lead_times, out_of_sample_probabilities
from ml.ml_config import GICS_SECTORS, REFERENCE_CRASHES
from ml import synthetic_data

# ARBITRARY, SYNTHETIC-ONLY placeholder lead biases (trading days each sector's
# synthetic topology signal is shifted earlier than the crisis onset). Replace
# entirely once real per-sector topology is handed over -- see module docstring.
SECTOR_LEAD_BIAS_DAYS = {
    "Financials":              25,
    "Real_Estate":             20,
    "Information_Technology":  15,
    "Consumer_Discretionary":  10,
    "Industrials":              8,
    "Materials":                5,
    "Energy":                   5,
    "Communication_Services":   3,
    "Health_Care":              0,
    "Consumer_Staples":         0,
    "Utilities":                0,
}


def load_sector_f1_features(sector_name, seed_offset=0):
    """
    Load real per-sector F1 topology features if Kunal's handover exists,
    otherwise synthesise them with this sector's placeholder lead bias.

    Returns (f1_features, provenance_str).
    """
    topo_csv = ml_config.sector_topology_file(sector_name)
    betti_npz = ml_config.sector_betti_file(sector_name)
    try:
        f1_features, source = load_f1_features(
            topology_csv_path=topo_csv, betti_npz_path=betti_npz,
        )
        return f1_features, f"real: {source}"
    except FileNotFoundError:
        lead_bias = SECTOR_LEAD_BIAS_DAYS.get(sector_name, 0)
        returns = synthetic_data.make_synthetic_asset_class_returns(
            n_assets=15, seed=100 + seed_offset,
        )
        betti_array, dates = synthetic_data.make_synthetic_asset_class_betti(
            returns, seed=200 + seed_offset, lead_bias_days=lead_bias,
        )
        f1_features = build_f1_from_betti_array(betti_array, dates)
        return f1_features, (
            f"SYNTHETIC placeholder (lead_bias_days={lead_bias}, "
            "arbitrary -- not an empirical result)"
        )


def compute_sector_lead_times(sector_name, f1_features, crash_labels,
                              threshold=ml_config.CROSS_ASSET_LEAD_TIME_THRESHOLD,
                              lookback_days=ml_config.SECTOR_LEAD_TIME_LOOKBACK_DAYS):
    """
    Train on this sector's F1 features alone and compute out-of-sample
    lead times against each reference crash. Returns a DataFrame (one row per
    crisis, tagged with sector) exactly like ml.lead_time_analysis.compute_lead_times
    but with a 'sector' column prepended.
    """
    X, y = align_features_labels(f1_features, crash_labels)
    if len(y.unique()) < 2 or len(X) < 20:
        result = compute_lead_times(pd.Series(dtype=float), threshold=threshold,
                                    lookback_days=lookback_days)
    else:
        proba = out_of_sample_probabilities(X, y)
        result = compute_lead_times(proba, threshold=threshold, lookback_days=lookback_days)
    result.insert(0, "sector", sector_name)
    return result


def build_sector_leadership_table(crash_labels, sectors=GICS_SECTORS):
    """
    Run compute_sector_lead_times for every GICS sector and stack the results.

    Returns (long_table, provenance) where long_table has one row per
    (sector, crisis) and provenance maps sector -> data source string.
    """
    rows = []
    provenance = {}
    for i, sector in enumerate(sectors):
        f1_features, source = load_sector_f1_features(sector, seed_offset=i)
        provenance[sector] = source
        sector_result = compute_sector_lead_times(sector, f1_features, crash_labels)
        rows.append(sector_result)
        found = int(sector_result["alarm_found"].sum())
        print(f"  [{sector}] {source} -- alarms found: {found}/{len(sector_result)}")

    long_table = pd.concat(rows, ignore_index=True)
    return long_table, provenance


def pivot_leadership_heatmap(long_table, crash_names=None):
    """
    Pivot the long (sector, crisis) table into a sectors x crash-events matrix
    of lead_time_trading_days (NaN where no alarm was found), sorted so the
    earliest-leading sector (smallest mean lead time is BEST -- most warning)
    appears first.
    """
    if crash_names is None:
        crash_names = [c[0] for c in REFERENCE_CRASHES]

    pivot = long_table.pivot(index="sector", columns="crisis", values="lead_time_trading_days")
    pivot = pivot.reindex(columns=crash_names)
    # Larger lead time = more warning = "leads" more. Sort descending by mean
    # available lead time so the top row is the earliest / most useful sector.
    order = pivot.mean(axis=1, skipna=True).sort_values(ascending=False).index
    return pivot.loc[order]


def save_sector_leadership_heatmap(pivot, output_path, title=None):
    """Render the sectors x crash-events lead-time matrix as a heatmap PNG."""
    fig, ax = plt.subplots(figsize=(max(6, 1.6 * pivot.shape[1] + 3), max(4, 0.4 * pivot.shape[0])))

    values = pivot.values.astype(float)
    masked = np.ma.masked_invalid(values)
    cmap = plt.cm.viridis.copy()
    cmap.set_bad(color="#dddddd")

    im = ax.imshow(masked, aspect="auto", cmap=cmap)
    ax.set_xticks(range(pivot.shape[1]))
    ax.set_xticklabels(pivot.columns, rotation=30, ha="right", fontsize=9)
    ax.set_yticks(range(pivot.shape[0]))
    ax.set_yticklabels(pivot.index, fontsize=9)

    for i in range(pivot.shape[0]):
        for j in range(pivot.shape[1]):
            v = values[i, j]
            label = f"{v:.0f}" if not np.isnan(v) else "-"
            ax.text(j, i, label, ha="center", va="center", fontsize=8,
                    color="white" if not np.isnan(v) else "#666666")

    plt.colorbar(im, ax=ax, label="Lead time (trading days before onset)")
    ax.set_title(title or "Sector Leadership Heatmap (lead time before crash onset)")
    fig.tight_layout()
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return output_path
