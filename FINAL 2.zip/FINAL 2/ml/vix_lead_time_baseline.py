"""
VIX-baseline lead-time comparison (Sina Kia) -- completes RQ on lead time.

The plan's actual lead-time claim is a DIFFERENTIAL: "the topology signal fires
N trading days EARLIER than VIX." ml/lead_time_analysis.py computes the model's
absolute lead time correctly, but on its own an absolute lead time proves
nothing -- VIX also rises before a crash. This module computes VIX's own lead
time using the standard practitioner rule (VIX crossing its rolling 95th
percentile) and subtracts it, so the paper can state the earliness of topology
RELATIVE to the standard fear gauge, which is the real claim.

vix_lead_times mirrors the structure of lead_time_analysis.compute_lead_times
(same crises, same trading-day counting via np.busday_count), so the two are
directly subtractable.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from ml.ml_config import REFERENCE_CRASHES


def vix_alarm_series(vix_series, quantile=0.95, rolling_window=252, min_periods=60):
    """
    Boolean alarm series: VIX above its trailing rolling `quantile`.

    Uses a TRAILING rolling quantile (not a global one) so the threshold at
    date t uses only information available up to t -- no look-ahead. Defaults:
    95th percentile over a trailing 1-year (252 trading day) window.
    """
    vix_series = vix_series.dropna().sort_index()
    threshold = vix_series.rolling(rolling_window, min_periods=min_periods).quantile(quantile)
    return (vix_series > threshold).fillna(False)


def vix_lead_times(vix_series, reference_crashes=REFERENCE_CRASHES,
                   lookback_days=120, quantile=0.95):
    """
    For each reference crisis, find the first VIX alarm within `lookback_days`
    trading days before onset, and report the lead time in trading days.

    Returns a DataFrame with the same shape/columns as
    lead_time_analysis.compute_lead_times so the two can be merged.
    """
    alarms = vix_alarm_series(vix_series, quantile=quantile)
    alarm_dates = alarms.index[alarms.values]

    rows = []
    for name, start, _end in reference_crashes:
        onset = pd.Timestamp(start)
        window_start = onset - pd.tseries.offsets.BDay(lookback_days)
        in_window = alarm_dates[(alarm_dates < onset) & (alarm_dates >= window_start)]

        if len(in_window) == 0:
            rows.append({
                "crisis": name, "onset": onset.date().isoformat(),
                "vix_alarm_date": None, "vix_lead_time_trading_days": None,
                "vix_alarm_found": False,
            })
            continue

        first = in_window.min()
        lead = int(np.busday_count(first.date(), onset.date()))
        rows.append({
            "crisis": name, "onset": onset.date().isoformat(),
            "vix_alarm_date": first.date().isoformat(),
            "vix_lead_time_trading_days": lead, "vix_alarm_found": True,
        })

    df = pd.DataFrame(rows)
    df["vix_lead_time_trading_days"] = pd.to_numeric(df["vix_lead_time_trading_days"],
                                                     errors="coerce")
    return df


def topology_vs_vix_lead_time(topology_lead_df, vix_lead_df):
    """
    Merge the topology lead-time table (from lead_time_analysis.compute_lead_times)
    with the VIX lead-time table and compute the differential.

    Returns a DataFrame with topology lead, VIX lead, and
    topology_minus_vix_days (positive => topology fired earlier than VIX).
    """
    topo = topology_lead_df.rename(columns={
        "lead_time_trading_days": "topology_lead_time_trading_days",
        "alarm_date": "topology_alarm_date",
        "alarm_found": "topology_alarm_found",
    })
    merged = topo.merge(vix_lead_df, on=["crisis", "onset"], how="outer")

    merged["topology_minus_vix_days"] = (
        merged["topology_lead_time_trading_days"] - merged["vix_lead_time_trading_days"]
    )
    return merged
