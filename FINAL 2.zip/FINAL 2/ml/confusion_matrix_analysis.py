"""
Confusion matrix analysis (Sina Kia) — Week 8.

Computed on OUT-OF-SAMPLE F3 probabilities (see ml.lead_time_analysis.
out_of_sample_probabilities), never in-sample -- an in-sample confusion
matrix would overstate performance the same way an in-sample AUROC would.

A single threshold (0.5) is rarely the right operating point for a rare-event
problem like this (crashes are ~5% of days), so this module reports both the
default-threshold confusion matrix AND a sweep across thresholds with the
best-F1 point highlighted, so the team can pick an operating point
deliberately rather than defaulting to 0.5 without discussion.
"""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def compute_confusion_matrix(proba, y, threshold=0.5):
    """
    Confusion matrix and derived metrics at a single threshold.

    Returns dict: threshold, tp, fp, tn, fn, precision, recall, specificity,
    f1, accuracy. Precision/recall/f1 are 0.0 (not NaN) when their
    denominator is zero (no predicted positives / no actual positives),
    following the standard sklearn convention, so the metric can still be
    plotted/averaged across thresholds without special-casing NaN downstream.
    """
    proba = np.asarray(proba, dtype=float)
    y = np.asarray(y, dtype=int)
    if len(proba) != len(y):
        raise ValueError("proba and y must be the same length.")

    pred = (proba >= threshold).astype(int)
    tp = int(np.sum((pred == 1) & (y == 1)))
    fp = int(np.sum((pred == 1) & (y == 0)))
    tn = int(np.sum((pred == 0) & (y == 0)))
    fn = int(np.sum((pred == 0) & (y == 1)))

    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    specificity = tn / (tn + fp) if (tn + fp) > 0 else 0.0
    f1 = (2 * precision * recall / (precision + recall)) if (precision + recall) > 0 else 0.0
    accuracy = (tp + tn) / len(y) if len(y) > 0 else 0.0

    return {
        "threshold": threshold, "tp": tp, "fp": fp, "tn": tn, "fn": fn,
        "precision": precision, "recall": recall, "specificity": specificity,
        "f1": f1, "accuracy": accuracy,
    }


def sweep_thresholds(proba, y, thresholds=None):
    """
    Compute the confusion-matrix metrics across a grid of thresholds.

    Returns pd.DataFrame, one row per threshold, sorted by threshold ascending.
    """
    if thresholds is None:
        thresholds = np.round(np.linspace(0.05, 0.95, 19), 2)
    rows = [compute_confusion_matrix(proba, y, threshold=t) for t in thresholds]
    return pd.DataFrame(rows)


def best_f1_threshold(sweep_table):
    """Return the row (as a dict) of sweep_table with the highest F1."""
    if sweep_table.empty:
        return None
    return sweep_table.loc[sweep_table["f1"].idxmax()].to_dict()


def save_confusion_matrix_plot(cm, output_path, title=None):
    """Render a 2x2 confusion matrix heatmap with counts and rates annotated."""
    matrix = np.array([[cm["tn"], cm["fp"]], [cm["fn"], cm["tp"]]])
    fig, ax = plt.subplots(figsize=(5, 4.5))
    im = ax.imshow(matrix, cmap="Blues")
    ax.set_xticks([0, 1])
    ax.set_yticks([0, 1])
    ax.set_xticklabels(["Predicted: no crash", "Predicted: crash"])
    ax.set_yticklabels(["Actual: no crash", "Actual: crash"])
    for i in range(2):
        for j in range(2):
            ax.text(j, i, str(matrix[i, j]), ha="center", va="center",
                    fontsize=14, color="white" if matrix[i, j] > matrix.max() / 2 else "black")
    subtitle = title or f"Confusion matrix @ threshold={cm['threshold']}"
    subtitle += (f"\nPrecision={cm['precision']:.2f}  Recall={cm['recall']:.2f}  "
                f"F1={cm['f1']:.2f}")
    ax.set_title(subtitle)
    plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return output_path


def save_threshold_sweep_plot(sweep_table, output_path, title=None):
    """Line plot of precision/recall/F1 across the threshold sweep."""
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(sweep_table["threshold"], sweep_table["precision"], marker="o", label="Precision")
    ax.plot(sweep_table["threshold"], sweep_table["recall"], marker="o", label="Recall")
    ax.plot(sweep_table["threshold"], sweep_table["f1"], marker="o", label="F1", linewidth=2)
    best = best_f1_threshold(sweep_table)
    if best is not None:
        ax.axvline(best["threshold"], linestyle="--", color="gray", alpha=0.6,
                  label=f"Best F1 @ {best['threshold']}")
    ax.set_xlabel("Threshold")
    ax.set_ylabel("Score")
    ax.set_title(title or "Precision / Recall / F1 vs threshold")
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return output_path
