"""
Calibration analysis (Sina Kia) — Week 6.

A crash probability is only useful for the dashboard (Week 7-8) if it is
CALIBRATED: among all dates where the model says "30% chance of a crash",
roughly 30% should actually crash. This module builds a reliability diagram
from out-of-sample probabilities (never in-sample -- an in-sample calibration
curve would just show the model agreeing with itself) and reports two summary
numbers: Brier score and Expected Calibration Error (ECE).

Reference: Niculescu-Mizil & Caruana (2005), on the Week 3 reading list --
tree ensembles like XGBoost are known to be reasonably well-calibrated already
but this should be checked, not assumed.
"""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def compute_calibration_curve(proba, y, n_bins=10):
    """
    Bin predictions into n_bins equal-width bins over [0, 1] and compute the
    observed positive rate in each bin.

    Parameters
    ----------
    proba : array-like, predicted P(crash).
    y : array-like, true 0/1 labels, same length/order as proba.
    n_bins : int

    Returns
    -------
    pd.DataFrame with one row per NON-EMPTY bin: bin_low, bin_high,
    mean_predicted, observed_frequency, count.
    """
    proba = np.asarray(proba, dtype=float)
    y = np.asarray(y, dtype=int)
    if len(proba) != len(y):
        raise ValueError("proba and y must be the same length.")

    edges = np.linspace(0.0, 1.0, n_bins + 1)
    # Rightmost edge inclusive so a prediction of exactly 1.0 lands in the
    # last bin instead of falling outside every bin.
    bin_idx = np.clip(np.digitize(proba, edges[1:-1], right=True), 0, n_bins - 1)

    rows = []
    for b in range(n_bins):
        mask = bin_idx == b
        count = int(mask.sum())
        if count == 0:
            continue
        rows.append({
            "bin_low": edges[b],
            "bin_high": edges[b + 1],
            "mean_predicted": float(proba[mask].mean()),
            "observed_frequency": float(y[mask].mean()),
            "count": count,
        })
    return pd.DataFrame(rows)


def brier_score(proba, y):
    """Mean squared error between predicted probability and the true label."""
    proba = np.asarray(proba, dtype=float)
    y = np.asarray(y, dtype=int)
    return float(np.mean((proba - y) ** 2))


def expected_calibration_error(calibration_table):
    """
    ECE: count-weighted average of |observed_frequency - mean_predicted|
    across bins. 0 = perfectly calibrated.
    """
    if calibration_table.empty:
        return np.nan
    total = calibration_table["count"].sum()
    weighted_gap = (
        (calibration_table["observed_frequency"] - calibration_table["mean_predicted"]).abs()
        * calibration_table["count"]
    ).sum()
    return float(weighted_gap / total)


def save_calibration_plot(calibration_table, output_path, title=None,
                          brier=None, ece=None):
    """
    Render a reliability diagram: observed frequency vs mean predicted
    probability per bin (with a perfect-calibration diagonal), plus a bar
    showing how many out-of-sample observations fell in each bin.
    """
    fig, (ax1, ax2) = plt.subplots(
        2, 1, figsize=(6, 7), gridspec_kw={"height_ratios": [3, 1]}, sharex=True,
    )

    ax1.plot([0, 1], [0, 1], linestyle="--", color="gray", label="Perfect calibration")
    if not calibration_table.empty:
        ax1.plot(
            calibration_table["mean_predicted"], calibration_table["observed_frequency"],
            marker="o", color="#D62728", label="Model (out-of-sample)",
        )
    ax1.set_ylabel("Observed frequency")
    ax1.set_xlim(0, 1)
    ax1.set_ylim(0, 1)
    subtitle = title or "Calibration curve (reliability diagram)"
    if brier is not None or ece is not None:
        subtitle += f"\nBrier={brier:.4f}" if brier is not None else ""
        subtitle += f"  ECE={ece:.4f}" if ece is not None else ""
    ax1.set_title(subtitle)
    ax1.legend(fontsize=8)

    if not calibration_table.empty:
        widths = calibration_table["bin_high"] - calibration_table["bin_low"]
        ax2.bar(
            calibration_table["bin_low"], calibration_table["count"],
            width=widths, align="edge", color="#4C72B0", alpha=0.7,
        )
    ax2.set_xlabel("Mean predicted probability (bin)")
    ax2.set_ylabel("Count")

    fig.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return output_path
