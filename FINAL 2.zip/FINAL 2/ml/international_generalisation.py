"""
International generalisation via transfer (Sina Kia) — Week 7, RQ4 continued.

Week 5's cross-asset AUROC trains a SEPARATE model on each asset class's own
topology (does credit/international topology carry a signal AT ALL?). This
module asks a stricter question: does a model trained ONLY on equity topology
generalise DIRECTLY -- with no retraining -- to credit and international
markets? That is only a meaningful test if the input feature space is
literally the same in both places, which holds for F1 (topology) because
every asset class's Betti curve is sampled on the same fixed epsilon grid and
therefore produces the same column schema (h1_eps_000 ... h1_eps_049 + the
scalar summaries) regardless of which instruments went into it. F2 does NOT
have this property (equity's F2 is VIX/eigenvalue-gap/vol/yield-slope; credit
and international's synthetic F2 is a 2-column vol/level proxy) -- transfer is
therefore only attempted on F1, not F2 or F3.

The "source" model is the model from the LAST fold of the equity expanding-
window CV (ml.models.cross_validated_auroc with return_models=True) -- i.e.
the model trained on the largest, most-recent block of equity history, same
choice Week 4 made when picking a single model for SHAP. It is applied,
UNCHANGED, to every row of the target asset class's F1 matrix.
"""

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score

from ml.data_access import align_features_labels
from ml.models import cross_validated_auroc


def train_source_model(f1_source, y_source, params=None, splitter=None):
    """
    Train the equity ("source") model via the standard expanding-window CV and
    return the last fold's fitted model plus that fold's own CV summary (a
    sanity check that the source model itself is reasonable before trusting
    any transfer result derived from it).

    Returns (model, source_cv_result). Raises ValueError if no fold produced
    a model (e.g. too little data for even one split).
    """
    cv = cross_validated_auroc(f1_source, y_source, params=params, splitter=splitter,
                               return_models=True)
    if not cv["models"]:
        raise ValueError("No CV fold produced a trained source model.")
    return cv["models"][-1], cv


def evaluate_transfer(model, source_columns, f1_target, y_target, asset_name):
    """
    Apply the equity-trained model, unchanged, to a target asset class's F1
    matrix and score it.

    Raises ValueError if the target's columns don't match the source model's
    expected schema exactly -- silently reindexing or padding would produce a
    prediction that looks valid but is meaningless (XGBoost has no way to
    detect that column 7 means something different in the target data).
    """
    target_columns = list(f1_target.columns)
    if target_columns != list(source_columns):
        raise ValueError(
            f"[{asset_name}] F1 column schema does not match the source model's "
            f"training schema -- transfer is not valid. "
            f"Source has {len(source_columns)} columns, target has {len(target_columns)}. "
            "This happens if the two asset classes used a different n_epsilon "
            "when their Betti curves were built, or if Kunal's real handover "
            "uses a different column layout than the synthetic placeholder."
        )

    proba = model.predict_proba(f1_target.values)[:, 1]
    y_values = np.asarray(y_target).astype(int)

    if len(np.unique(y_values)) < 2:
        auroc, pr_auc = np.nan, np.nan
    else:
        auroc = roc_auc_score(y_values, proba)
        pr_auc = average_precision_score(y_values, proba)

    return {
        "asset_class": asset_name,
        "n_rows": len(y_values),
        "n_positive": int(y_values.sum()),
        "transfer_auroc": auroc,
        "transfer_pr_auc": pr_auc,
    }


def run_international_generalisation(f1_equity, y_equity, target_datasets,
                                     params=None, splitter=None):
    """
    Train the source model on equity F1, then evaluate transfer to every
    (asset_name, f1_target_features) pair in target_datasets, aligning each
    target's features to the SAME shared crash labels used for equity.

    Parameters
    ----------
    target_datasets : dict[str, (f1_target_features, crash_labels)]
        e.g. {"credit": (credit_f1, crash_labels), "international": (intl_f1, crash_labels)}

    Returns
    -------
    (table, source_cv_result)
        table : pd.DataFrame, one row per target asset class, plus a row for
        the source model's own (equity) out-of-sample performance for reference.
    """
    model, source_cv = train_source_model(f1_equity, y_equity, params=params, splitter=splitter)
    source_columns = list(f1_equity.columns)

    rows = [{
        "asset_class": "equity (source, own OOS CV)",
        "n_rows": sum(d["test_size"] for d in source_cv["fold_detail"]),
        "n_positive": sum(d["test_positives"] for d in source_cv["fold_detail"]),
        "transfer_auroc": source_cv["mean_auroc"],
        "transfer_pr_auc": source_cv["mean_pr_auc"],
    }]

    for asset_name, (f1_target, crash_labels) in target_datasets.items():
        X_target, y_target = align_features_labels(f1_target, crash_labels)
        rows.append(evaluate_transfer(model, source_columns, X_target, y_target, asset_name))

    return pd.DataFrame(rows), source_cv
