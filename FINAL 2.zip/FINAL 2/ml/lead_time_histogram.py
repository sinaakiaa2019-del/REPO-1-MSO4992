"""
Lead-time histogram (Sina Kia) — Week 8.

Week 4 reported lead time for exactly the 3 named reference crises. This
module generalises that to EVERY crash episode present in the label series
(detected automatically from crash_labels), so the team can see the full
DISTRIBUTION of lead times the model achieves, not just three hand-picked
examples. It reuses ml.lead_time_analysis.compute_lead_times unchanged --
that function's reference_crashes parameter already accepts any list of
(name, start, end) tuples, so all that's needed here is the episode detector.
"""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from ml.lead_time_analysis import compute_lead_times


def detect_crash_episodes(crash_labels, max_gap_days=10):
    """
    Detect contiguous "crash episodes" from a 0/1 crash_label series.

    The forward-looking drawdown label is 1 for every day inside a 20-day
    lookahead window that eventually sees a >10% drawdown, so a single crash
    event typically produces many separate short runs of 1s close together in
    time rather than one long unbroken run. Runs separated by at most
    max_gap_days are merged into a single episode, so e.g. a 3-week crisis
    with a few single-day dips back below threshold still counts as ONE
    episode with ONE onset, not a dozen tiny ones.

    Returns list of (episode_name, start_date, end_date) tuples, sorted by
    start date, in the same shape ml.lead_time_analysis.compute_lead_times
    expects for its reference_crashes argument.
    """
    labels = crash_labels["crash_label"] if isinstance(crash_labels, pd.DataFrame) else crash_labels
    labels = labels.sort_index()
    positive_dates = labels.index[labels == 1]

    if len(positive_dates) == 0:
        return []

    episodes = []
    episode_start = positive_dates[0]
    episode_end = positive_dates[0]

    for date in positive_dates[1:]:
        gap_days = (date - episode_end).days
        if gap_days <= max_gap_days:
            episode_end = date
        else:
            episodes.append((episode_start, episode_end))
            episode_start = date
            episode_end = date
    episodes.append((episode_start, episode_end))

    return [
        (f"episode_{i+1} ({start.date()})", start, end)
        for i, (start, end) in enumerate(episodes)
    ]


def compute_lead_time_histogram(proba_series, crash_labels, threshold=0.5,
                                lookback_days=120, max_gap_days=10):
    """
    Detect crash episodes and compute the out-of-sample lead time for each.

    Returns
    -------
    (episode_table, lead_times_found)
        episode_table : pd.DataFrame, same columns as compute_lead_times
        (one row per detected episode).
        lead_times_found : np.ndarray of the lead_time_trading_days values
        for episodes where an alarm WAS found (NaNs dropped) -- this is what
        gets histogrammed.
    """
    episodes = detect_crash_episodes(crash_labels, max_gap_days=max_gap_days)
    if not episodes:
        empty = pd.DataFrame(columns=[
            "crisis", "onset", "alarm_date", "lead_time_trading_days",
            "threshold", "max_proba_in_window", "alarm_found", "n_oos_obs_in_window",
        ])
        return empty, np.array([])

    table = compute_lead_times(
        proba_series, threshold=threshold, reference_crashes=episodes,
        lookback_days=lookback_days,
    )
    found = table.loc[table["alarm_found"], "lead_time_trading_days"].dropna().values
    return table, found


def save_lead_time_histogram(lead_times_found, output_path, n_bins=10, title=None):
    """
    Histogram of lead times (trading days) across every detected episode
    where an alarm was found. If there's nothing to plot (no episodes had an
    alarm), still writes a PNG with an explicit "no data" message rather than
    silently producing no file.
    """
    fig, ax = plt.subplots(figsize=(7, 5))
    if len(lead_times_found) == 0:
        ax.text(0.5, 0.5, "No episodes with a detected out-of-sample alarm",
                ha="center", va="center", transform=ax.transAxes, fontsize=11)
        ax.set_xticks([])
        ax.set_yticks([])
    else:
        bins = min(n_bins, max(3, len(lead_times_found)))
        ax.hist(lead_times_found, bins=bins, color="#4C72B0", edgecolor="white", alpha=0.85)
        ax.axvline(np.median(lead_times_found), color="#D62728", linestyle="--",
                  label=f"Median = {np.median(lead_times_found):.0f} days")
        ax.set_xlabel("Lead time (trading days before onset)")
        ax.set_ylabel("Number of crash episodes")
        ax.legend(fontsize=9)

    ax.set_title(title or "Distribution of out-of-sample lead times across all detected crash episodes")
    fig.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return output_path
