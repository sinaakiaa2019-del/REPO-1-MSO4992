"""
ML & Validation orchestrator (Sina Kia) — Week 8.

Run AFTER run_ml.py. Reuses Weeks 1-3 state and rebuilds F3 like Week 4/6/7.

  python run_ml_week8.py

Deliverables:
  - Confusion matrix (at threshold=0.5) + a full threshold sweep with the
    best-F1 operating point highlighted.
  - Lead-time histogram: generalises Week 4's 3-crisis table to every
    detected crash episode.
  - LSTM benchmark: same expanding-window CV discipline as XGBoost, for a
    fair deep-learning comparison.
  - Live dashboard support: trains and persists the "F2-lite" model
    (vix, realised_vol_20d, yield_curve_slope only -- the subset obtainable
    from a lightweight live data pull) so the Streamlit dashboard's Live tab
    can score a live snapshot without retraining on every page load.
"""

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from ml import ml_config
from ml.confusion_matrix_analysis import (
    best_f1_threshold,
    compute_confusion_matrix,
    save_confusion_matrix_plot,
    save_threshold_sweep_plot,
    sweep_thresholds,
)
from ml.f3_combined_features import build_f1_f2_f3
from ml.lead_time_analysis import out_of_sample_probabilities
from ml.lead_time_histogram import compute_lead_time_histogram, save_lead_time_histogram
from ml.live_features import LIVE_F2_LITE_FEATURES, build_live_f2_lite_features
from ml.lstm_benchmark import build_lstm_vs_xgboost_table, cross_validated_lstm_auroc
from ml.model_persistence import save_model
from ml.models import cross_validated_auroc
from run_ml import main as run_weeks_1_to_3


def banner(text):
    print("\n" + "=" * 64)
    print(text)
    print("=" * 64)


def main():
    ml_config.ensure_output_dirs()

    banner("Reusing Weeks 1-3 (returns, crash labels, equity F1/F2) + building F3")
    state = run_weeks_1_to_3()
    crash_labels = state["crash_labels"]
    equity_f1 = state["f1_features"]
    equity_f2 = state["f2_features"]
    aligned, y = build_f1_f2_f3(equity_f1, equity_f2, crash_labels)
    X3 = aligned["F3"]
    print(f"  F3: {X3.shape[0]} rows x {X3.shape[1]} features")

    proba = out_of_sample_probabilities(X3, y)
    if proba.empty:
        print("  No out-of-sample probabilities produced -- Weeks 8 analyses need this, stopping.")
        return
    y_oos = y.loc[proba.index]

    # ---------------- Week 8: confusion matrix ----------------
    banner("WEEK 8  Confusion matrix + threshold sweep")
    cm = compute_confusion_matrix(proba.values, y_oos.values, threshold=ml_config.CONFUSION_MATRIX_THRESHOLD)
    print(cm)
    pd_to_csv_single_row(cm, ml_config.CONFUSION_MATRIX_FILE)
    save_confusion_matrix_plot(cm, ml_config.CONFUSION_MATRIX_PLOT_FILE)
    print(f"  Saved: {ml_config.CONFUSION_MATRIX_FILE}, {ml_config.CONFUSION_MATRIX_PLOT_FILE}")

    sweep = sweep_thresholds(proba.values, y_oos.values)
    sweep.to_csv(ml_config.THRESHOLD_SWEEP_FILE, index=False)
    save_threshold_sweep_plot(sweep, ml_config.THRESHOLD_SWEEP_PLOT_FILE)
    best = best_f1_threshold(sweep)
    print(f"  Best-F1 threshold: {best['threshold']} (F1={best['f1']:.3f}, "
          f"precision={best['precision']:.3f}, recall={best['recall']:.3f})")
    print(f"  Saved: {ml_config.THRESHOLD_SWEEP_FILE}, {ml_config.THRESHOLD_SWEEP_PLOT_FILE}")

    # ---------------- Week 8: lead-time histogram ----------------
    banner("WEEK 8  Lead-time histogram (all detected crash episodes)")
    episode_table, lead_times_found = compute_lead_time_histogram(
        proba, crash_labels, threshold=ml_config.CONFUSION_MATRIX_THRESHOLD,
        max_gap_days=ml_config.LEAD_TIME_HISTOGRAM_MAX_GAP_DAYS,
    )
    print(episode_table.to_string(index=False))
    episode_table.to_csv(ml_config.LEAD_TIME_HISTOGRAM_TABLE_FILE, index=False)
    save_lead_time_histogram(lead_times_found, ml_config.LEAD_TIME_HISTOGRAM_PLOT_FILE)
    print(f"  {len(lead_times_found)} / {len(episode_table)} episodes had a detected alarm.")
    print(f"  Saved: {ml_config.LEAD_TIME_HISTOGRAM_TABLE_FILE}, {ml_config.LEAD_TIME_HISTOGRAM_PLOT_FILE}")

    # ---------------- Week 8: LSTM benchmark ----------------
    banner("WEEK 8  LSTM benchmark (same expanding-window CV as XGBoost)")
    xgb_result = cross_validated_auroc(X3, y)
    print(f"  XGBoost F3: mean AUROC={xgb_result['mean_auroc']:.3f} "
          f"(scored {xgb_result['n_scored_folds']}/{xgb_result['n_total_folds']} folds)")

    lstm_result = cross_validated_lstm_auroc(
        X3, y, seq_len=ml_config.LSTM_SEQ_LEN, hidden_size=ml_config.LSTM_HIDDEN_SIZE,
        epochs=ml_config.LSTM_EPOCHS,
    )
    print(f"  LSTM F3:     mean AUROC={lstm_result['mean_auroc']:.3f} "
          f"(scored {lstm_result['n_scored_folds']}/{lstm_result['n_total_folds']} folds, "
          f"seq_len={lstm_result['seq_len']})")

    comparison = build_lstm_vs_xgboost_table(lstm_result, xgb_result)
    print(comparison.to_string(index=False))
    comparison.to_csv(ml_config.LSTM_VS_XGBOOST_TABLE_FILE, index=False)
    print(f"  Saved: {ml_config.LSTM_VS_XGBOOST_TABLE_FILE}")

    # ---------------- Week 8: persist model for the live dashboard ----------------
    banner("WEEK 8  Training + persisting the F2-lite model (for the Live dashboard tab)")
    try:
        macro_df, _ = None, None
        from ml.data_access import align_features_labels
        # Reuse whatever macro source Week 2 already resolved -- rebuild it
        # the same way run_ml.py does, to avoid duplicating that fallback logic.
        import run_ml as _run_ml
        macro_df, _ = _run_ml.load_macro_or_synthetic(state["returns"])
        f2_lite = build_live_f2_lite_features(macro_df)
        X_lite, y_lite = align_features_labels(f2_lite, crash_labels)
        lite_cv = cross_validated_auroc(X_lite, y_lite, return_models=True)
        if not lite_cv["models"]:
            print("  No fold produced a model -- skipping persistence.")
        else:
            model_path, meta_path = save_model(
                lite_cv["models"][-1], LIVE_F2_LITE_FEATURES, ml_config.F2_LITE_MODEL_FILE,
                extra_metadata={"mean_auroc_oos": lite_cv["mean_auroc"]},
            )
            print(f"  Saved model: {model_path}")
            print(f"  Saved metadata: {meta_path}")
            print(f"  F2-lite mean OOS AUROC: {lite_cv['mean_auroc']:.3f} "
                  "(3-feature model, weaker than full F3 -- for live scoring only)")
    except Exception as exc:
        print(f"  Could not train/persist the live model: {exc}")

    banner("DONE (Week 8)")
    print(f"Reports: {ml_config.ML_REPORT_DIR}")
    print(f"Figures: {ml_config.ML_FIGURE_DIR}")
    print(f"Models:  {ml_config.MODEL_DIR}")


def pd_to_csv_single_row(row_dict, path):
    import pandas as pd
    pd.DataFrame([row_dict]).to_csv(path, index=False)


if __name__ == "__main__":
    main()
