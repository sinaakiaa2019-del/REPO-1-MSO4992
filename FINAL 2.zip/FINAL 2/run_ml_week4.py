"""
ML & Validation orchestrator (Sina Kia) — Week 4.

Run this AFTER run_ml.py (Weeks 1-3). It reuses that run's returns, F1/F2
features, and crash labels rather than recomputing them, so Weeks 1-3 and
Week 4 always agree on the same data.

  python run_ml_week4.py

Deliverables (per the 11-week plan):
  - F3 combined model: F1 (topology) + F2 (standard), added to the F1-vs-F2
    comparison to make it F1 vs F2 vs F3.
  - SHAP heatmap: out-of-sample SHAP values for the F3 model, top features
    over time, so we can see WHEN each feature drives the crash probability up
    rather than just its average importance.
  - Lead-time analysis: for each reference crisis, the first out-of-sample
    alarm (F3 model, threshold 0.5) and how many trading days before onset
    that gave the team.
"""

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from ml import ml_config
from ml.f3_combined_features import build_f1_f2_f3
from ml.lead_time_analysis import compute_lead_times, out_of_sample_probabilities
from ml.models import compare_feature_sets
from ml.shap_analysis import compute_shap_values_oos, save_shap_heatmap
from run_ml import main as run_weeks_1_to_3


def banner(text):
    print("\n" + "=" * 64)
    print(text)
    print("=" * 64)


def main():
    ml_config.ensure_output_dirs()

    banner("Reusing Weeks 1-3 (returns, crash labels, F1, F2)")
    state = run_weeks_1_to_3()
    crash_labels = state["crash_labels"]
    f1_features = state["f1_features"]
    f2_features = state["f2_features"]

    # ---------------- Week 4: F3 combined model ----------------
    banner("WEEK 4  F3 = F1 + F2 combined model")
    aligned, y = build_f1_f2_f3(f1_features, f2_features, crash_labels)
    print(f"  Common rows: {len(y)}")
    print(f"  F1: {aligned['F1'].shape[1]} features, "
          f"F2: {aligned['F2'].shape[1]} features, "
          f"F3: {aligned['F3'].shape[1]} features")

    comparison = compare_feature_sets(aligned, y)
    print(comparison.to_string(index=False))
    comparison.to_csv(ml_config.F1_VS_F2_VS_F3_TABLE_FILE, index=False)
    print(f"  Saved: {ml_config.F1_VS_F2_VS_F3_TABLE_FILE}")

    f3_row = comparison[comparison["feature_set"] == "F3"].iloc[0]
    f2_row = comparison[comparison["feature_set"] == "F2"].iloc[0]
    if pd_isna(f3_row["mean_auroc"]) or pd_isna(f2_row["mean_auroc"]):
        print("  NOTE: F3 vs F2 AUROC comparison inconclusive (NaN present); "
              "see the single-class-fold warning above.")
    else:
        delta = f3_row["mean_auroc"] - f2_row["mean_auroc"]
        print(f"  F3 - F2 mean AUROC = {delta:+.3f} "
              f"({'F3 ahead' if delta > 0 else 'F2 ahead or tied'})")

    # ---------------- Week 4: SHAP heatmap on F3 ----------------
    banner("WEEK 4  Out-of-sample SHAP heatmap (F3)")
    X3 = aligned["F3"]
    shap_df = compute_shap_values_oos(X3, y)
    if shap_df.empty:
        print("  No out-of-sample rows produced (every fold degenerate) -- "
              "skipping heatmap. Check fold sizes / purge gap for this dataset.")
    else:
        print(f"  Out-of-sample SHAP matrix: {shap_df.shape[0]} rows x {shap_df.shape[1]} features")
        importance = shap_df.abs().mean(axis=0).sort_values(ascending=False)
        importance_df = importance.reset_index()
        importance_df.columns = ["feature", "mean_abs_shap_oos"]
        importance_df.to_csv(ml_config.F3_SHAP_IMPORTANCE_FILE, index=False)
        print(importance_df.head(10).to_string(index=False))

        save_shap_heatmap(
            shap_df, ml_config.SHAP_HEATMAP_F3_FILE, top_n=15,
            title="F3 out-of-sample SHAP heatmap (top 15 features)",
        )
        print(f"  Heatmap saved: {ml_config.SHAP_HEATMAP_F3_FILE}")

    # ---------------- Week 4: lead-time analysis ----------------
    banner("WEEK 4  Lead-time analysis (F3, threshold="
           f"{ml_config.LEAD_TIME_THRESHOLD})")
    proba_series = out_of_sample_probabilities(X3, y)
    if proba_series.empty:
        print("  No out-of-sample probabilities produced -- skipping lead-time analysis.")
    else:
        lead_times = compute_lead_times(
            proba_series,
            threshold=ml_config.LEAD_TIME_THRESHOLD,
            lookback_days=ml_config.LEAD_TIME_LOOKBACK_DAYS,
        )
        print(lead_times.to_string(index=False))
        lead_times.to_csv(ml_config.LEAD_TIME_TABLE_FILE, index=False)
        print(f"  Saved: {ml_config.LEAD_TIME_TABLE_FILE}")
        n_found = int(lead_times["alarm_found"].sum())
        print(f"  Alarm found before onset for {n_found} / {len(lead_times)} reference crises.")

    banner("DONE (Week 4)")
    print(f"Reports: {ml_config.ML_REPORT_DIR}")
    print(f"Figures: {ml_config.ML_FIGURE_DIR}")


def pd_isna(x):
    import pandas as pd
    return pd.isna(x)


if __name__ == "__main__":
    main()
