from datetime import datetime


def write_data_quality_report(path, prices, cleaned_prices, returns,
                               metadata_df, missing_report, baseline_features, crash_labels):
    """Write a markdown data quality report summarising pipeline outputs."""
    removed_assets = sorted(set(prices.columns) - set(cleaned_prices.columns))

    lines = [
        "# Data Quality Report",
        "",
        f"Report created: {datetime.now().strftime('%Y-%m-%d %H:%M')}",
        "",
        "## Data universe",
        f"Initial number of assets: {prices.shape[1]}",
        f"Final number of assets used: {cleaned_prices.shape[1]}",
        f"Assets used: {', '.join(cleaned_prices.columns)}",
        "",
    ]

    if removed_assets:
        lines.append(f"Assets removed (>50% missing globally): {', '.join(removed_assets)}")
    else:
        lines.append("No assets were removed.")

    high_missing = missing_report[missing_report["missing_ratio"] > 0.10].sort_values(
        "missing_ratio", ascending=False
    )
    if not high_missing.empty:
        lines += ["", "## Tickers with >10% missing data (kept via per-window filtering)"]
        for ticker, row in high_missing.iterrows():
            lines.append(f"  {ticker}: {row['missing_ratio']:.1%} missing "
                         f"(first valid: {row['first_date']})")

    lines += [
        "",
        "## Data size",
        f"Price rows after cleaning: {cleaned_prices.shape[0]}",
        f"Return rows: {returns.shape[0]}",
        f"Rolling windows created: {metadata_df.shape[0]}",
        f"Baseline feature rows: {baseline_features.shape[0]}",
        f"Crash label rows: {crash_labels.shape[0]}",
        "",
        "## Missing data handling",
        "Tickers with more than 50% missing observations are dropped globally.",
        "Gaps of up to 5 consecutive days are forward-filled.",
        "Per-window universe filtering then excludes stocks with less than 80%",
        "valid returns in a given rolling window, without dropping them globally.",
        "",
        "## Main outputs",
        "- cleaned price data",
        "- daily log returns",
        "- EWMA correlation and distance matrices (NPZ per window)",
        "- window metadata CSV",
        "- baseline features (realised vol, avg correlation, eigenvalue ratio)",
        "- crash labels (forward drawdown labels)",
        "- FRED macro features (VIX, yield curve, credit spreads)",
        "",
        "## Survivorship bias note",
        "S&P 500 membership is reconstructed point-in-time from the Wikipedia",
        "additions/removals table. Residual bias: yfinance may lack full price",
        "history for stocks removed due to bankruptcy (Brown, 1995).",
    ]

    path.write_text("\n".join(lines), encoding="utf-8")


def write_development_notes(path):
    """Write a brief pipeline description to the logs directory."""
    notes = """# Development Notes

The data pipeline downloads S&P 500 prices via yfinance and FRED macro series
via pandas_datareader, cleans missing values, computes log returns, and builds
EWMA correlation and Mantegna distance matrices saved as NPZ files.

S&P 500 membership is reconstructed point-in-time from the Wikipedia
additions/removals history to reduce survivorship bias.

Per-window universe filtering retains all tickers globally but excludes those
with insufficient history in a given rolling window, so the asset count varies
across windows. This is standard practice for long datasets spanning multiple
index compositions.

Output files are organised so they can be consumed directly by the TDA and
machine-learning stages without any additional preprocessing.
"""
    path.write_text(notes, encoding="utf-8")
