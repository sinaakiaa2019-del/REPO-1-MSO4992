"""
ML & Validation orchestrator (Sina Kia) — Week 5.

Run AFTER run_ml.py / run_ml_week4.py. Reuses Weeks 1-3 state (returns, crash
labels, equity F1/F2) rather than recomputing it.

  python run_ml_week5.py

Deliverables:
  - Cross-asset AUROC: F1/F2/F3 comparison repeated for credit and
    international instruments (real handover if present, synthetic
    placeholder otherwise), stacked with the equity result into one table.
  - Sector leadership heatmap: per-GICS-sector lead time before each
    reference crash, from that sector's own topology-only model.
"""

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from ml import ml_config
from ml.cross_asset_validation import (
    build_cross_asset_auroc_table,
    evaluate_asset_class,
    load_asset_class_features,
)
from ml.sector_leadership import (
    build_sector_leadership_table,
    pivot_leadership_heatmap,
    save_sector_leadership_heatmap,
)
from run_ml import main as run_weeks_1_to_3


def banner(text):
    print("\n" + "=" * 64)
    print(text)
    print("=" * 64)


def main():
    ml_config.ensure_output_dirs()

    banner("Reusing Weeks 1-3 (returns, crash labels, equity F1/F2)")
    state = run_weeks_1_to_3()
    crash_labels = state["crash_labels"]
    equity_f1 = state["f1_features"]
    equity_f2 = state["f2_features"]

    # ---------------- Week 5: cross-asset AUROC ----------------
    banner("WEEK 5  Cross-asset AUROC (equity vs credit vs international)")

    equity_table = evaluate_asset_class("equity", equity_f1, equity_f2, crash_labels)

    credit_f1, credit_f2, credit_prov = load_asset_class_features(
        "credit",
        topology_csv_path=ml_config.CREDIT_TOPOLOGY_FEATURES_FILE,
        betti_npz_path=ml_config.CREDIT_BETTI_CURVE_FILE,
        synthetic_seed=41, synthetic_betti_seed=43, synthetic_macro_seed=47,
    )
    print(f"  [credit] F1 source: {credit_prov['f1']}")
    print(f"  [credit] F2 source: {credit_prov['f2']}")
    credit_table = evaluate_asset_class("credit", credit_f1, credit_f2, crash_labels)

    intl_f1, intl_f2, intl_prov = load_asset_class_features(
        "international",
        topology_csv_path=ml_config.INTERNATIONAL_TOPOLOGY_FEATURES_FILE,
        betti_npz_path=ml_config.INTERNATIONAL_BETTI_CURVE_FILE,
        synthetic_seed=53, synthetic_betti_seed=59, synthetic_macro_seed=61,
    )
    print(f"  [international] F1 source: {intl_prov['f1']}")
    print(f"  [international] F2 source: {intl_prov['f2']}")
    intl_table = evaluate_asset_class("international", intl_f1, intl_f2, crash_labels)

    cross_asset_table = build_cross_asset_auroc_table(equity_table, credit_table, intl_table)
    print(cross_asset_table.to_string(index=False))
    cross_asset_table.to_csv(ml_config.CROSS_ASSET_AUROC_TABLE_FILE, index=False)
    print(f"  Saved: {ml_config.CROSS_ASSET_AUROC_TABLE_FILE}")
    print("  NOTE: credit and international results use synthetic stand-in data")
    print("  until Octavian/Kunal hand over real credit and international")
    print("  topology -- treat these two rows as a pipeline smoke test, not a result.")

    # ---------------- Week 5: sector leadership heatmap ----------------
    banner("WEEK 5  Sector leadership heatmap")
    print("  NOTE: per-sector topology handover from Kunal not yet present for")
    print("  any sector -- all 11 sectors below use the SYNTHETIC placeholder")
    print("  described in ml/sector_leadership.py. Lead times are illustrative")
    print("  of the pipeline only, not an empirical finding.")

    long_table, provenance = build_sector_leadership_table(crash_labels)
    long_table.to_csv(ml_config.SECTOR_LEADERSHIP_TABLE_FILE, index=False)
    print(f"  Saved: {ml_config.SECTOR_LEADERSHIP_TABLE_FILE}")

    pivot = pivot_leadership_heatmap(long_table)
    print(pivot.to_string())

    save_sector_leadership_heatmap(
        pivot, ml_config.SECTOR_LEADERSHIP_HEATMAP_FILE,
        title="Sector Leadership Heatmap [SYNTHETIC PLACEHOLDER -- see notes]",
    )
    print(f"  Heatmap saved: {ml_config.SECTOR_LEADERSHIP_HEATMAP_FILE}")

    banner("DONE (Week 5)")
    print(f"Reports: {ml_config.ML_REPORT_DIR}")
    print(f"Figures: {ml_config.ML_FIGURE_DIR}")


if __name__ == "__main__":
    main()
