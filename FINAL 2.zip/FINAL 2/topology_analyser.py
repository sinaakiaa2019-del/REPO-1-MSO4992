"""Topology analysis utilities: reads TDA outputs and computes regime statistics."""
import numpy as np
import pandas as pd
from pathlib import Path

from config import BETTI_CURVE_FILE, CRASH_LABELS_FILE, REPORTS_DIR, TOPOLOGY_FEATURES_FILE


def load_topology_features():
    """Load betti_curves.npz and topology_features.csv produced by tda/run_tda.py."""
    topology_df = None
    betti_array = None
    dates       = None

    if Path(TOPOLOGY_FEATURES_FILE).exists():
        topology_df = pd.read_csv(TOPOLOGY_FEATURES_FILE, index_col=0)
        topology_df.index = pd.to_datetime(topology_df.index)

    if Path(BETTI_CURVE_FILE).exists():
        data = np.load(BETTI_CURVE_FILE, allow_pickle=True)
        # Kunal's tda/run_tda.py saves the array under the key 'betti'. Earlier
        # this loader only looked for 'betti_curves'/'curves', so betti_array
        # came back None and the entire phase-portrait / beta-ratio / event-study
        # branch silently produced nothing even when the real TDA output existed.
        # Check 'betti' first, then the legacy aliases, then fall back to the
        # first stored array so a future rename can't silently break this again.
        for key in ("betti", "betti_curves", "curves"):
            if key in data:
                betti_array = data[key]
                break
        if betti_array is None:
            array_keys = [k for k in data.files if k != "dates"]
            if array_keys:
                betti_array = data[array_keys[0]]
        raw_dates = data["dates"] if "dates" in data.files else None
        if raw_dates is not None:
            dates = pd.to_datetime([str(d) for d in raw_dates])

    return topology_df, betti_array, dates


def load_crash_labels():
    """Load crash labels produced by the data pipeline."""
    if not Path(CRASH_LABELS_FILE).exists():
        return None
    df = pd.read_csv(CRASH_LABELS_FILE, index_col=0)
    df.index = pd.to_datetime(df.index)
    return df


def compute_beta_ratio(betti_array, dates):
    """Compute the H1/H0 loop-to-component ratio (Gidea & Katz scalar) per window."""
    if betti_array is None:
        return pd.DataFrame()

    if betti_array.ndim == 3:
        h0 = betti_array[:, :, 0].sum(axis=1).astype(float)
        h1 = betti_array[:, :, 1].sum(axis=1).astype(float)
    elif betti_array.ndim == 2:
        h0 = betti_array[:, 0].astype(float)
        h1 = betti_array[:, 1].astype(float) if betti_array.shape[1] > 1 else np.zeros(len(betti_array))
    else:
        return pd.DataFrame()

    h0_safe = np.where(h0 == 0, 1e-8, h0)
    ratio   = h1 / h0_safe

    idx = dates if dates is not None else pd.RangeIndex(len(ratio))
    return pd.DataFrame({"h0_sum": h0, "h1_sum": h1, "beta_ratio": ratio}, index=idx)


def compute_summary_statistics(topology_df, crash_labels):
    """Mean, std, skewness, and kurtosis per topology feature split by crash vs normal regime."""
    if topology_df is None or crash_labels is None:
        return pd.DataFrame()

    merged = topology_df.join(crash_labels[["crash_label"]], how="inner")
    crash  = merged[merged["crash_label"] == 1].drop(columns=["crash_label"])
    normal = merged[merged["crash_label"] == 0].drop(columns=["crash_label"])

    records = []
    for col in topology_df.columns:
        if col not in crash.columns:
            continue
        records.append({
            "feature":     col,
            "crash_mean":  crash[col].mean(),
            "crash_std":   crash[col].std(),
            "crash_skew":  crash[col].skew(),
            "crash_kurt":  crash[col].kurt(),
            "normal_mean": normal[col].mean(),
            "normal_std":  normal[col].std(),
            "normal_skew": normal[col].skew(),
            "normal_kurt": normal[col].kurt(),
        })
    return pd.DataFrame(records)


def generate_results_skeleton(output_path=None):
    """Write a paper results section skeleton with placeholders for computed values."""
    if output_path is None:
        output_path = REPORTS_DIR / "paper_results_skeleton.md"

    text = """# Results — Section Skeleton

Fill in bracketed values from the output CSVs in outputs/ml_reports/.

## RQ1  Can topology predict market crashes?
- Table: F1 vs F2 AUROC (5-fold expanding-window CV)  <- f1_vs_f2_auroc.csv
- Key result: topology AUROC = [X], standard features AUROC = [Y]

## RQ2  Which filtration scale (epsilon) is most predictive?
- Figure: AUROC vs epsilon  <- from filtration sensitivity analysis
- Key result: peak at epsilon ~ [X], corresponding to Pearson rho ~ [Y]

## RQ3  Does F3 (topology + standard) outperform either alone?
- Table: F1 vs F2 vs F3 AUROC with DeLong p-values
- Key result: F3 = [X] AUROC, p = [Y] vs F2 baseline

## RQ4  Does the signal generalise cross-asset?
- Table: AUROC on credit and international instruments
- Key result: [describe generalisation]

## RQ5  Which sector topology leads before crashes?
- Table: sector-level AUROC and mean lead time per crash event
- Key result: [sector] led in 2008, [sector] led in 2020

## Topology Regime Statistics
- Table: mean/std/skew/kurt per feature in crash vs non-crash windows
  <- topology_summary_statistics.csv
- Key finding: [feature] shows largest separation between regimes
"""
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    Path(output_path).write_text(text, encoding="utf-8")
    print(f"  Results skeleton: {output_path}")
